from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from app.engines.authority_source_authenticity import (
    AuthoritySourceAttestation,
    attest_reference_authority_record,
)
from app.engines.authority_store import AuthorityStateRecord, get_authority_record


class AuthorityEvidenceUnavailable(RuntimeError):
    """Raised when an identified authority source cannot currently be queried."""


class AuthorityEvidenceConflict(RuntimeError):
    """Raised when authoritative sources provide materially conflicting authority evidence."""


@dataclass(frozen=True)
class AuthorityEvidenceResult:
    authority_id: str
    record: AuthorityStateRecord | None
    source_status: str
    evidence_source: str
    acquisition_layer: str
    source_attestation: AuthoritySourceAttestation | None = None


class AuthorityEvidenceAdapter(Protocol):
    """Normalize external authority evidence into a FlowSignal AuthorityStateRecord."""

    def acquire(self, authority_id: str) -> AuthorityEvidenceResult:
        ...


class ReferenceAuthorityStoreAdapter:
    """Reference adapter over the in-memory authority registry used by the harness."""

    def acquire(self, authority_id: str) -> AuthorityEvidenceResult:
        record = get_authority_record(authority_id)
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=record,
            source_status="AVAILABLE" if record is not None else "NOT_FOUND",
            evidence_source="authoritative_mandate_store",
            acquisition_layer="ReferenceAuthorityStoreAdapter",
            source_attestation=None if record is None else attest_reference_authority_record(record),
        )
