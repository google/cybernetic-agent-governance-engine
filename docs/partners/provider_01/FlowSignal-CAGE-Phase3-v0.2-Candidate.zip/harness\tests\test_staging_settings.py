import pytest

from app.settings import load_settings


def test_no_tls_env_defaults_to_plain_http(monkeypatch):
    for var in (
        "FLOWSIGNAL_TLS_CERTFILE",
        "FLOWSIGNAL_TLS_KEYFILE",
        "FLOWSIGNAL_TLS_CA_CERTS",
    ):
        monkeypatch.delenv(var, raising=False)
    settings = load_settings()
    assert settings.mtls_enabled is False
    assert settings.port == 8000


def test_complete_mtls_env_enables_mtls(monkeypatch, tmp_path):
    cert = tmp_path / "server.crt"
    key = tmp_path / "server.key"
    ca = tmp_path / "ca.crt"
    for f in (cert, key, ca):
        f.write_text("placeholder")
    monkeypatch.setenv("FLOWSIGNAL_TLS_CERTFILE", str(cert))
    monkeypatch.setenv("FLOWSIGNAL_TLS_KEYFILE", str(key))
    monkeypatch.setenv("FLOWSIGNAL_TLS_CA_CERTS", str(ca))
    settings = load_settings()
    assert settings.mtls_enabled is True
    assert settings.port == 8443


def test_partial_mtls_env_is_rejected(monkeypatch, tmp_path):
    # A half-configured mTLS setup is worse than none: it can look secure
    # while silently accepting any client. This must fail loudly at startup.
    cert = tmp_path / "server.crt"
    cert.write_text("placeholder")
    monkeypatch.setenv("FLOWSIGNAL_TLS_CERTFILE", str(cert))
    monkeypatch.delenv("FLOWSIGNAL_TLS_KEYFILE", raising=False)
    monkeypatch.delenv("FLOWSIGNAL_TLS_CA_CERTS", raising=False)
    with pytest.raises(ValueError, match="Incomplete mTLS configuration"):
        load_settings()


def test_require_client_cert_defaults_true(monkeypatch):
    monkeypatch.delenv("FLOWSIGNAL_REQUIRE_CLIENT_CERT", raising=False)
    assert load_settings().require_client_cert is True


def test_require_client_cert_can_be_disabled(monkeypatch):
    monkeypatch.setenv("FLOWSIGNAL_REQUIRE_CLIENT_CERT", "false")
    assert load_settings().require_client_cert is False
