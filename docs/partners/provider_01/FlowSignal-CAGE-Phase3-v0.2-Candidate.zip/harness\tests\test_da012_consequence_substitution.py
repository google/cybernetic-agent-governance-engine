from datetime import datetime
from pathlib import Path

import pytest

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
ATTEMPTED_AT = datetime.fromisoformat("2026-08-10T09:15:30+00:00")


def _attempt(request, **overrides):
    values = {
        "actor_id": request.actor_id,
        "principal_id": request.principal_id,
        "action": request.action,
        "target": request.target,
        "amount": request.amount,
        "currency": request.currency,
        "source_account": request.source_account,
        "beneficiary": request.beneficiary,
        "purpose": request.purpose,
        "mandate_id": request.mandate_id,
        "attempted_at": ATTEMPTED_AT,
    }
    values.update(overrides)
    return ExecutionAttempt(**values)


def _allowed_receipt():
    request = load_scenario(AP001)
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )
            assert response.decision == "ALLOW"
            return request, receipt


def test_da012_exact_bound_consequence_is_permitted_while_authority_is_unchanged():
    request, receipt = _allowed_receipt()

    # temporary_authoritative_mandate_status restores ACTIVE but also advances the
    # authority-state version on exit, so obtain a fresh receipt inside the state
    # context for this exact-execution positive control.
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            response, current_receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )
            assert response.decision == "ALLOW"
            result = validate_execution(current_receipt, _attempt(request))

    assert result.status == "PERMITTED"
    assert result.reason_code == "BOUND_ALLOW_VALID"
    assert result.execution_permit is not None


@pytest.mark.parametrize(
    ("field", "replacement"),
    [
        ("amount", 749999.0),
        ("beneficiary", "SUPPLIER-Y"),
        ("source_account", "ACCT-SECONDARY-999"),
        ("purpose", "Altered purpose after authority determination"),
    ],
)
def test_da012_any_post_allow_consequence_change_is_blocked(field, replacement):
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )
            assert response.decision == "ALLOW"

            # Authority remains current. Only the represented consequence changes.
            result = validate_execution(
                receipt,
                _attempt(request, **{field: replacement}),
            )

    assert result.status == "BLOCKED"
    assert result.reason_code == "ACTION_BINDING_MISMATCH"
    assert result.expected_action_binding_hash != result.attempted_action_binding_hash
    assert result.execution_permit is None
