from datetime import datetime
from pathlib import Path

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


def _execution_attempt(request):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=datetime.fromisoformat("2026-08-10T09:15:30+00:00"),
    )


def test_da011_authority_revoked_after_allow_but_before_execution_blocks_stale_receipt():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )

            assert response.decision == "ALLOW"
            assert receipt.decision == "ALLOW"
            issued_authority_version = receipt.authority_state_version

            approval_evidence = next(
                item for item in receipt.evidence_references
                if item.get("type") == "approval_state"
            )
            authority_evidence = next(
                item for item in receipt.evidence_references
                if item.get("type") == "delegated_authority_state"
            )
            assert approval_evidence["status"] == "APPROVED"
            assert authority_evidence["status"] == "ACTIVE"
            assert authority_evidence["authority_state_version"] == issued_authority_version

            # TOCTOU condition: authority changes after determination but before bind/execution.
            with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
                gateway = validate_execution(receipt, _execution_attempt(request))

                assert gateway.status == "BLOCKED"
                assert gateway.reason_code == "AUTHORITY_STATE_STALE_REEVALUATION_REQUIRED"
                assert gateway.execution_permit is None


def test_da011_unchanged_authority_allows_same_bound_execution():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )

            assert response.decision == "ALLOW"
            gateway = validate_execution(receipt, _execution_attempt(request))

            assert gateway.status == "PERMITTED"
            assert gateway.reason_code == "BOUND_ALLOW_VALID"
            assert gateway.execution_permit is not None
