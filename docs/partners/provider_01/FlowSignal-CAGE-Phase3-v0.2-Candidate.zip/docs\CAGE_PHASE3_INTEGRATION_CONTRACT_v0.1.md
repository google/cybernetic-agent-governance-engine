# FlowSignal ↔ CAGE Phase 3 Integration Contract v0.1

## Baseline

This integration is derived from frozen Runtime Authority baseline commit:

`87fc133828ca9e8c16a9bda425aa508aa661469e`

The frozen baseline is preserved on `baseline-cage-v0.1`. CAGE-specific work is additive and does not redefine the core FlowSignal ALLOW / ESCALATE / REFUSE semantics.

## Responsibility boundary

FlowSignal determines. CAGE enforces. ConsequenceGateway acts.

FlowSignal has no consequence-execution capability or credentials. CAGE remains responsible for execution-boundary enforcement, downstream token consumption, routing and consequence formation.

## Phase 3 contract requested by Google

### CAGE endpoint

`POST /cage/validate`

The payload is the same authority-determination request accepted by the native FlowSignal service boundary. Caller-provided authority assertions and evidence references remain presented context and do not become authoritative merely because CAGE transports them.

### ALLOW

An ALLOW response MUST contain:

- `decision: "ALLOW"`
- non-empty `authority_record_id`
- sealed `authority_receipt`
- execution context identifying platform and execution ID

ALLOW is necessary but not sufficient for consequence formation. CAGE remains responsible for validating/enforcing the receipt and its own execution controls.

### ESCALATE

FlowSignal retains the native semantic `ESCALATE`. The CAGE-facing adapter MUST return a normal ValidationResult rather than raising an exception.

The result includes a finding:

- `code: "FLOWSIGNAL_HOLD"`
- `needs_human_review: true`

ESCALATE is non-executable.

### REFUSE

REFUSE remains explicit and non-authorising. The CAGE-facing result includes `FLOWSIGNAL_REFUSE`. CAGE/platform policy, approval, identity or caller assertions must not override FlowSignal REFUSE.

## Preserved Runtime Authority protections

The CAGE adapter inherits the frozen baseline protections, including exact consequence binding, receipt integrity, single-use/replay protection, authority-state currency, approval continuity, mutable supporting-evidence continuity, temporal validity, source authenticity, rollback/equivocation detection, distributed consistency fail-closed behavior, and evidence provenance derived from actual JUnit results.

## Phase 3 live-environment materials

The following are operational deployment materials and are deliberately not embedded in the reference repository:

1. FlowSignal staging endpoint URL and test API credentials.
2. Staging CA bundle.
3. Staging client certificate.
4. Staging client private key.

These must be generated specifically for the private staging trust relationship and distributed through an appropriate secret channel. Reference/test signing keys in the harness are not staging or production PKI material.

## Phase 3 live validation targets

The live GKE/mTLS validation should prove at minimum:

1. CAGE reaches FlowSignal over the intended mTLS trust path.
2. ALLOW includes `decision` and `authority_record_id` and remains bound to the exact consequence.
3. ESCALATE returns `FLOWSIGNAL_HOLD` with `needs_human_review: true` and cannot execute.
4. REFUSE cannot be overridden by an otherwise permissive CAGE/platform state.
5. FlowSignal unavailable or malformed response fails closed.
6. Tampered, stale, expired, mismatched or replayed authority receipts do not produce executable authority.
7. Approval or mutable supporting evidence invalidated after determination makes the prior ALLOW unusable.
8. FlowSignal cannot mint CAGE ConsequenceTokens or form the consequence directly.
9. CAGE cannot manufacture FlowSignal authority locally when FlowSignal has not returned a valid current ALLOW.

## Claim boundary

This contract and reference suite do not claim Google CAGE production certification, production IAM/KMS/HSM correctness, production distributed availability, universal route closure, legal/regulatory compliance, or real payment-rail prevention. Those claims require live integration and platform-specific evidence.
