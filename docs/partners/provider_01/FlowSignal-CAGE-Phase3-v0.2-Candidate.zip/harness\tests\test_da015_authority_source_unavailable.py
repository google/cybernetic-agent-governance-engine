from datetime import datetime
from pathlib import Path

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_evidence_adapter import AuthorityEvidenceUnavailable
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from app.engines.receipt_integrity import verify_receipt_hmac
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
RESOLUTION_PATH = "RETRY_AUTHORITATIVE_MANDATE_SOURCE_OR_ROUTE_TO_AUTHORITY_OWNER"


class UnavailableAuthorityAdapter:
    def acquire(self, _authority_id: str):
        raise AuthorityEvidenceUnavailable("authoritative authority source unavailable")


def _execution_attempt(request):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=datetime.fromisoformat("2026-08-10T09:15:30+00:00"),
    )


def _authority_evidence(receipt):
    return next(item for item in receipt.evidence_references if item["type"] == "delegated_authority_state")


def test_da015_resolvable_authority_source_outage_escalates_and_does_not_execute():
    request = load_scenario(AP001)
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=UnavailableAuthorityAdapter(),
            authority_resolution_path=RESOLUTION_PATH,
        )

    assert response.decision == "ESCALATE"
    assert response.reason_code == "AUTHORITY_EVIDENCE_TEMPORARILY_UNAVAILABLE"
    assert response.required_action == RESOLUTION_PATH
    assert receipt.valid_until is None
    assert verify_receipt_hmac(receipt) is True
    authority_evidence = _authority_evidence(receipt)
    assert authority_evidence["status"] == "UNKNOWN"
    assert authority_evidence["source_status"] == "UNAVAILABLE"
    assert authority_evidence["source"] == "UNKNOWN"
    assert authority_evidence["acquisition_layer"] == "UnavailableAuthorityAdapter"
    assert authority_evidence["resolution_path"] == RESOLUTION_PATH
    gateway = validate_execution(receipt, _execution_attempt(request))
    assert gateway.status == "BLOCKED"
    assert gateway.reason_code == "NO_APPLICABLE_ALLOW"
    assert gateway.execution_permit is None


def test_da015_unresolvable_authority_source_outage_does_not_misuse_escalate():
    request = load_scenario(AP001)
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=UnavailableAuthorityAdapter(),
        )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_NOT_ESTABLISHED"
    assert verify_receipt_hmac(receipt) is True
    authority_evidence = _authority_evidence(receipt)
    assert authority_evidence["status"] == "UNKNOWN"
    assert authority_evidence["source_status"] == "UNAVAILABLE"
    assert authority_evidence["source"] == "UNKNOWN"
    assert authority_evidence["acquisition_layer"] == "UnavailableAuthorityAdapter"
    assert "resolution_path" not in authority_evidence
    gateway = validate_execution(receipt, _execution_attempt(request))
    assert gateway.status == "BLOCKED"
    assert gateway.reason_code == "NO_APPLICABLE_ALLOW"
    assert gateway.execution_permit is None
