from __future__ import annotations

import re
from pathlib import Path
from xml.etree import ElementTree


def _evidence_pattern(evidence_id: str) -> re.Pattern[str]:
    parts = [part.lower() for part in re.findall(r"[A-Za-z0-9]+", evidence_id)]
    if not parts:
        raise ValueError("evidence identifier must contain alphanumeric content")
    token = r"[-_.]?".join(re.escape(part) for part in parts)
    return re.compile(rf"(?<![a-z0-9]){token}(?![a-z0-9])", re.IGNORECASE)


def _root(path: str | Path):
    return ElementTree.parse(path).getroot()


def junit_test_counts(path: str | Path) -> dict[str, int]:
    counts = {"total": 0, "passed": 0, "failed": 0, "errors": 0, "skipped": 0}
    for testcase in _root(path).iter("testcase"):
        counts["total"] += 1
        if testcase.find("failure") is not None:
            counts["failed"] += 1
        elif testcase.find("error") is not None:
            counts["errors"] += 1
        elif testcase.find("skipped") is not None:
            counts["skipped"] += 1
        else:
            counts["passed"] += 1
    return counts


def observed_evidence_from_junit(path: str | Path, evidence_ids: set[str]) -> set[str]:
    """Return evidence IDs backed by passing, boundary-matched JUnit testcases."""
    passed_names: list[str] = []
    for testcase in _root(path).iter("testcase"):
        if testcase.find("failure") is not None or testcase.find("error") is not None or testcase.find("skipped") is not None:
            continue
        name = testcase.attrib.get("name", "")
        classname = testcase.attrib.get("classname", "")
        passed_names.append(f"{classname} {name}")

    observed: set[str] = set()
    for evidence_id in evidence_ids:
        pattern = _evidence_pattern(evidence_id)
        if any(pattern.search(test_name) for test_name in passed_names):
            observed.add(evidence_id)
    return observed
