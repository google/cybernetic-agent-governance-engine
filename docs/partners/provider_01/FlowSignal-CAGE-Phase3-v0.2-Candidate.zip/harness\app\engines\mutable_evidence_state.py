from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from threading import RLock


class MutableEvidenceStateUnavailable(RuntimeError):
    """Raised when mutable supporting-evidence state cannot be established."""


@dataclass
class InMemoryMutableEvidenceStateStore:
    """Reference-only mutable supporting-evidence state.

    Each evidence source has a monotonic version. Invalidation advances the
    version and marks the source non-current. Production integrations should bind
    this contract to an authoritative, durable source of evidence invalidation.
    """

    _versions: dict[str, int] = field(default_factory=dict)
    _current: dict[str, bool] = field(default_factory=dict)
    _lock: RLock = field(default_factory=RLock)

    def snapshot(self, source: str) -> tuple[int, bool]:
        with self._lock:
            return self._versions.get(source, 1), self._current.get(source, True)

    def invalidate(self, source: str) -> int:
        with self._lock:
            version = self._versions.get(source, 1) + 1
            self._versions[source] = version
            self._current[source] = False
            return version

    def restore_current(self, source: str) -> int:
        with self._lock:
            version = self._versions.get(source, 1) + 1
            self._versions[source] = version
            self._current[source] = True
            return version


DEFAULT_MUTABLE_EVIDENCE_STATE_STORE = InMemoryMutableEvidenceStateStore()
_ACTIVE_MUTABLE_EVIDENCE_STATE_STORE = DEFAULT_MUTABLE_EVIDENCE_STATE_STORE


def _state_call(operation, *args):
    try:
        return operation(*args)
    except MutableEvidenceStateUnavailable:
        raise
    except Exception as exc:
        raise MutableEvidenceStateUnavailable(
            "mutable supporting-evidence state unavailable"
        ) from exc


def get_mutable_evidence_snapshot(source: str) -> tuple[int, bool]:
    return _state_call(_ACTIVE_MUTABLE_EVIDENCE_STATE_STORE.snapshot, source)


def invalidate_mutable_evidence(source: str) -> int:
    return _state_call(_ACTIVE_MUTABLE_EVIDENCE_STATE_STORE.invalidate, source)


@contextmanager
def temporary_mutable_evidence_state_store(store):
    global _ACTIVE_MUTABLE_EVIDENCE_STATE_STORE
    previous = _ACTIVE_MUTABLE_EVIDENCE_STATE_STORE
    _ACTIVE_MUTABLE_EVIDENCE_STATE_STORE = store
    try:
        yield store
    finally:
        _ACTIVE_MUTABLE_EVIDENCE_STATE_STORE = previous
