# Staging Deployment Guide

## What this covers

How to run the FlowSignal reference service in a form suitable for the CAGE
Phase 3 live-endpoint / GKE mTLS validation. This document describes the
*mechanism*; it deliberately does not include real credentials.

## What is NOT in this repository, and why

Per explicit instruction, no production/staging credentials, certificates or
private keys are created or committed here without prior sign-off. That means:

- the real FlowSignal staging endpoint URL and API credentials,
- the real staging CA bundle, client certificate and private key,

are **not** in this package. They must be generated through an approved
process and distributed via a secure channel, not committed to git.

The mTLS mechanism was verified during development using locally generated,
test-only certificate material. Those generated certificates and private keys
are not included in this reviewed branch. The verification procedure and scope
are documented below so the mechanism can be reproduced with separately
generated test material without committing certificate or key artefacts.

## Configuration

All settings are environment variables (`app/settings.py`). See
`.env.example` for the full list with placeholder values - copy it to `.env`
and fill in real paths for an actual deployment; never commit the filled-in
version.

| Variable | Required | Purpose |
|---|---|---|
| `FLOWSIGNAL_HOST` | No (defaults `127.0.0.1`) | Bind address |
| `FLOWSIGNAL_PORT` | No (defaults `8000`, or `8443` if mTLS is configured) | Bind port |
| `FLOWSIGNAL_TLS_CERTFILE` | For mTLS | Server certificate |
| `FLOWSIGNAL_TLS_KEYFILE` | For mTLS | Server private key |
| `FLOWSIGNAL_TLS_CA_CERTS` | For mTLS | CA bundle used to verify client certificates |
| `FLOWSIGNAL_REQUIRE_CLIENT_CERT` | No (defaults `true`) | If `false`, client cert becomes optional rather than required - do not set this to `false` for the Phase 3 path |

The three TLS variables must be set together or not at all. Setting only some
of them raises a startup error rather than silently running without full
enforcement - see `test_partial_mtls_env_is_rejected` in
`tests/test_staging_settings.py`.

## Running

Local development, no TLS:

```bash
python -m app.run_staging
```

With mTLS (using real staging material once issued):

```bash
export FLOWSIGNAL_TLS_CERTFILE=/path/to/staging_server.crt
export FLOWSIGNAL_TLS_KEYFILE=/path/to/staging_server.key
export FLOWSIGNAL_TLS_CA_CERTS=/path/to/staging_ca_bundle.crt
python -m app.run_staging
```

## What has been verified against a live server

Run with the local demo certificates (`tests/mtls_fixtures/`), against a real
running instance, not simulated:

1. A client presenting a certificate signed by the trusted CA is accepted and
   receives a real `/cage/validate` determination.
2. A client presenting no certificate is rejected at the TLS handshake -
   connection fails before any HTTP request is processed.
3. A client presenting a certificate signed by a *different*, untrusted CA is
   rejected at the handshake.
4. A client presenting an expired certificate is rejected at the handshake.
5. Stopping the service results in connection failure for a subsequent
   request, not a silent or degraded success - fail-closed, not fail-open.

## What has not yet been verified

- **Client identity beyond CA trust.** The current enforcement verifies that
  a client certificate chains to the trusted CA. It does not yet check the
  presented certificate's specific identity (e.g. Common Name) against an
  expected allow-list. A certificate signed by the right CA but issued to the
  wrong service would currently be accepted. If CAGE's platform team needs
  per-client identity restriction beyond CA trust, this needs an additional
  application-level check before Phase 3 sign-off.
- **Real GKE/Linkerd mTLS termination**, as opposed to uvicorn's built-in TLS
  used here for local verification. The production path may terminate mTLS at
  a service mesh sidecar rather than in the Python process itself, in which
  case this configuration serves as a fallback/direct-connection path rather
  than the primary one - worth confirming which topology Phase 3
  expects.
- **Real staging credentials and certificates**, since none are included here.
