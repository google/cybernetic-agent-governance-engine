from datetime import datetime
from pathlib import Path

from app.engines.approval_store import get_approval_status, temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from app.engines.receipt_integrity import verify_receipt_hmac
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


def _execution_attempt(request):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=datetime.fromisoformat("2026-08-10T09:15:30+00:00"),
    )


def _evidence(receipt, evidence_type):
    return next(item for item in receipt.evidence_references if item["type"] == evidence_type)


def test_da016_valid_approval_does_not_override_revoked_delegated_authority():
    request = load_scenario(AP001)
    assert request.actor_authenticated is True
    assert request.kya_status == "VERIFIED"
    assert request.action == "payment.release"
    assert request.counterparty_status == "APPROVED"
    assert request.account_status == "ACTIVE"
    assert request.risk_state == "NORMAL"
    assert request.screening_status == "CLEAR"

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        assert get_approval_status(APPROVAL_ID) == "APPROVED"
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            response, receipt = evaluate_delegated_authority(request, approval_id=APPROVAL_ID)
            assert response.decision == "REFUSE"
            assert response.reason_code == "AUTHORITY_NOT_ESTABLISHED"
            assert receipt.decision == "REFUSE"
            assert verify_receipt_hmac(receipt) is True

            failed = [check for check in receipt.checks if not check.passed]
            assert len(failed) == 1
            assert failed[0].name == "mandate_active"
            assert failed[0].reason == "Mandate status is 'REVOKED'"

            approval_evidence = _evidence(receipt, "approval_state")
            assert approval_evidence["type"] == "approval_state"
            assert approval_evidence["source"] == "approval_store"
            assert approval_evidence["approval_id"] == APPROVAL_ID
            assert approval_evidence["status"] == "APPROVED"
            assert isinstance(approval_evidence["state_version"], int)
            assert approval_evidence["state_version"] >= 1

            authority_evidence = _evidence(receipt, "delegated_authority_state")
            assert authority_evidence["source"] == "authoritative_mandate_store"
            assert authority_evidence["mandate_id"] == request.mandate_id
            assert authority_evidence["status"] == "REVOKED"
            assert authority_evidence["authority_state_version"] == receipt.authority_state_version

            gateway = validate_execution(receipt, _execution_attempt(request))
            assert gateway.status == "BLOCKED"
            assert gateway.reason_code == "NO_APPLICABLE_ALLOW"


def test_da016_positive_control_allows_when_approval_and_authority_are_current():
    request = load_scenario(AP001)
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            response, receipt = evaluate_delegated_authority(request, approval_id=APPROVAL_ID)
            assert response.decision == "ALLOW"
            assert verify_receipt_hmac(receipt) is True

            approval_evidence = _evidence(receipt, "approval_state")
            authority_evidence = _evidence(receipt, "delegated_authority_state")
            assert approval_evidence["status"] == "APPROVED"
            assert isinstance(approval_evidence["state_version"], int)
            assert authority_evidence["status"] == "ACTIVE"

            gateway = validate_execution(receipt, _execution_attempt(request))
            assert gateway.status == "PERMITTED"
            assert gateway.reason_code == "BOUND_ALLOW_VALID"
