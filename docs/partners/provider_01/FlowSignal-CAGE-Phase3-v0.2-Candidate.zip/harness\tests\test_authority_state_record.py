from datetime import datetime, timezone
from pathlib import Path

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import (
    get_authority_record,
    temporary_authority_record,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.receipt_integrity import verify_receipt_hmac
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


def _failed(receipt, name):
    return next(check for check in receipt.checks if check.name == name and not check.passed)


def _authority_evidence(receipt):
    return next(item for item in receipt.evidence_references if item["type"] == "delegated_authority_state")


def test_authstate001_reference_record_drives_positive_control_and_seals_provenance():
    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        response, receipt = evaluate_delegated_authority(request, approval_id=APPROVAL_ID)

    assert response.decision == "ALLOW"
    assert verify_receipt_hmac(receipt) is True
    evidence = _authority_evidence(receipt)
    assert evidence["principal_id"] == request.principal_id
    assert evidence["delegate_id"] == request.actor_id
    assert request.action in evidence["permitted_consequence_classes"]
    assert evidence["max_amount"] == 1000000.0
    assert evidence["currency"] == "GBP"
    assert evidence["provenance"]["source"] == "reference_authority_registry"
    assert evidence["provenance"]["source_record_id"] == request.mandate_id


def test_authstate002_principal_mismatch_refuses_even_when_legacy_fields_say_yes():
    request = load_scenario(AP001)
    with temporary_authority_record(request.mandate_id, principal_id="different-principal"):
        response, receipt = evaluate_delegated_authority(request, approval_id=APPROVAL_ID)

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_RECORD_CONSTRAINT_FAILED"
    assert _failed(receipt, "authority_principal_matches").reason == "Principal does not match delegated authority record"
    assert verify_receipt_hmac(receipt) is True


def test_authstate003_delegate_mismatch_refuses():
    request = load_scenario(AP001)
    with temporary_authority_record(request.mandate_id, delegate_id="different-agent"):
        response, receipt = evaluate_delegated_authority(request, approval_id=APPROVAL_ID)

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_RECORD_CONSTRAINT_FAILED"
    assert _failed(receipt, "authority_delegate_matches").reason == "Actor does not match delegated authority record"


def test_authstate004_consequence_scope_mismatch_refuses():
    request = load_scenario(AP001)
    with temporary_authority_record(request.mandate_id, permitted_consequence_classes=("payment.prepare",)):
        response, receipt = evaluate_delegated_authority(request, approval_id=APPROVAL_ID)

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_RECORD_CONSTRAINT_FAILED"
    assert "outside delegated authority scope" in _failed(receipt, "authority_consequence_class_permitted").reason


def test_authstate005_record_effective_window_is_independent_execution_condition():
    request = load_scenario(AP001, rebase_to_now=False)
    with temporary_authority_record(
        request.mandate_id,
        effective_from=datetime(2026, 8, 11, tzinfo=timezone.utc),
        effective_until=datetime(2027, 1, 1, tzinfo=timezone.utc),
    ):
        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            sealed_at=request.requested_execution_time,
        )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_RECORD_CONSTRAINT_FAILED"
    assert _failed(receipt, "authority_effective").reason == "Delegated authority record is not effective at execution time"
