from datetime import datetime, timezone
from pathlib import Path

from app.adapters.reference_boundary_adapter import ReferenceExecutionBoundaryAdapter
from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


def test_xplat004_two_reference_adapters_conform_on_valid_allow():
    request = load_scenario(AP001)
    alpha = ReferenceExecutionBoundaryAdapter(platform="REFERENCE-BOUNDARY-ALPHA")
    beta = ReferenceExecutionBoundaryAdapter(platform="REFERENCE-BOUNDARY-BETA")
    attempted_at = datetime.now(timezone.utc)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            alpha_result = alpha.determine_and_enforce(
                request=request,
                approval_id=APPROVAL_ID,
                execution_id="EXEC-ADAPTER-ALPHA",
                attempted_at=attempted_at,
                evidence_references=[{"type": "platform_policy", "result": "PERMIT"}],
            )
            beta_result = beta.determine_and_enforce(
                request=request,
                approval_id=APPROVAL_ID,
                execution_id="EXEC-ADAPTER-BETA",
                attempted_at=attempted_at,
                evidence_references=[{"type": "platform_policy", "result": "PERMIT"}],
            )

    assert alpha_result.determination == "ALLOW"
    assert beta_result.determination == "ALLOW"
    assert alpha_result.status == "PERMITTED"
    assert beta_result.status == "PERMITTED"
    assert alpha_result.reason_code == "BOUND_ALLOW_VALID"
    assert beta_result.reason_code == "BOUND_ALLOW_VALID"
    assert alpha_result.gateway_result.execution_permit is not None
    assert beta_result.gateway_result.execution_permit is not None


def test_xplat004_reference_adapter_blocks_revoked_authority_even_with_platform_permit():
    request = load_scenario(AP001)
    request.mandate_status = "ACTIVE"
    adapter = ReferenceExecutionBoundaryAdapter(platform="REFERENCE-BOUNDARY-ALPHA")

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            result = adapter.determine_and_enforce(
                request=request,
                approval_id=APPROVAL_ID,
                execution_id="EXEC-ADAPTER-REVOKED",
                attempted_at=datetime.now(timezone.utc),
                evidence_references=[{"type": "platform_policy", "result": "PERMIT"}],
            )

    assert result.determination == "REFUSE"
    assert result.status == "BLOCKED"
    assert result.reason_code == "NO_APPLICABLE_ALLOW"
    assert result.gateway_result is None
    assert result.authority_receipt is not None

    evidence = result.authority_receipt.evidence_references
    presented = next(item for item in evidence if item["type"] == "presented_authority_assertion")
    authoritative = next(item for item in evidence if item["type"] == "delegated_authority_state")
    assert presented["status"] == "ACTIVE"
    assert authoritative["status"] == "REVOKED"


def test_xplat004_reference_adapter_blocks_without_flow_signal_response(monkeypatch):
    request = load_scenario(AP001)
    adapter = ReferenceExecutionBoundaryAdapter(platform="REFERENCE-BOUNDARY-FAIL-CLOSED")

    def _unavailable(*args, **kwargs):
        raise ConnectionError("FlowSignal unavailable")

    monkeypatch.setattr(adapter._client, "post", _unavailable)

    result = adapter.determine_and_enforce(
        request=request,
        approval_id=APPROVAL_ID,
        execution_id="EXEC-ADAPTER-OUTAGE",
        attempted_at=datetime.now(timezone.utc),
    )

    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_DETERMINATION_UNAVAILABLE"
    assert result.gateway_result is None
    assert result.authority_receipt is None
