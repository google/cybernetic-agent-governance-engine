from pathlib import Path

from app.engines.authority_evidence_adapter import ReferenceAuthorityStoreAdapter
from app.engines.authority_version_floor import temporary_authority_consistency_checkpoint
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


class UnavailableAuthorityConsistencyCheckpoint:
    """Models a partition/outage of the shared distributed checkpoint."""

    def get_highest_verified_version(self, source: str, authority_id: str):
        raise RuntimeError("shared authority consistency checkpoint unavailable")

    def get_verified_digest(self, source: str, authority_id: str, version: int):
        raise RuntimeError("shared authority consistency checkpoint unavailable")

    def observe_verified_version(self, source: str, authority_id: str, version: int, *, content_digest=None):
        raise RuntimeError("shared authority consistency checkpoint unavailable")


def test_attack006_checkpoint_unavailable_must_never_degrade_to_allow():
    request = load_scenario(AP001)

    with temporary_authority_consistency_checkpoint(UnavailableAuthorityConsistencyCheckpoint()):
        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=ReferenceAuthorityStoreAdapter(),
        )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_CONSISTENCY_CHECKPOINT_UNAVAILABLE"

    evidence = next(
        item for item in receipt.evidence_references
        if item["type"] == "delegated_authority_state"
    )
    assert evidence["source_authenticity"] == "VERIFIED"
    assert evidence["consistency_checkpoint"] == "UNAVAILABLE"
    assert evidence["status"] == "UNKNOWN"
