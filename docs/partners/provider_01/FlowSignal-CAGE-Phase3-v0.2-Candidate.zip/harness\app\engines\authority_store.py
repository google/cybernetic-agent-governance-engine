from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, replace
from datetime import datetime, timezone
from threading import RLock


@dataclass(frozen=True)
class AuthorityProvenance:
    source: str
    source_record_id: str
    observed_at: datetime


@dataclass(frozen=True)
class AuthorityStateRecord:
    authority_id: str
    principal_id: str
    delegate_id: str
    permitted_consequence_classes: tuple[str, ...]
    max_amount: float | None
    currency: str | None
    effective_from: datetime | None
    effective_until: datetime | None
    lifecycle_status: str
    version: int
    provenance: AuthorityProvenance

    def is_effective_at(self, moment: datetime) -> bool:
        moment = _aware(moment)
        if self.effective_from is not None and moment < _aware(self.effective_from):
            return False
        if self.effective_until is not None and moment > _aware(self.effective_until):
            return False
        return True


def _aware(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


# Private reference authority records. Payment-specific helpers below remain as
# compatibility views over these richer records while vNext migrates the core.
_AUTHORITY_RECORDS = {
    "MANDATE-TREASURY-001": AuthorityStateRecord(
        authority_id="MANDATE-TREASURY-001",
        principal_id="institution-001",
        delegate_id="agent-treasury-01",
        permitted_consequence_classes=("payment.release",),
        max_amount=1000000.0,
        currency="GBP",
        effective_from=datetime(2026, 1, 1, tzinfo=timezone.utc),
        effective_until=datetime(2027, 1, 1, tzinfo=timezone.utc),
        lifecycle_status="ACTIVE",
        version=1,
        provenance=AuthorityProvenance(
            source="reference_authority_registry",
            source_record_id="MANDATE-TREASURY-001",
            observed_at=datetime(2026, 8, 28, tzinfo=timezone.utc),
        ),
    ),
}


# Compatibility views retained for the existing harness API surface.
AUTHORITATIVE_MANDATE_LIMITS = {
    authority_id: record.max_amount
    for authority_id, record in _AUTHORITY_RECORDS.items()
    if record.max_amount is not None
}
AUTHORITATIVE_MANDATE_STATUS = {
    authority_id: record.lifecycle_status
    for authority_id, record in _AUTHORITY_RECORDS.items()
}


class _MonotonicAuthorityState:
    __slots__ = ("__version",)

    def __init__(self, initial_version: int) -> None:
        object.__setattr__(self, "_MonotonicAuthorityState__version", initial_version)

    @property
    def version(self) -> int:
        return self.__version

    def advance(self) -> int:
        object.__setattr__(
            self,
            "_MonotonicAuthorityState__version",
            self.__version + 1,
        )
        return self.__version


_AUTHORITY_STATE = _MonotonicAuthorityState(1)
_AUTHORITY_STATE_LOCK = RLock()


def get_authority_record(authority_id: str) -> AuthorityStateRecord | None:
    with _AUTHORITY_STATE_LOCK:
        return _AUTHORITY_RECORDS.get(authority_id)


def set_authority_record(authority_id: str, record: AuthorityStateRecord) -> int:
    """Replace one authority record and advance the global authority-state version."""
    if record.authority_id != authority_id:
        raise ValueError("authority_id must match record.authority_id")
    with _AUTHORITY_STATE_LOCK:
        new_global_version = _AUTHORITY_STATE.advance()
        _AUTHORITY_RECORDS[authority_id] = replace(record, version=new_global_version)
        _sync_compatibility_views(authority_id)
        return new_global_version


def _sync_compatibility_views(authority_id: str) -> None:
    record = _AUTHORITY_RECORDS.get(authority_id)
    if record is None:
        AUTHORITATIVE_MANDATE_LIMITS.pop(authority_id, None)
        AUTHORITATIVE_MANDATE_STATUS.pop(authority_id, None)
        return
    if record.max_amount is None:
        AUTHORITATIVE_MANDATE_LIMITS.pop(authority_id, None)
    else:
        AUTHORITATIVE_MANDATE_LIMITS[authority_id] = record.max_amount
    AUTHORITATIVE_MANDATE_STATUS[authority_id] = record.lifecycle_status


def get_authoritative_mandate_limit(mandate_id: str) -> float | None:
    record = get_authority_record(mandate_id)
    return None if record is None else record.max_amount


def get_authoritative_mandate_status(mandate_id: str) -> str | None:
    record = get_authority_record(mandate_id)
    return None if record is None else record.lifecycle_status


def set_authoritative_mandate_status(mandate_id: str, status: str) -> int:
    """Compatibility lifecycle mutation backed by the explicit authority record."""
    with _AUTHORITY_STATE_LOCK:
        record = _AUTHORITY_RECORDS.get(mandate_id)
        if record is None:
            raise KeyError(mandate_id)
        new_global_version = _AUTHORITY_STATE.advance()
        _AUTHORITY_RECORDS[mandate_id] = replace(
            record,
            lifecycle_status=status.upper(),
            version=new_global_version,
            provenance=replace(record.provenance, observed_at=datetime.now(timezone.utc)),
        )
        _sync_compatibility_views(mandate_id)
        return new_global_version


@contextmanager
def temporary_authoritative_mandate_status(mandate_id: str, status: str):
    """Test-scoped lifecycle mutation with deterministic restoration."""
    with _AUTHORITY_STATE_LOCK:
        previous = _AUTHORITY_RECORDS.get(mandate_id)
        if previous is None:
            raise KeyError(mandate_id)
        new_global_version = _AUTHORITY_STATE.advance()
        _AUTHORITY_RECORDS[mandate_id] = replace(
            previous,
            lifecycle_status=status.upper(),
            version=new_global_version,
            provenance=replace(previous.provenance, observed_at=datetime.now(timezone.utc)),
        )
        _sync_compatibility_views(mandate_id)
    try:
        yield
    finally:
        with _AUTHORITY_STATE_LOCK:
            restore_version = _AUTHORITY_STATE.advance()
            _AUTHORITY_RECORDS[mandate_id] = replace(previous, version=restore_version)
            _sync_compatibility_views(mandate_id)


@contextmanager
def temporary_authority_record(authority_id: str, **changes):
    """Test-scoped mutation of one or more explicit authority-record fields."""
    with _AUTHORITY_STATE_LOCK:
        previous = _AUTHORITY_RECORDS.get(authority_id)
        if previous is None:
            raise KeyError(authority_id)
        new_global_version = _AUTHORITY_STATE.advance()
        updated = replace(previous, **changes, version=new_global_version)
        _AUTHORITY_RECORDS[authority_id] = updated
        _sync_compatibility_views(authority_id)
    try:
        yield updated
    finally:
        with _AUTHORITY_STATE_LOCK:
            restore_version = _AUTHORITY_STATE.advance()
            _AUTHORITY_RECORDS[authority_id] = replace(previous, version=restore_version)
            _sync_compatibility_views(authority_id)


def get_authority_state_version() -> int:
    with _AUTHORITY_STATE_LOCK:
        return _AUTHORITY_STATE.version


@contextmanager
def authority_state_guard():
    """Serialize final standing validation and represented consequence formation.

    The guard is intentionally in-process and reference-harness scoped. It does
    not claim distributed transaction semantics across external systems.
    """
    with _AUTHORITY_STATE_LOCK:
        yield


def get_authority_state_version_unlocked() -> int:
    """Read state while the caller already holds authority_state_guard()."""
    return _AUTHORITY_STATE.version


def advance_authority_state_version() -> int:
    with _AUTHORITY_STATE_LOCK:
        return _AUTHORITY_STATE.advance()
