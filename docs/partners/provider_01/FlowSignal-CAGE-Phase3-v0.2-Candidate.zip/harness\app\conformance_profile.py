from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ConformanceRequirement:
    requirement_id: str
    summary: str
    evidence_tests: tuple[str, ...]


RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1 = (
    ConformanceRequirement("RA-CP-001", "Intercept before consequence binds", ("XPLAT-004",)),
    ConformanceRequirement("RA-CP-002", "Submit exact proposed consequence to authority service", ("XPLAT-001", "XPLAT-004")),
    ConformanceRequirement("RA-CP-003", "Caller authority assertions remain evidence only", ("IND-001", "XPLAT-003")),
    ConformanceRequirement("RA-CP-004", "Carry platform and execution correlation", ("XPLAT-001", "XPLAT-002")),
    ConformanceRequirement("RA-CP-005", "Unknown or malformed determinations fail closed", ("XPLAT-004", "XPLAT-005")),
    ConformanceRequirement("RA-CP-006", "Missing or malformed receipts fail closed", ("XPLAT-004", "XPLAT-005")),
    ConformanceRequirement("RA-CP-007", "ESCALATE and REFUSE are non-executable", ("DA-015", "XPLAT-004")),
    ConformanceRequirement("RA-CP-008", "ALLOW is necessary but not sufficient", ("XPLAT-004", "XPLAT-005")),
    ConformanceRequirement("RA-CP-009", "Receipt integrity must validate", ("XPLAT-005",)),
    ConformanceRequirement("RA-CP-010", "Authority state must remain current", ("DA-011", "XPLAT-005")),
    ConformanceRequirement("RA-CP-011", "Expired ALLOW is non-executable", ("XPLAT-005",)),
    ConformanceRequirement("RA-CP-012", "Receipt must bind exact consequence", ("DA-012", "XPLAT-005")),
    ConformanceRequirement("RA-CP-013", "Authority Receipt is single-use", ("DA-013", "XPLAT-005")),
    ConformanceRequirement("RA-CP-014", "Authority service outage fails closed", ("DA-014", "XPLAT-004")),
    ConformanceRequirement("RA-CP-015", "Resolvable source outage escalates but remains blocked", ("DA-015",)),
    ConformanceRequirement("RA-CP-016", "Unresolvable source outage refuses", ("DA-015",)),
    ConformanceRequirement("RA-CP-017", "Malformed responses never degrade to local permission", ("XPLAT-004", "XPLAT-005")),
    ConformanceRequirement("RA-CP-018", "Authority core does not mint external permits", ("IND-004",)),
    ConformanceRequirement("RA-CP-019", "Authority core has no direct consequence capability in the contract", ("IND-004", "XPLAT-001")),
    ConformanceRequirement("RA-CP-020", "Permit issuance remains boundary responsibility", ("IND-004", "XPLAT-004")),
    ConformanceRequirement("RA-CP-021", "Consequence formation is downstream of permit consumption", ("IND-004",)),
    ConformanceRequirement("RA-CP-022", "Platform context does not alter authority semantics", ("XPLAT-002", "XPLAT-003")),
    ConformanceRequirement("RA-CP-023", "Different adapters produce equivalent authority semantics", ("XPLAT-002", "XPLAT-003")),
    ConformanceRequirement("RA-CP-024", "Policy or approval cannot override REFUSE", ("IND-002", "IND-003", "DA-016")),
)


def requirement_ids() -> set[str]:
    return {requirement.requirement_id for requirement in RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1}
