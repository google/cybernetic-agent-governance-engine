"""Staging/production runtime configuration.

Every setting is read from the environment. Nothing here is a secret - these are
paths and flags. The actual certificate/key material they point to is never
committed to the repository (see .env.example and STAGING.md).

This module supports explicit plain-HTTP local development and configured mTLS.
For the Phase 3 staging/GKE path, mTLS must be configured explicitly. Partial
mTLS configuration surfaces as a startup error rather than silently weakening
the configured TLS mode.
"""

from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class StagingSettings:
    host: str
    port: int
    log_level: str

    # mTLS. All three must be set together for client-certificate enforcement.
    # If none are set, the service runs over plain HTTP - suitable only for
    # local development, never for the Phase 3 staging/GKE path.
    tls_certfile: str | None
    tls_keyfile: str | None
    tls_ca_certs: str | None
    require_client_cert: bool

    @property
    def mtls_enabled(self) -> bool:
        return bool(self.tls_certfile and self.tls_keyfile and self.tls_ca_certs)


def load_settings() -> StagingSettings:
    """Read staging settings from the environment.

    Raises ValueError if mTLS is partially configured (e.g. a cert without a
    CA bundle) - a half-configured mTLS setup is worse than none, since it can
    look secure while accepting any client.
    """
    certfile = os.getenv("FLOWSIGNAL_TLS_CERTFILE") or None
    keyfile = os.getenv("FLOWSIGNAL_TLS_KEYFILE") or None
    ca_certs = os.getenv("FLOWSIGNAL_TLS_CA_CERTS") or None

    provided = [x for x in (certfile, keyfile, ca_certs) if x]
    if provided and len(provided) != 3:
        raise ValueError(
            "Incomplete mTLS configuration: FLOWSIGNAL_TLS_CERTFILE, "
            "FLOWSIGNAL_TLS_KEYFILE and FLOWSIGNAL_TLS_CA_CERTS must all be set "
            "together, or none of them (plain HTTP, local development only)."
        )

    return StagingSettings(
        host=os.getenv("FLOWSIGNAL_HOST", "127.0.0.1"),
        port=int(os.getenv("FLOWSIGNAL_PORT", "8443" if provided else "8000")),
        log_level=os.getenv("FLOWSIGNAL_LOG_LEVEL", "info"),
        tls_certfile=certfile,
        tls_keyfile=keyfile,
        tls_ca_certs=ca_certs,
        require_client_cert=os.getenv("FLOWSIGNAL_REQUIRE_CLIENT_CERT", "true").lower() == "true",
    )
