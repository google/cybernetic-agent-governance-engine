from __future__ import annotations

from dataclasses import replace
from datetime import timedelta
from hashlib import sha256

from app.adapter_conformance import validate_authority_evidence_result
from app.engines.approval_store import get_approval_snapshot
from app.engines.authority_evidence_adapter import (
    AuthorityEvidenceAdapter,
    AuthorityEvidenceConflict,
    AuthorityEvidenceUnavailable,
    ReferenceAuthorityStoreAdapter,
)
from app.engines.authority_source_authenticity import (
    canonical_authority_record,
    verify_authority_source_attestation,
)
from app.engines.authority_store import AuthorityStateRecord
from app.engines.authority_version_floor import (
    AuthorityConsistencyCheckpointUnavailable,
    get_highest_verified_version,
    get_verified_digest,
    observe_verified_version,
)
from app.engines.financial_runtime import evaluate_financial
from app.engines.financial_types import FinancialAuthorityRequest, FinancialCheck
from app.engines.receipt_integrity import compute_receipt_hmac


STALE_EVIDENCE_VIOLATION = "AE-CP-014 authority evidence is stale"
FUTURE_DATED_EVIDENCE_VIOLATION = "AE-CP-021 authority evidence observed_at is in the future"


def _recompute_receipt_hmac(receipt):
    return compute_receipt_hmac(
        receipt_id=receipt.id,
        scenario_id=receipt.scenario_id,
        decision=receipt.decision,
        reason_code=receipt.reason_code,
        sealed_at=receipt.sealed_at,
        valid_until=receipt.valid_until,
        action_binding_hash=receipt.action_binding_hash,
        authority_state_version=receipt.authority_state_version,
        request_snapshot=receipt.request_snapshot,
        checks=receipt.checks,
        evidence_references=receipt.evidence_references,
    )


def _seal_delegated_authority_evidence(
    receipt,
    *,
    approval_id: str,
    approval_status: str | None,
    approval_state_version: int,
    mandate_id: str,
    presented_mandate_status: str,
    authority_record: AuthorityStateRecord | None,
    authority_source_status: str,
    evidence_source: str,
    acquisition_layer: str,
    authority_resolution_path: str | None = None,
    adapter_conformance_violations: tuple[str, ...] = (),
    source_authenticity_status: str = "NOT_APPLICABLE",
    source_authenticity_key_id: str | None = None,
    presented_record_version: int | None = None,
    rollback_detected: bool = False,
    known_current_record_version: int | None = None,
    equivocation_detected: bool = False,
    consistency_checkpoint_status: str = "AVAILABLE",
    authority_evidence_max_age_seconds: int | None = None,
):
    evidence_references = list(receipt.evidence_references)
    authority_evidence = {
        "type": "delegated_authority_state",
        "source": evidence_source,
        "acquisition_layer": acquisition_layer,
        "mandate_id": mandate_id,
        "status": authority_record.lifecycle_status if authority_record is not None else "UNKNOWN",
        "authority_state_version": receipt.authority_state_version,
        "source_status": authority_source_status,
        "adapter_conformance": "PASS" if not adapter_conformance_violations else "FAIL",
        "source_authenticity": source_authenticity_status,
        "consistency_checkpoint": consistency_checkpoint_status,
    }
    if source_authenticity_key_id is not None:
        authority_evidence["source_authenticity_key_id"] = source_authenticity_key_id
    if presented_record_version is not None:
        authority_evidence["record_version"] = presented_record_version
    if rollback_detected:
        authority_evidence["rollback_detected"] = True
    if equivocation_detected:
        authority_evidence["equivocation_detected"] = True
    if known_current_record_version is not None:
        authority_evidence["known_current_record_version"] = known_current_record_version
    if adapter_conformance_violations:
        authority_evidence["adapter_conformance_violations"] = list(adapter_conformance_violations)
    if authority_record is not None:
        authority_evidence.update(
            {
                "principal_id": authority_record.principal_id,
                "delegate_id": authority_record.delegate_id,
                "permitted_consequence_classes": list(authority_record.permitted_consequence_classes),
                "max_amount": authority_record.max_amount,
                "currency": authority_record.currency,
                "effective_from": None if authority_record.effective_from is None else authority_record.effective_from.isoformat(),
                "effective_until": None if authority_record.effective_until is None else authority_record.effective_until.isoformat(),
                "record_version": authority_record.version,
                "provenance": {
                    "source": authority_record.provenance.source,
                    "source_record_id": authority_record.provenance.source_record_id,
                    "observed_at": authority_record.provenance.observed_at.isoformat(),
                },
            }
        )
        if authority_evidence_max_age_seconds is not None:
            freshness_valid_until = authority_record.provenance.observed_at + timedelta(
                seconds=authority_evidence_max_age_seconds
            )
            authority_evidence["freshness_max_age_seconds"] = authority_evidence_max_age_seconds
            authority_evidence["freshness_valid_until"] = freshness_valid_until.isoformat()
    if authority_resolution_path is not None:
        authority_evidence["resolution_path"] = authority_resolution_path

    evidence_references.extend(
        [
            {
                "type": "presented_authority_assertion",
                "source": "request",
                "mandate_id": mandate_id,
                "status": presented_mandate_status,
            },
            {
                "type": "approval_state",
                "source": "approval_store",
                "approval_id": approval_id,
                "status": approval_status or "UNKNOWN",
                "state_version": approval_state_version,
            },
            authority_evidence,
        ]
    )
    updated = replace(receipt, evidence_references=evidence_references)
    return replace(updated, receipt_hmac=_recompute_receipt_hmac(updated))


def _apply_approval_condition(response, receipt, *, approval_id: str, approval_status: str | None):
    approval_current = approval_status == "APPROVED"
    approval_check = FinancialCheck(
        name="approval_current",
        passed=approval_current,
        outcome_on_failure="REFUSE",
        reason=None if approval_current else f"Approval status is '{approval_status or 'UNKNOWN'}'",
        evidence_ref=approval_id,
    )
    checks = list(receipt.checks) + [approval_check]
    if approval_current:
        updated = replace(receipt, checks=checks)
        return response, replace(updated, receipt_hmac=_recompute_receipt_hmac(updated))
    updated_response = replace(response, decision="REFUSE", reason_code="APPROVAL_NOT_CURRENT", valid_until=None, required_action=None)
    updated_receipt = replace(receipt, decision="REFUSE", reason_code="APPROVAL_NOT_CURRENT", valid_until=None, checks=checks)
    return updated_response, replace(updated_receipt, receipt_hmac=_recompute_receipt_hmac(updated_receipt))


def _apply_authority_record_conditions(response, receipt, *, req, authority_record: AuthorityStateRecord | None, sealed_at=None):
    checks = list(receipt.checks)
    if authority_record is None:
        updated = replace(receipt, checks=checks)
        return response, replace(updated, receipt_hmac=_recompute_receipt_hmac(updated))

    moment = sealed_at or req.requested_execution_time
    record_checks = [
        FinancialCheck("authority_principal_matches", req.principal_id == authority_record.principal_id, "REFUSE", None if req.principal_id == authority_record.principal_id else "Principal does not match delegated authority record", authority_record.authority_id),
        FinancialCheck("authority_delegate_matches", req.actor_id == authority_record.delegate_id, "REFUSE", None if req.actor_id == authority_record.delegate_id else "Actor does not match delegated authority record", authority_record.authority_id),
        FinancialCheck("authority_consequence_class_permitted", req.action in authority_record.permitted_consequence_classes, "REFUSE", None if req.action in authority_record.permitted_consequence_classes else f"Consequence class '{req.action}' is outside delegated authority scope", authority_record.authority_id),
        FinancialCheck("authority_effective", authority_record.is_effective_at(moment), "REFUSE", None if authority_record.is_effective_at(moment) else "Delegated authority record is not effective at execution time", authority_record.authority_id),
    ]
    checks.extend(record_checks)
    if any(not check.passed for check in record_checks):
        response = replace(response, decision="REFUSE", reason_code="AUTHORITY_RECORD_CONSTRAINT_FAILED", valid_until=None, required_action=None)
        receipt = replace(receipt, decision="REFUSE", reason_code="AUTHORITY_RECORD_CONSTRAINT_FAILED", valid_until=None, checks=checks)
    else:
        receipt = replace(receipt, checks=checks)
    return response, replace(receipt, receipt_hmac=_recompute_receipt_hmac(receipt))


def _bound_allow_validity_to_authority_evidence(
    response,
    receipt,
    *,
    authority_record: AuthorityStateRecord | None,
    authority_evidence_max_age_seconds: int | None,
):
    if response.decision != "ALLOW" or authority_record is None or receipt.valid_until is None:
        return response, receipt

    horizons = [receipt.valid_until]
    if authority_record.effective_until is not None:
        horizons.append(authority_record.effective_until)
    if authority_evidence_max_age_seconds is not None:
        horizons.append(
            authority_record.provenance.observed_at
            + timedelta(seconds=authority_evidence_max_age_seconds)
        )

    bounded_valid_until = min(horizons)
    if bounded_valid_until == receipt.valid_until:
        return response, receipt

    updated_response = replace(response, valid_until=bounded_valid_until)
    updated_receipt = replace(receipt, valid_until=bounded_valid_until)
    return updated_response, replace(updated_receipt, receipt_hmac=_recompute_receipt_hmac(updated_receipt))


def _convert_authority_uncertainty_to_escalate(response, receipt, *, reason_code: str, reason: str, resolution_path: str):
    checks = [replace(check) for check in receipt.checks]
    for check in checks:
        if check.name == "mandate_active" and not check.passed:
            check.outcome_on_failure = "ESCALATE"
            check.reason = f"{reason}; resolution path: {resolution_path}"
    updated_response = replace(response, decision="ESCALATE", reason_code=reason_code, valid_until=None, required_action=resolution_path)
    updated_receipt = replace(receipt, decision="ESCALATE", reason_code=reason_code, valid_until=None, checks=checks)
    return updated_response, replace(updated_receipt, receipt_hmac=_recompute_receipt_hmac(updated_receipt))


def evaluate_delegated_authority(
    req: FinancialAuthorityRequest,
    *,
    approval_id: str,
    sealed_at=None,
    authority_evidence_adapter: AuthorityEvidenceAdapter | None = None,
    authority_resolution_path: str | None = None,
    authority_evidence_max_age_seconds: int | None = None,
):
    """Determine whether delegated authority remains exercisable for this exact consequence."""
    approval_status, approval_state_version = get_approval_snapshot(approval_id)
    presented_mandate_status = req.mandate_status
    adapter = authority_evidence_adapter or ReferenceAuthorityStoreAdapter()
    adapter_conformance_violations: tuple[str, ...] = ()
    evidence_stale = False
    evidence_future_dated = False
    source_authenticity_status = "NOT_APPLICABLE"
    source_authenticity_key_id: str | None = None
    presented_record_version: int | None = None
    rollback_detected = False
    equivocation_detected = False
    known_current_record_version: int | None = None
    consistency_checkpoint_status = "AVAILABLE"

    try:
        evidence_result = adapter.acquire(req.mandate_id)
        conformance = validate_authority_evidence_result(
            evidence_result,
            requested_authority_id=req.mandate_id,
            evaluated_at=sealed_at or req.requested_execution_time,
            max_evidence_age_seconds=authority_evidence_max_age_seconds,
        )
        evidence_source = evidence_result.evidence_source or "UNKNOWN"
        acquisition_layer = evidence_result.acquisition_layer or type(adapter).__name__
        if conformance.passed:
            candidate_record = evidence_result.record
            authority_source_status = evidence_result.source_status
            if candidate_record is not None:
                presented_record_version = candidate_record.version
            if candidate_record is not None and evidence_result.source_status == "AVAILABLE":
                source_authenticity_key_id = None if evidence_result.source_attestation is None else evidence_result.source_attestation.key_id
                if verify_authority_source_attestation(candidate_record, evidence_result.source_attestation, expected_source=evidence_source):
                    source_authenticity_status = "VERIFIED"
                    content_digest = sha256(canonical_authority_record(candidate_record, source=evidence_source)).hexdigest()
                    existing_digest = get_verified_digest(evidence_source, candidate_record.authority_id, candidate_record.version)
                    known_current_record_version = get_highest_verified_version(evidence_source, candidate_record.authority_id)
                    if existing_digest is not None and existing_digest != content_digest:
                        authority_record = None
                        authority_source_status = "EQUIVOCATION_DETECTED"
                        equivocation_detected = True
                    elif known_current_record_version is not None and candidate_record.version < known_current_record_version:
                        authority_record = None
                        authority_source_status = "ROLLBACK_DETECTED"
                        rollback_detected = True
                    else:
                        authority_record = candidate_record
                        known_current_record_version = observe_verified_version(
                            evidence_source, candidate_record.authority_id, candidate_record.version, content_digest=content_digest
                        )
                else:
                    authority_record = None
                    authority_source_status = "AUTHENTICITY_UNVERIFIED"
                    source_authenticity_status = "FAILED"
            else:
                authority_record = candidate_record
        else:
            authority_record = None
            adapter_conformance_violations = conformance.violations
            evidence_stale = conformance.violations == (STALE_EVIDENCE_VIOLATION,)
            evidence_future_dated = conformance.violations == (FUTURE_DATED_EVIDENCE_VIOLATION,)
            authority_source_status = "STALE" if evidence_stale else "FUTURE_DATED" if evidence_future_dated else "NONCONFORMING"
    except AuthorityEvidenceUnavailable:
        authority_record = None
        authority_source_status = "UNAVAILABLE"
        evidence_source = "UNKNOWN"
        acquisition_layer = type(adapter).__name__
    except AuthorityEvidenceConflict:
        authority_record = None
        authority_source_status = "CONFLICT"
        evidence_source = "MULTIPLE_AUTHORITATIVE_SOURCES"
        acquisition_layer = type(adapter).__name__
    except AuthorityConsistencyCheckpointUnavailable:
        authority_record = None
        authority_source_status = "CONSISTENCY_CHECKPOINT_UNAVAILABLE"
        consistency_checkpoint_status = "UNAVAILABLE"
        evidence_source = locals().get("evidence_source", "UNKNOWN")
        acquisition_layer = locals().get("acquisition_layer", type(adapter).__name__)

    authoritative_status = authority_record.lifecycle_status if authority_record is not None else None
    evaluated_request = replace(req, mandate_status=authoritative_status or "UNKNOWN")
    if authority_record is not None:
        if authority_record.max_amount is not None:
            evaluated_request = replace(evaluated_request, mandate_max_amount=authority_record.max_amount)
        if authority_record.currency is not None:
            evaluated_request = replace(evaluated_request, mandate_currency=authority_record.currency)

    response, receipt = evaluate_financial(evaluated_request, sealed_at=sealed_at)
    response, receipt = _apply_approval_condition(response, receipt, approval_id=approval_id, approval_status=approval_status)
    response, receipt = _apply_authority_record_conditions(response, receipt, req=req, authority_record=authority_record, sealed_at=sealed_at)

    if approval_status == "APPROVED":
        if evidence_future_dated:
            response = replace(response, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_FUTURE_DATED", valid_until=None, required_action=None)
            receipt = replace(receipt, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_FUTURE_DATED", valid_until=None)
            receipt = replace(receipt, receipt_hmac=_recompute_receipt_hmac(receipt))
        elif evidence_stale:
            response = replace(response, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_STALE", valid_until=None, required_action=None)
            receipt = replace(receipt, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_STALE", valid_until=None)
            receipt = replace(receipt, receipt_hmac=_recompute_receipt_hmac(receipt))
        elif adapter_conformance_violations:
            response = replace(response, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_NONCONFORMING", valid_until=None, required_action=None)
            receipt = replace(receipt, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_NONCONFORMING", valid_until=None)
            receipt = replace(receipt, receipt_hmac=_recompute_receipt_hmac(receipt))
        elif source_authenticity_status == "FAILED":
            response = replace(response, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_AUTHENTICITY_UNVERIFIED", valid_until=None, required_action=None)
            receipt = replace(receipt, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_AUTHENTICITY_UNVERIFIED", valid_until=None)
            receipt = replace(receipt, receipt_hmac=_recompute_receipt_hmac(receipt))
        elif consistency_checkpoint_status == "UNAVAILABLE":
            response = replace(response, decision="REFUSE", reason_code="AUTHORITY_CONSISTENCY_CHECKPOINT_UNAVAILABLE", valid_until=None, required_action=None)
            receipt = replace(receipt, decision="REFUSE", reason_code="AUTHORITY_CONSISTENCY_CHECKPOINT_UNAVAILABLE", valid_until=None)
            receipt = replace(receipt, receipt_hmac=_recompute_receipt_hmac(receipt))
        elif equivocation_detected:
            response = replace(response, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_EQUIVOCATION_DETECTED", valid_until=None, required_action=None)
            receipt = replace(receipt, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_EQUIVOCATION_DETECTED", valid_until=None)
            receipt = replace(receipt, receipt_hmac=_recompute_receipt_hmac(receipt))
        elif rollback_detected:
            response = replace(response, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_ROLLBACK_DETECTED", valid_until=None, required_action=None)
            receipt = replace(receipt, decision="REFUSE", reason_code="AUTHORITY_EVIDENCE_ROLLBACK_DETECTED", valid_until=None)
            receipt = replace(receipt, receipt_hmac=_recompute_receipt_hmac(receipt))

    response, receipt = _bound_allow_validity_to_authority_evidence(
        response, receipt, authority_record=authority_record, authority_evidence_max_age_seconds=authority_evidence_max_age_seconds
    )

    sealed_receipt = _seal_delegated_authority_evidence(
        receipt,
        approval_id=approval_id,
        approval_status=approval_status,
        approval_state_version=approval_state_version,
        mandate_id=req.mandate_id,
        presented_mandate_status=presented_mandate_status,
        authority_record=authority_record,
        authority_source_status=authority_source_status,
        evidence_source=evidence_source,
        acquisition_layer=acquisition_layer,
        authority_resolution_path=authority_resolution_path,
        adapter_conformance_violations=adapter_conformance_violations,
        source_authenticity_status=source_authenticity_status,
        source_authenticity_key_id=source_authenticity_key_id,
        presented_record_version=presented_record_version,
        rollback_detected=rollback_detected,
        known_current_record_version=known_current_record_version,
        equivocation_detected=equivocation_detected,
        consistency_checkpoint_status=consistency_checkpoint_status,
        authority_evidence_max_age_seconds=authority_evidence_max_age_seconds,
    )

    if approval_status == "APPROVED" and authority_resolution_path:
        if authority_source_status == "STALE":
            return _convert_authority_uncertainty_to_escalate(response, sealed_receipt, reason_code="AUTHORITY_EVIDENCE_STALE", reason="Authoritative authority evidence is stale and must be refreshed", resolution_path=authority_resolution_path)
        if authority_source_status == "UNAVAILABLE":
            return _convert_authority_uncertainty_to_escalate(response, sealed_receipt, reason_code="AUTHORITY_EVIDENCE_TEMPORARILY_UNAVAILABLE", reason="Authoritative authority evidence is temporarily unavailable", resolution_path=authority_resolution_path)
        if authority_source_status == "CONFLICT":
            return _convert_authority_uncertainty_to_escalate(response, sealed_receipt, reason_code="AUTHORITATIVE_EVIDENCE_CONFLICT", reason="Authoritative sources provide conflicting authority evidence", resolution_path=authority_resolution_path)

    return response, sealed_receipt
