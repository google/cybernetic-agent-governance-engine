from dataclasses import replace
from datetime import timedelta
from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from app.engines.receipt_integrity import verify_receipt_hmac
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


class FixedAdapter:
    def __init__(self, result):
        self.result = result

    def acquire(self, _authority_id: str):
        return self.result


def _attempt(request):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=request.requested_execution_time,
    )


def _authority_evidence(receipt):
    return next(item for item in receipt.evidence_references if item["type"] == "delegated_authority_state")


def test_runtime_gate001_nonconforming_active_record_is_discarded_before_core_evaluation():
    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None
    malformed = replace(record, delegate_id="")
    result = AuthorityEvidenceResult(
        authority_id=request.mandate_id,
        record=malformed,
        source_status="AVAILABLE",
        evidence_source="external-authority-system",
        acquisition_layer="BrokenAdapter",
    )

    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=FixedAdapter(result),
    )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_EVIDENCE_NONCONFORMING"
    assert receipt.decision == "REFUSE"
    assert verify_receipt_hmac(receipt) is True
    evidence = _authority_evidence(receipt)
    assert evidence["status"] == "UNKNOWN"
    assert evidence["source_status"] == "NONCONFORMING"
    assert evidence["adapter_conformance"] == "FAIL"
    assert any("AE-CP-007" in item for item in evidence["adapter_conformance_violations"])
    assert not any(check.name == "authority_delegate_matches" for check in receipt.checks)

    gateway = validate_execution(receipt, _attempt(request))
    assert gateway.status == "BLOCKED"
    assert gateway.execution_permit is None


def test_runtime_gate002_stale_active_record_fails_when_freshness_policy_is_enabled():
    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None
    stale = replace(
        record,
        provenance=replace(
            record.provenance,
            observed_at=request.requested_execution_time - timedelta(hours=2),
        ),
    )
    result = AuthorityEvidenceResult(
        authority_id=request.mandate_id,
        record=stale,
        source_status="AVAILABLE",
        evidence_source="external-authority-system",
        acquisition_layer="StaleAdapter",
    )

    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=FixedAdapter(result),
        authority_evidence_max_age_seconds=300,
    )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_EVIDENCE_STALE"
    evidence = _authority_evidence(receipt)
    assert evidence["source_status"] == "STALE"
    assert evidence["adapter_conformance"] == "FAIL"
    assert any("AE-CP-014" in item for item in evidence["adapter_conformance_violations"])
    assert evidence["status"] == "UNKNOWN"


def test_runtime_gate003_conforming_active_record_reaches_core_and_allows():
    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None
    result = AuthorityEvidenceResult(
        authority_id=request.mandate_id,
        record=record,
        source_status="AVAILABLE",
        evidence_source="authoritative_mandate_store",
        acquisition_layer="ReferenceAuthorityStoreAdapter",
        source_attestation=attest_reference_authority_record(record),
    )

    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=FixedAdapter(result),
    )

    assert response.decision == "ALLOW"
    assert response.reason_code == "AUTHORITY_ESTABLISHED"
    evidence = _authority_evidence(receipt)
    assert evidence["adapter_conformance"] == "PASS"
    assert evidence["source_authenticity"] == "VERIFIED"
    assert "adapter_conformance_violations" not in evidence
    assert any(check.name == "authority_delegate_matches" for check in receipt.checks)


def test_runtime_gate004_noncurrent_approval_still_has_refuse_precedence():
    from app.engines.approval_store import temporary_approval_status

    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None
    malformed = replace(record, principal_id="")
    result = AuthorityEvidenceResult(
        authority_id=request.mandate_id,
        record=malformed,
        source_status="AVAILABLE",
        evidence_source="external-authority-system",
        acquisition_layer="BrokenAdapter",
    )

    with temporary_approval_status(APPROVAL_ID, "WITHDRAWN"):
        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=FixedAdapter(result),
        )

    assert response.decision == "REFUSE"
    assert response.reason_code == "APPROVAL_NOT_CURRENT"
    evidence = _authority_evidence(receipt)
    assert evidence["adapter_conformance"] == "FAIL"
    assert any("AE-CP-007" in item for item in evidence["adapter_conformance_violations"])
