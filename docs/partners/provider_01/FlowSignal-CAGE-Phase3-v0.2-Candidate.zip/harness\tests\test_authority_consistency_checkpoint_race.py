from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path
from threading import Barrier, Event, RLock

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import temporary_authority_consistency_checkpoint
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


class CoordinatedAtomicCheckpoint:
    """Monotonic checkpoint that exposes the read-before-observe race deterministically.

    Both replicas first observe an empty checkpoint. Version 3 is then committed
    before version 2. The version-2 observe call correctly returns 3 and never
    lowers the shared floor. The runtime must still refuse the stale v2 decision.
    """

    def __init__(self):
        self._read_barrier = Barrier(2)
        self._v3_observed = Event()
        self._lock = RLock()
        self._highest = None
        self._digests = {}

    def get_verified_digest(self, source: str, authority_id: str, version: int):
        return None

    def get_highest_verified_version(self, source: str, authority_id: str):
        self._read_barrier.wait(timeout=5)
        return None

    def observe_verified_version(self, source: str, authority_id: str, version: int, *, content_digest=None):
        if version == 2:
            self._v3_observed.wait(timeout=5)
        with self._lock:
            if content_digest is not None:
                existing = self._digests.get((source, authority_id, version))
                if existing is not None and existing != content_digest:
                    raise ValueError("verified authority version is already bound to different content")
                self._digests[(source, authority_id, version)] = content_digest
            if self._highest is None or version > self._highest:
                self._highest = version
            current = self._highest
        if version == 3:
            self._v3_observed.set()
        return current


def test_attack007_concurrent_newer_version_must_invalidate_older_inflight_allow():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None

    active_v2 = replace(base, lifecycle_status="ACTIVE", version=2)
    revoked_v3 = replace(base, lifecycle_status="REVOKED", version=3)
    checkpoint = CoordinatedAtomicCheckpoint()

    with temporary_authority_consistency_checkpoint(checkpoint):
        with ThreadPoolExecutor(max_workers=2) as pool:
            older_future = pool.submit(
                evaluate_delegated_authority,
                request,
                approval_id=APPROVAL_ID,
                authority_evidence_adapter=SignedRecordAdapter(active_v2),
            )
            newer_future = pool.submit(
                evaluate_delegated_authority,
                request,
                approval_id=APPROVAL_ID,
                authority_evidence_adapter=SignedRecordAdapter(revoked_v3),
            )
            older_response, older_receipt = older_future.result(timeout=10)
            newer_response, _ = newer_future.result(timeout=10)

    assert newer_response.decision == "REFUSE"

    # Security expectation: once the atomic observe reports that a higher
    # version already won the concurrent race, the older in-flight authority
    # record is no longer usable. The reference path conservatively treats that
    # as inability to establish distributed consistency and fails closed.
    assert older_response.decision == "REFUSE"
    assert older_response.reason_code == "AUTHORITY_CONSISTENCY_CHECKPOINT_UNAVAILABLE"

    evidence = next(
        item for item in older_receipt.evidence_references
        if item["type"] == "delegated_authority_state"
    )
    assert evidence["consistency_checkpoint"] == "UNAVAILABLE"
    assert evidence["status"] == "UNKNOWN"
