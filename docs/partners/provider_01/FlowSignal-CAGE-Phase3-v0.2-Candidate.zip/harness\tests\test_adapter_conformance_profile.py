from dataclasses import replace
from datetime import datetime, timedelta, timezone

from app.adapter_conformance import validate_authority_evidence_result
from app.engines.authority_evidence_adapter import AuthorityEvidenceResult, ReferenceAuthorityStoreAdapter
from app.engines.authority_store import AuthorityProvenance, AuthorityStateRecord, get_authority_record


AUTHORITY_ID = "MANDATE-TREASURY-001"
NOW = datetime(2026, 8, 28, 11, 0, tzinfo=timezone.utc)


def _base_result():
    return ReferenceAuthorityStoreAdapter().acquire(AUTHORITY_ID)


def test_aecp001_reference_adapter_satisfies_positive_profile():
    result = _base_result()
    outcome = validate_authority_evidence_result(
        result,
        requested_authority_id=AUTHORITY_ID,
        evaluated_at=NOW,
        max_evidence_age_seconds=86400,
    )
    assert outcome.passed is True
    assert outcome.violations == ()


def test_aecp002_available_record_must_match_requested_authority_and_have_source_identity():
    result = _base_result()
    broken = replace(result, authority_id="OTHER", evidence_source="")
    outcome = validate_authority_evidence_result(broken, requested_authority_id=AUTHORITY_ID)
    assert outcome.passed is False
    assert any(v.startswith("AE-CP-001") for v in outcome.violations)
    assert any(v.startswith("AE-CP-002") for v in outcome.violations)


def test_aecp003_malformed_available_record_is_rejected_before_trust():
    record = get_authority_record(AUTHORITY_ID)
    assert record is not None
    malformed = replace(
        record,
        principal_id="",
        delegate_id="",
        permitted_consequence_classes=(),
        lifecycle_status="",
        version=0,
        max_amount=-1.0,
    )
    result = AuthorityEvidenceResult(AUTHORITY_ID, malformed, "AVAILABLE", "source-x", "adapter-x")
    outcome = validate_authority_evidence_result(result, requested_authority_id=AUTHORITY_ID)
    assert outcome.passed is False
    ids = {v.split()[0] for v in outcome.violations}
    assert {"AE-CP-007", "AE-CP-008", "AE-CP-009", "AE-CP-010", "AE-CP-012"}.issubset(ids)


def test_aecp004_stale_evidence_is_rejected_when_freshness_bound_is_declared():
    record = get_authority_record(AUTHORITY_ID)
    assert record is not None
    stale_record = replace(
        record,
        provenance=replace(record.provenance, observed_at=NOW - timedelta(hours=25)),
    )
    result = AuthorityEvidenceResult(AUTHORITY_ID, stale_record, "AVAILABLE", "source-x", "adapter-x")
    outcome = validate_authority_evidence_result(
        result,
        requested_authority_id=AUTHORITY_ID,
        evaluated_at=NOW,
        max_evidence_age_seconds=86400,
    )
    assert outcome.passed is False
    assert "AE-CP-014 authority evidence is stale" in outcome.violations


def test_aecp005_non_available_states_cannot_smuggle_in_active_record():
    record = get_authority_record(AUTHORITY_ID)
    assert record is not None
    for status, requirement in [
        ("NOT_FOUND", "AE-CP-018"),
        ("UNAVAILABLE", "AE-CP-016"),
        ("CONFLICT", "AE-CP-017"),
    ]:
        result = AuthorityEvidenceResult(AUTHORITY_ID, record, status, "source-x", "adapter-x")
        outcome = validate_authority_evidence_result(result, requested_authority_id=AUTHORITY_ID)
        assert outcome.passed is False
        assert any(v.startswith(requirement) for v in outcome.violations)


def test_aecp006_unknown_status_fails_conformance():
    result = AuthorityEvidenceResult(AUTHORITY_ID, None, "MAYBE", "source-x", "adapter-x")
    outcome = validate_authority_evidence_result(result, requested_authority_id=AUTHORITY_ID)
    assert outcome.passed is False
    assert "AE-CP-019 unknown source status" in outcome.violations


def test_aecp007_inverted_effective_window_and_naive_provenance_are_rejected():
    record = get_authority_record(AUTHORITY_ID)
    assert record is not None
    bad = replace(
        record,
        effective_from=datetime(2026, 9, 1, tzinfo=timezone.utc),
        effective_until=datetime(2026, 8, 1, tzinfo=timezone.utc),
        provenance=AuthorityProvenance(
            source="source-x",
            source_record_id="record-x",
            observed_at=datetime(2026, 8, 28, 11, 0),
        ),
    )
    result = AuthorityEvidenceResult(AUTHORITY_ID, bad, "AVAILABLE", "source-x", "adapter-x")
    outcome = validate_authority_evidence_result(result, requested_authority_id=AUTHORITY_ID)
    assert outcome.passed is False
    assert any(v.startswith("AE-CP-011") for v in outcome.violations)
    assert any(v.startswith("AE-CP-013") for v in outcome.violations)


def test_aecp008_available_requires_record_and_acquisition_layer():
    result = AuthorityEvidenceResult(AUTHORITY_ID, None, "AVAILABLE", "source-x", "")
    outcome = validate_authority_evidence_result(result, requested_authority_id=AUTHORITY_ID)
    assert outcome.passed is False
    assert any(v.startswith("AE-CP-004") for v in outcome.violations)
    assert any(v.startswith("AE-CP-005") for v in outcome.violations)
