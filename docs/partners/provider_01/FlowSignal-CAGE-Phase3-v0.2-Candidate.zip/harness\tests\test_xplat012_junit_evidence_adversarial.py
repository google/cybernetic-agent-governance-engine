from pathlib import Path

from app.junit_evidence import observed_evidence_from_junit


def _write(tmp_path: Path, body: str) -> Path:
    path = tmp_path / "results.xml"
    path.write_text(f"<testsuite>{body}</testsuite>", encoding="utf-8")
    return path


def test_xplat012_exact_passing_evidence_token_counts(tmp_path):
    path = _write(tmp_path, '<testcase classname="tests.test_contract" name="test_xplat004_valid_allow"/>')
    assert observed_evidence_from_junit(path, {"XPLAT-004"}) == {"XPLAT-004"}


def test_xplat012_failed_skipped_and_errored_mapped_tests_do_not_count(tmp_path):
    path = _write(tmp_path, '''
        <testcase classname="tests.test_contract" name="test_xplat004_failed"><failure/></testcase>
        <testcase classname="tests.test_contract" name="test_xplat004_skipped"><skipped/></testcase>
        <testcase classname="tests.test_contract" name="test_xplat004_error"><error/></testcase>
    ''')
    assert observed_evidence_from_junit(path, {"XPLAT-004"}) == set()


def test_xplat012_unrelated_name_containing_token_as_substring_does_not_count(tmp_path):
    path = _write(tmp_path, '<testcase classname="tests.test_fake" name="test_notxplat004_but_contains_text"/>')
    assert observed_evidence_from_junit(path, {"XPLAT-004"}) == set()


def test_xplat012_distinct_numeric_evidence_ids_do_not_alias(tmp_path):
    path = _write(tmp_path, '<testcase classname="tests.test_contract" name="test_da015_unavailable"/>')
    assert observed_evidence_from_junit(path, {"DA-015", "DA-0150"}) == {"DA-015"}
