from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import (
    InMemoryAuthorityConsistencyCheckpoint,
    temporary_authority_consistency_checkpoint,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def _attempt(request, attempted_at):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=attempted_at,
    )


def _evaluate(request, record, determined_at):
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authority_consistency_checkpoint(InMemoryAuthorityConsistencyCheckpoint()):
            return evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
                sealed_at=determined_at,
                authority_evidence_adapter=SignedRecordAdapter(record),
                authority_evidence_max_age_seconds=300,
            )


def test_attack019_screening_freshness_can_be_earliest_horizon():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None
    determined_at = datetime(2026, 8, 28, 12, 0, 0, tzinfo=timezone.utc)

    record = replace(
        base,
        effective_until=determined_at + timedelta(seconds=20),
        provenance=replace(base.provenance, observed_at=determined_at),
    )
    request = replace(
        request,
        screening_captured_at=determined_at - timedelta(seconds=55),
        screening_max_age_seconds=60,
        mandate_valid_until=determined_at + timedelta(seconds=10),
        requested_execution_time=determined_at,
    )
    expected_horizon = determined_at + timedelta(seconds=5)

    response, receipt = _evaluate(request, record, determined_at)
    assert response.decision == "ALLOW"
    assert receipt.valid_until is not None
    assert receipt.valid_until <= expected_horizon

    result = validate_execution(receipt, _attempt(request, determined_at + timedelta(seconds=6)))
    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_DETERMINATION_EXPIRED"


def test_attack019_mandate_expiry_can_be_earliest_horizon():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None
    determined_at = datetime(2026, 8, 28, 12, 0, 0, tzinfo=timezone.utc)

    record = replace(
        base,
        effective_until=determined_at + timedelta(seconds=30),
        provenance=replace(base.provenance, observed_at=determined_at),
    )
    request = replace(
        request,
        screening_captured_at=determined_at,
        screening_max_age_seconds=60,
        mandate_valid_until=determined_at + timedelta(seconds=4),
        requested_execution_time=determined_at,
    )
    expected_horizon = determined_at + timedelta(seconds=4)

    response, receipt = _evaluate(request, record, determined_at)
    assert response.decision == "ALLOW"
    assert receipt.valid_until is not None
    assert receipt.valid_until <= expected_horizon


def test_attack019_authority_effective_until_can_be_earliest_horizon():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None
    determined_at = datetime(2026, 8, 28, 12, 0, 0, tzinfo=timezone.utc)

    record = replace(
        base,
        effective_until=determined_at + timedelta(seconds=3),
        provenance=replace(base.provenance, observed_at=determined_at),
    )
    request = replace(
        request,
        screening_captured_at=determined_at,
        screening_max_age_seconds=60,
        mandate_valid_until=determined_at + timedelta(seconds=40),
        requested_execution_time=determined_at,
    )
    expected_horizon = determined_at + timedelta(seconds=3)

    response, receipt = _evaluate(request, record, determined_at)
    assert response.decision == "ALLOW"
    assert receipt.valid_until is not None
    assert receipt.valid_until <= expected_horizon
