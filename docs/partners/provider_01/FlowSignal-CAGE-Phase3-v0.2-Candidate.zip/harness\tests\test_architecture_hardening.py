from datetime import datetime
from pathlib import Path

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_evidence_adapter import AuthorityEvidenceConflict
from app.engines.authority_store import temporary_authoritative_mandate_status
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from app.engines.receipt_integrity import verify_receipt_hmac
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


class ConflictingAuthorityAdapter:
    def acquire(self, _authority_id: str):
        raise AuthorityEvidenceConflict("conflicting authoritative sources")


def _execution_attempt(request):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=datetime.fromisoformat("2026-08-10T09:15:30+00:00"),
    )


def _evidence(receipt, evidence_type):
    return next(item for item in receipt.evidence_references if item["type"] == evidence_type)


def test_arch001_approval_is_first_class_and_does_not_mutate_mandate_state():
    request = load_scenario(AP001)
    with temporary_approval_status(APPROVAL_ID, "WITHDRAWN"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            response, receipt = evaluate_delegated_authority(request, approval_id=APPROVAL_ID)
            assert response.decision == "REFUSE"
            assert response.reason_code == "APPROVAL_NOT_CURRENT"
            assert verify_receipt_hmac(receipt) is True
            approval_check = next(check for check in receipt.checks if check.name == "approval_current")
            mandate_check = next(check for check in receipt.checks if check.name == "mandate_active")
            assert approval_check.passed is False
            assert mandate_check.passed is True
            assert _evidence(receipt, "delegated_authority_state")["status"] == "ACTIVE"
            assert _evidence(receipt, "approval_state")["status"] == "WITHDRAWN"
            gateway = validate_execution(receipt, _execution_attempt(request))
            assert gateway.status == "BLOCKED"
            assert gateway.reason_code == "NO_APPLICABLE_ALLOW"


def test_arch002_non_current_approval_cannot_be_downgraded_to_escalate_by_authority_uncertainty():
    request = load_scenario(AP001)
    with temporary_approval_status(APPROVAL_ID, "WITHDRAWN"):
        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=ConflictingAuthorityAdapter(),
            authority_resolution_path="Route to mandate authority owner",
        )
    assert response.decision == "REFUSE"
    assert response.reason_code == "APPROVAL_NOT_CURRENT"
    assert verify_receipt_hmac(receipt) is True
    assert _evidence(receipt, "delegated_authority_state")["source_status"] == "CONFLICT"


def test_da010_conflicting_authoritative_evidence_escalates_only_with_resolution_path():
    request = load_scenario(AP001)
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=ConflictingAuthorityAdapter(),
            authority_resolution_path="Route to mandate authority owner",
        )
    assert response.decision == "ESCALATE"
    assert response.reason_code == "AUTHORITATIVE_EVIDENCE_CONFLICT"
    assert response.required_action == "Route to mandate authority owner"
    assert verify_receipt_hmac(receipt) is True
    authority_evidence = _evidence(receipt, "delegated_authority_state")
    assert authority_evidence["status"] == "UNKNOWN"
    assert authority_evidence["source_status"] == "CONFLICT"
    gateway = validate_execution(receipt, _execution_attempt(request))
    assert gateway.status == "BLOCKED"
    assert gateway.reason_code == "NO_APPLICABLE_ALLOW"


def test_da010_conflicting_authoritative_evidence_without_resolution_path_refuses():
    request = load_scenario(AP001)
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=ConflictingAuthorityAdapter(),
        )
    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_NOT_ESTABLISHED"
    assert verify_receipt_hmac(receipt) is True
    authority_evidence = _evidence(receipt, "delegated_authority_state")
    assert authority_evidence["source_status"] == "CONFLICT"
    assert authority_evidence["status"] == "UNKNOWN"
