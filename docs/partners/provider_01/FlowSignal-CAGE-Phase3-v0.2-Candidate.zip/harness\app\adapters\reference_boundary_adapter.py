from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any

from fastapi.encoders import jsonable_encoder
from fastapi.testclient import TestClient

from app.api import app
from app.engines.execution_gateway import ExecutionAttempt, GatewayResult, validate_execution
from app.engines.financial_types import AuthorityReceipt, FinancialCheck


@dataclass
class AdapterDecision:
    status: str
    reason_code: str
    determination: str | None = None
    authority_receipt: AuthorityReceipt | None = None
    gateway_result: GatewayResult | None = None
    required_action: str | None = None


class ReferenceExecutionBoundaryAdapter:
    """Vendor-neutral reference adapter from an external execution boundary to FlowSignal."""

    def __init__(self, *, platform: str):
        self.platform = platform
        self._client = TestClient(app)

    @staticmethod
    def _receipt_from_payload(payload: dict[str, Any]) -> AuthorityReceipt:
        checks = [FinancialCheck(**check) for check in payload.get("checks", [])]
        return AuthorityReceipt(
            id=payload["id"],
            scenario_id=payload["scenario_id"],
            decision=payload["decision"],
            reason_code=payload["reason_code"],
            sealed_at=datetime.fromisoformat(payload["sealed_at"]),
            valid_until=(
                datetime.fromisoformat(payload["valid_until"])
                if payload.get("valid_until") is not None
                else None
            ),
            action_binding_hash=payload["action_binding_hash"],
            authority_state_version=payload["authority_state_version"],
            receipt_hmac=payload["receipt_hmac"],
            request_snapshot=payload["request_snapshot"],
            checks=checks,
            evidence_references=payload.get("evidence_references", []),
        )

    def determine_and_enforce(
        self,
        *,
        request,
        approval_id: str,
        execution_id: str,
        attempted_at: datetime,
        evidence_references: list[dict[str, Any]] | None = None,
    ) -> AdapterDecision:
        payload = jsonable_encoder(request)
        payload.update(
            {
                "approval_id": approval_id,
                "platform": self.platform,
                "execution_id": execution_id,
                "evidence_references": evidence_references or [],
            }
        )

        try:
            response = self._client.post("/authority/determine", json=payload)
        except Exception:
            return AdapterDecision(
                status="BLOCKED",
                reason_code="AUTHORITY_DETERMINATION_UNAVAILABLE",
            )

        if response.status_code != 200:
            return AdapterDecision(
                status="BLOCKED",
                reason_code="AUTHORITY_DETERMINATION_INVALID_RESPONSE",
            )

        body = response.json()
        determination = body.get("determination")
        if determination not in {"ALLOW", "ESCALATE", "REFUSE"}:
            return AdapterDecision(
                status="BLOCKED",
                reason_code="AUTHORITY_DETERMINATION_UNKNOWN",
                determination=determination,
            )

        receipt_payload = body.get("authority_receipt")
        if not isinstance(receipt_payload, dict):
            return AdapterDecision(
                status="BLOCKED",
                reason_code="AUTHORITY_RECEIPT_MISSING",
                determination=determination,
                required_action=body.get("required_action"),
            )

        try:
            receipt = self._receipt_from_payload(receipt_payload)
        except Exception:
            return AdapterDecision(
                status="BLOCKED",
                reason_code="AUTHORITY_RECEIPT_MALFORMED",
                determination=determination,
                required_action=body.get("required_action"),
            )

        if determination != "ALLOW":
            return AdapterDecision(
                status="BLOCKED",
                reason_code="NO_APPLICABLE_ALLOW",
                determination=determination,
                authority_receipt=receipt,
                required_action=body.get("required_action"),
            )

        attempt = ExecutionAttempt(
            actor_id=request.actor_id,
            principal_id=request.principal_id,
            action=request.action,
            target=request.target,
            amount=request.amount,
            currency=request.currency,
            source_account=request.source_account,
            beneficiary=request.beneficiary,
            purpose=request.purpose,
            mandate_id=request.mandate_id,
            attempted_at=attempted_at,
        )
        gateway = validate_execution(receipt, attempt)
        return AdapterDecision(
            status=gateway.status,
            reason_code=gateway.reason_code,
            determination=determination,
            authority_receipt=receipt,
            gateway_result=gateway,
        )
