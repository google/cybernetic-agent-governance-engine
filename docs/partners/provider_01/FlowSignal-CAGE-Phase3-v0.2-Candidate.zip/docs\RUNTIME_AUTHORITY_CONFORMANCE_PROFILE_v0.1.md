# Runtime Authority Conformance Profile v0.1

Status: Private engineering conformance profile

Branch: `runtime-authority-vnext`

Purpose: define the minimum behaviour an external execution boundary integration must satisfy to be considered compatible with the FlowSignal Runtime Authority reference architecture.

This profile is vendor-neutral. It does not assert conformance by Google CAGE, AWS, Microsoft or any other third-party platform.

## 1. Architectural invariant

> No consequential execution may occur unless the external execution boundary possesses a valid FlowSignal Authority Receipt bound to the exact consequence being executed and to sufficiently current authority state.

The responsibility split is normative:

- FlowSignal determines authority.
- The adapter transports the request and response.
- The external execution boundary validates and enforces.
- The consequence executor acts only after the boundary has issued an execution permit.

## 2. Normative terminology

The words MUST, MUST NOT, SHOULD and MAY are used in their usual normative sense.

## 3. Required request behaviour

A conforming adapter MUST:

RA-CP-001. Intercept the proposed consequence before it can bind or execute.

RA-CP-002. Submit the exact proposed consequence to `POST /authority/determine`, including actor, principal, mandate reference, action, target, amount, currency, source account, beneficiary, purpose, execution context and relevant presented evidence.

RA-CP-003. Preserve caller- or platform-presented authority assertions as evidence only. It MUST NOT treat them as authoritative delegated-authority state.

RA-CP-004. Include a platform identifier and execution identifier so the consuming boundary can correlate the determination with its own attempted execution.

## 4. Required response handling

A conforming adapter MUST:

RA-CP-005. Accept only the defined determinations `ALLOW`, `ESCALATE` or `REFUSE`. Unknown or malformed determinations MUST fail closed.

RA-CP-006. Require an Authority Receipt for any determination response that is to be processed by the boundary. A missing or malformed receipt MUST fail closed.

RA-CP-007. Treat `ESCALATE` and `REFUSE` as non-executable outcomes. Neither may produce an execution permit.

RA-CP-008. Treat `ALLOW` as necessary but not sufficient for execution. The boundary MUST independently validate the returned Authority Receipt before producing a permit.

## 5. Mandatory Authority Receipt validation

Before an execution permit may exist, the external execution boundary MUST validate:

RA-CP-009. Receipt integrity. Any integrity failure or HMAC/signature mismatch MUST block execution.

RA-CP-010. Authority-state currency. If current authoritative state has advanced beyond the sealed receipt version, execution MUST be blocked and re-evaluation required.

RA-CP-011. Receipt validity window. An expired ALLOW MUST NOT be executable.

RA-CP-012. Exact consequence binding. The attempted execution MUST match the action binding sealed into the Authority Receipt. Any actor, principal, action, target, amount, currency, source account, beneficiary, purpose or mandate substitution that changes the binding MUST block execution.

RA-CP-013. Receipt replay protection. A vNext Authority Receipt MUST be single-use at the execution boundary. A second presentation MUST be blocked and MUST NOT produce a second permit.

## 6. Failure behaviour

RA-CP-014. If FlowSignal is unavailable, times out, raises an error or cannot return a usable determination, the adapter/boundary MUST fail closed. No permit path may exist.

RA-CP-015. If the authoritative authority source is unavailable but FlowSignal returns `ESCALATE` with a defined resolution path, the boundary MUST remain blocked pending resolution.

RA-CP-016. If the authoritative authority source is unavailable and no resolvable path is established, a `REFUSE` remains non-executable.

RA-CP-017. Malformed or incomplete FlowSignal responses MUST NOT degrade into platform-local permission.

## 7. Capability separation

RA-CP-018. The FlowSignal Authority Core MUST NOT be relied upon to mint an external execution permit.

RA-CP-019. The FlowSignal Authority Core MUST NOT be given direct consequence-execution capability by the adapter contract.

RA-CP-020. Permit issuance MUST remain an enforcement-boundary responsibility after successful Authority Receipt validation.

RA-CP-021. Consequence formation MUST remain downstream of permit issuance and consumption.

## 8. Platform independence

RA-CP-022. Platform identity or execution correlation data MUST NOT silently alter authority semantics for an otherwise identical consequence and authority state.

RA-CP-023. Two conforming platform adapters presented with the same consequence and same authoritative state SHOULD obtain equivalent determination semantics and equivalent consequence binding, while retaining their own platform/execution correlation metadata.

RA-CP-024. Platform policy `PERMIT`, approval state or agent assertion MUST NOT override a FlowSignal `REFUSE`.

## 9. Evidence requirements

A conforming integration SHOULD preserve sufficient evidence to reconstruct:

- caller-presented authority assertion;
- independently obtained delegated-authority state;
- approval state where relevant;
- authority-state version;
- exact consequence binding;
- determination and reason code;
- validity window;
- required resolution path for `ESCALATE` where applicable;
- boundary validation result;
- execution permit identifier/signature if issued;
- final consequence outcome where the test harness models it.

## 10. Reference proof mapping

| Requirement area | Reference proof |
| --- | --- |
| Service contract / no execution capability | XPLAT-001 |
| Same semantics across different reference platforms | XPLAT-002 |
| Same REFUSE semantics across different reference platforms | XPLAT-003 |
| Adapter hand-off, external validation and fail-closed behaviour | XPLAT-004 |
| Malformed/tampered/stale/mismatched/replayed receipt resistance | XPLAT-005 |
| Caller assertion cannot override authoritative revocation | IND-001 |
| Approval cannot manufacture authority | IND-002 |
| Platform policy PERMIT cannot override REFUSE | IND-003 |
| Authority core cannot directly mint/execute in reference harness | IND-004 |
| Authority changes between determination and execution | DA-011 |
| Exact consequence substitution | DA-012 |
| Authority Receipt replay | DA-013 |
| FlowSignal unavailable | DA-014 |
| Authority-source unavailability semantics | DA-015 |
| Approval remains valid while delegated authority is revoked | DA-016 |

## 11. Conformance claim boundary

A platform or adapter MUST NOT be described as conformant solely because it can call `/authority/determine`.

For this reference profile, conformance requires evidence that all MUST requirements applicable to the integration have been exercised and passed, including hostile/failure cases.

A passing reference-harness conformance profile does not establish production certification, universal non-bypassability, production IAM/KMS/HSM isolation, distributed transaction guarantees, legal compliance, regulatory approval, real payment-rail prevention or third-party endorsement.

## 12. Current reference status

The private vNext harness currently demonstrates the behaviours mapped above. The authoritative status of a future real platform integration must be established by running this profile against that integration rather than inferring compatibility from architectural similarity.
