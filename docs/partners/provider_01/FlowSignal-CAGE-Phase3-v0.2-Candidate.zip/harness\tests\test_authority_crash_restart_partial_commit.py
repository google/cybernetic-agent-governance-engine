from dataclasses import replace
from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import (
    InMemoryAuthorityConsistencyCheckpoint,
    InMemoryAuthorityContinuityAnchor,
    temporary_authority_consistency_checkpoint,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def test_attack013_crash_restart_partial_commit_requires_recovery_before_allow():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None
    active_v5 = replace(base, lifecycle_status="ACTIVE", version=5)

    # Simulate hard crash after checkpoint commit but before anchor update.
    persisted_checkpoint = InMemoryAuthorityConsistencyCheckpoint()
    persisted_anchor = InMemoryAuthorityContinuityAnchor()
    persisted_checkpoint.observe_verified_version(SOURCE, request.mandate_id, 5)
    persisted_anchor.observe_anchored_version(SOURCE, request.mandate_id, 4)

    # Fresh runtime starts against the partially committed persistence state.
    with temporary_authority_consistency_checkpoint(
        persisted_checkpoint,
        continuity_anchor=persisted_anchor,
    ):
        response, _ = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=SignedRecordAdapter(active_v5),
        )

    # Crash recovery must converge the anchor before ALLOW survives.
    assert persisted_anchor.get_highest_anchored_version(SOURCE, request.mandate_id) == 5
    assert response.decision == "ALLOW"
