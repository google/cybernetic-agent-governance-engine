from __future__ import annotations
import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timezone

from app.engines.approval_store import get_approval_snapshot
from app.engines.authority_receipt_use_store import claim_authority_receipt_once
from app.engines.financial_types import AuthorityReceipt
from app.engines.receipt_integrity import verify_receipt_hmac
from app.engines.authority_store import get_authority_state_version
from app.engines.mutable_evidence_state import (
    MutableEvidenceStateUnavailable,
    get_mutable_evidence_snapshot,
)
from app.engines.permit_authority import (
    ExecutionPermit,
    _GATEWAY_MINT_CAPABILITY,
    issue_execution_permit,
)

@dataclass
class ExecutionAttempt:
    actor_id: str
    principal_id: str
    action: str
    target: str
    amount: float
    currency: str
    source_account: str
    beneficiary: str
    purpose: str
    mandate_id: str
    attempted_at: datetime


@dataclass
class GatewayResult:
    status: str
    reason_code: str
    authority_receipt_id: str
    expected_action_binding_hash: str
    attempted_action_binding_hash: str
    execution_permit: ExecutionPermit | None = None


def _aware(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        return dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _is_vnext_delegated_authority_receipt(receipt: AuthorityReceipt) -> bool:
    return any(
        evidence.get("type") == "delegated_authority_state"
        for evidence in receipt.evidence_references
        if isinstance(evidence, dict)
    )


def _approval_state_is_current(receipt: AuthorityReceipt) -> bool:
    for evidence in receipt.evidence_references:
        if not isinstance(evidence, dict) or evidence.get("type") != "approval_state":
            continue
        approval_id = evidence.get("approval_id")
        if not approval_id:
            continue
        current_status, current_version = get_approval_snapshot(approval_id)
        expected_status = evidence.get("status")
        expected_version = evidence.get("state_version")
        if current_status != expected_status:
            return False
        if expected_version is not None and current_version != expected_version:
            return False
    return True


def _mutable_supporting_evidence_is_current(receipt: AuthorityReceipt) -> bool:
    for evidence in receipt.evidence_references:
        if not isinstance(evidence, dict):
            continue
        if evidence.get("type") != "sanctions_screening":
            continue
        expected_version = evidence.get("mutable_state_version")
        source = evidence.get("source")
        if expected_version is None or not source:
            continue
        current_version, current = get_mutable_evidence_snapshot(source)
        if not current or current_version != expected_version:
            return False
    return True


def action_binding_hash(attempt: ExecutionAttempt) -> str:
    payload = {
        "actor_id": attempt.actor_id,
        "principal_id": attempt.principal_id,
        "action": attempt.action,
        "target": attempt.target,
        "amount": attempt.amount,
        "currency": attempt.currency,
        "source_account": attempt.source_account,
        "beneficiary": attempt.beneficiary,
        "purpose": attempt.purpose,
        "mandate_id": attempt.mandate_id,
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _blocked(receipt, attempted_hash, reason_code: str) -> GatewayResult:
    return GatewayResult(
        status="BLOCKED",
        reason_code=reason_code,
        authority_receipt_id=receipt.id,
        expected_action_binding_hash=receipt.action_binding_hash,
        attempted_action_binding_hash=attempted_hash,
    )


def validate_execution(receipt: AuthorityReceipt, attempt: ExecutionAttempt) -> GatewayResult:
    attempted_hash = action_binding_hash(attempt)
    if not verify_receipt_hmac(receipt):
        return _blocked(receipt, attempted_hash, "AUTHORITY_RECEIPT_INTEGRITY_INVALID")

    current_authority_state_version = get_authority_state_version()
    if receipt.authority_state_version != current_authority_state_version:
        return _blocked(receipt, attempted_hash, "AUTHORITY_STATE_STALE_REEVALUATION_REQUIRED")
    if receipt.decision != "ALLOW":
        return _blocked(receipt, attempted_hash, "NO_APPLICABLE_ALLOW")
    if receipt.valid_until is None or _aware(attempt.attempted_at) > _aware(receipt.valid_until):
        return _blocked(receipt, attempted_hash, "AUTHORITY_DETERMINATION_EXPIRED")
    if not _approval_state_is_current(receipt):
        return _blocked(receipt, attempted_hash, "APPROVAL_STATE_STALE_REEVALUATION_REQUIRED")
    try:
        mutable_evidence_current = _mutable_supporting_evidence_is_current(receipt)
    except MutableEvidenceStateUnavailable:
        return _blocked(receipt, attempted_hash, "AUTHORITY_SUPPORTING_EVIDENCE_STATE_UNAVAILABLE")
    if not mutable_evidence_current:
        return _blocked(receipt, attempted_hash, "AUTHORITY_SUPPORTING_EVIDENCE_INVALIDATED")
    if attempted_hash != receipt.action_binding_hash:
        return _blocked(receipt, attempted_hash, "ACTION_BINDING_MISMATCH")

    if _is_vnext_delegated_authority_receipt(receipt) and not claim_authority_receipt_once(receipt.id):
        return _blocked(receipt, attempted_hash, "AUTHORITY_RECEIPT_REPLAY")

    permit = issue_execution_permit(
        authority_receipt_id=receipt.id,
        action_binding_hash=attempted_hash,
        authority_state_version=current_authority_state_version,
        valid_until=_aware(receipt.valid_until).isoformat(),
        mint_capability=_GATEWAY_MINT_CAPABILITY,
    )
    return GatewayResult(
        status="PERMITTED",
        reason_code="BOUND_ALLOW_VALID",
        authority_receipt_id=receipt.id,
        expected_action_binding_hash=receipt.action_binding_hash,
        attempted_action_binding_hash=attempted_hash,
        execution_permit=permit,
    )
