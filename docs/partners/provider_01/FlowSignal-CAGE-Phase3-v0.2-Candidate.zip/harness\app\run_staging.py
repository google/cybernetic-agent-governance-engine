"""Staging/production entrypoint.

Usage:
    python -m app.run_staging

All configuration comes from the environment (see app/settings.py and
.env.example). Running this with no TLS environment variables set starts a
plain-HTTP server for local development. Running it with
FLOWSIGNAL_TLS_CERTFILE / FLOWSIGNAL_TLS_KEYFILE / FLOWSIGNAL_TLS_CA_CERTS all
set enables mTLS: uvicorn enforces the TLS handshake itself, so a client
without a certificate trusted by the configured CA is rejected at the
transport layer, before any request reaches the application.
"""

from __future__ import annotations

import ssl
import sys

import uvicorn

from app.settings import load_settings


def main() -> None:
    settings = load_settings()

    ssl_kwargs = {}
    if settings.mtls_enabled:
        ssl_kwargs = {
            "ssl_certfile": settings.tls_certfile,
            "ssl_keyfile": settings.tls_keyfile,
            "ssl_ca_certs": settings.tls_ca_certs,
            "ssl_cert_reqs": (
                ssl.CERT_REQUIRED if settings.require_client_cert else ssl.CERT_OPTIONAL
            ),
        }
        print(
            f"Starting with mTLS enabled (client cert "
            f"{'REQUIRED' if settings.require_client_cert else 'optional'}), "
            f"CA bundle: {settings.tls_ca_certs}",
            file=sys.stderr,
        )
    else:
        print(
            "Starting WITHOUT TLS. This is suitable for local development only - "
            "the Phase 3 staging/GKE path requires mTLS.",
            file=sys.stderr,
        )

    uvicorn.run(
        "app.api:app",
        host=settings.host,
        port=settings.port,
        log_level=settings.log_level,
        **ssl_kwargs,
    )


if __name__ == "__main__":
    main()
