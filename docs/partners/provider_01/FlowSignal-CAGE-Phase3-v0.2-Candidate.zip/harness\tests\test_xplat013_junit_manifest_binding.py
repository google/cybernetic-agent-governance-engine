from datetime import datetime, timezone

from app.conformance_evidence import EvidenceProvenance, generate_conformance_evidence_report
from app.conformance_profile import RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1
from app.evidence_manifest import build_evidence_manifest, generate_ed25519_keypair_pem, verify_evidence_manifest

ALL_MAPPED_EVIDENCE = {e for requirement in RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1 for e in requirement.evidence_tests}


def _report():
    return generate_conformance_evidence_report(
        observed_evidence=ALL_MAPPED_EVIDENCE,
        subject="REFERENCE-BOUNDARY-CONFORMANCE",
        provenance=EvidenceProvenance(repository="grahamb-ai/flowsignal-agentic-payments-vnext", branch="runtime-authority-vnext", commit_sha="3" * 40, workflow_run_id="33190000000", workflow_run_attempt="1", profile_version="0.1"),
        generated_at=datetime(2026, 8, 28, 17, 0, tzinfo=timezone.utc),
    )


def test_xplat013_manifest_binds_exact_junit_bytes_and_counts():
    report = _report()
    report_json = report.to_json()
    report_markdown = report.to_markdown()
    junit = b'<testsuite><testcase name="test_xplat004_valid"/></testsuite>'
    counts = {"total": 1, "passed": 1, "failed": 0, "errors": 0, "skipped": 0}
    private_key, public_key = generate_ed25519_keypair_pem()
    manifest = build_evidence_manifest(report=report, report_json=report_json, report_markdown=report_markdown, private_key_pem=private_key, public_key_pem=public_key, junit_xml=junit, junit_counts=counts)

    assert manifest.manifest_version == "0.3"
    assert manifest.junit_xml_sha256 is not None
    assert manifest.junit_test_counts == counts
    assert verify_evidence_manifest(manifest=manifest, report_json=report_json, report_markdown=report_markdown, public_key_pem=public_key, junit_xml=junit, junit_counts=counts)

    assert not verify_evidence_manifest(manifest=manifest, report_json=report_json, report_markdown=report_markdown, public_key_pem=public_key, junit_xml=junit + b"tamper", junit_counts=counts)
    assert not verify_evidence_manifest(manifest=manifest, report_json=report_json, report_markdown=report_markdown, public_key_pem=public_key, junit_xml=junit, junit_counts={**counts, "passed": 0})
    assert not verify_evidence_manifest(manifest=manifest, report_json=report_json, report_markdown=report_markdown, public_key_pem=public_key)
