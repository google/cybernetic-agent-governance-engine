from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path
from threading import Barrier, RLock

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import temporary_authority_consistency_checkpoint
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


class CoordinatedSameVersionCheckpoint:
    """Expose the digest-binding race for two different signed records at one version."""

    def __init__(self):
        self._read_barrier = Barrier(2)
        self._observe_barrier = Barrier(2)
        self._lock = RLock()
        self._highest = None
        self._digests = {}

    def get_verified_digest(self, source: str, authority_id: str, version: int):
        self._read_barrier.wait(timeout=5)
        return None

    def get_highest_verified_version(self, source: str, authority_id: str):
        return None

    def observe_verified_version(self, source: str, authority_id: str, version: int, *, content_digest=None):
        self._observe_barrier.wait(timeout=5)
        with self._lock:
            key = (source, authority_id, version)
            if content_digest is not None:
                existing = self._digests.get(key)
                if existing is not None and existing != content_digest:
                    raise ValueError("verified authority version is already bound to different content")
                self._digests[key] = content_digest
            if self._highest is None or version > self._highest:
                self._highest = version
            return self._highest


def test_attack008_same_version_concurrent_equivocation_must_not_allow_both_meanings():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None

    active_v3 = replace(base, lifecycle_status="ACTIVE", version=3)
    revoked_v3 = replace(base, lifecycle_status="REVOKED", version=3)
    checkpoint = CoordinatedSameVersionCheckpoint()

    with temporary_authority_consistency_checkpoint(checkpoint):
        with ThreadPoolExecutor(max_workers=2) as pool:
            active_future = pool.submit(
                evaluate_delegated_authority,
                request,
                approval_id=APPROVAL_ID,
                authority_evidence_adapter=SignedRecordAdapter(active_v3),
            )
            revoked_future = pool.submit(
                evaluate_delegated_authority,
                request,
                approval_id=APPROVAL_ID,
                authority_evidence_adapter=SignedRecordAdapter(revoked_v3),
            )
            active_response, active_receipt = active_future.result(timeout=10)
            revoked_response, revoked_receipt = revoked_future.result(timeout=10)

    # Both records are source-authentic and both passed the empty pre-read.
    # Security requirement: the checkpoint must atomically bind version 3 to
    # only one digest. It is unacceptable for both competing meanings to be
    # treated as usable authority.
    decisions = {active_response.decision, revoked_response.decision}
    assert "ALLOW" not in decisions or decisions == {"ALLOW", "REFUSE"}
    assert not (active_response.decision == "ALLOW" and revoked_response.decision == "ALLOW")

    # More strongly, whichever competing observation loses the atomic digest
    # bind must fail closed and seal the checkpoint as unusable for that result.
    losing = None
    for response, receipt in ((active_response, active_receipt), (revoked_response, revoked_receipt)):
        if response.reason_code == "AUTHORITY_CONSISTENCY_CHECKPOINT_UNAVAILABLE":
            losing = receipt
            break
    assert losing is not None
    evidence = next(
        item for item in losing.evidence_references
        if item["type"] == "delegated_authority_state"
    )
    assert evidence["consistency_checkpoint"] == "UNAVAILABLE"
    assert evidence["status"] == "UNKNOWN"
