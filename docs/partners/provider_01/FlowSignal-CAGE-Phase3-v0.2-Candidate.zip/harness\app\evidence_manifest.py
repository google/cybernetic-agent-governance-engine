from __future__ import annotations

import base64
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
from typing import Mapping

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from app.conformance_evidence import ConformanceEvidenceReport


@dataclass(frozen=True)
class EvidenceManifest:
    manifest_version: str
    generated_at: str
    profile_version: str
    repository: str
    branch: str
    commit_sha: str
    workflow_run_id: str
    workflow_run_attempt: str
    subject: str
    overall_status: str
    report_json_sha256: str
    report_markdown_sha256: str
    artifact_zip_sha256: str | None
    signature_algorithm: str
    signer_key_id: str
    signature_base64: str
    junit_xml_sha256: str | None = None
    junit_test_counts: dict[str, int] | None = None

    def unsigned_dict(self) -> dict:
        payload = asdict(self)
        payload.pop("signature_base64")
        return payload

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=True)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def _canonical_json(payload: Mapping) -> bytes:
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")


def generate_ed25519_keypair_pem() -> tuple[str, str]:
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")
    return private_pem, public_pem


def public_key_id(public_key_pem: str) -> str:
    public_key = serialization.load_pem_public_key(public_key_pem.encode("utf-8"))
    if not isinstance(public_key, Ed25519PublicKey):
        raise ValueError("public_key_pem must contain an Ed25519 public key")
    raw = public_key.public_bytes(encoding=serialization.Encoding.Raw, format=serialization.PublicFormat.Raw)
    return hashlib.sha256(raw).hexdigest()


def build_evidence_manifest(
    *,
    report: ConformanceEvidenceReport,
    report_json: str,
    report_markdown: str,
    private_key_pem: str,
    public_key_pem: str,
    artifact_zip_sha256: str | None = None,
    generated_at: datetime | None = None,
    junit_xml: bytes | None = None,
    junit_counts: Mapping[str, int] | None = None,
) -> EvidenceManifest:
    report.provenance.validate()
    private_key = serialization.load_pem_private_key(private_key_pem.encode("utf-8"), password=None)
    if not isinstance(private_key, Ed25519PrivateKey):
        raise ValueError("private_key_pem must contain an Ed25519 private key")
    signer_key_id = public_key_id(public_key_pem)
    timestamp = generated_at or datetime.now(timezone.utc)
    unsigned = {
        "manifest_version": "0.3",
        "generated_at": timestamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        "profile_version": report.provenance.profile_version,
        "repository": report.provenance.repository,
        "branch": report.provenance.branch,
        "commit_sha": report.provenance.commit_sha,
        "workflow_run_id": report.provenance.workflow_run_id,
        "workflow_run_attempt": report.provenance.workflow_run_attempt,
        "subject": report.subject,
        "overall_status": report.overall_status,
        "report_json_sha256": sha256_text(report_json),
        "report_markdown_sha256": sha256_text(report_markdown),
        "artifact_zip_sha256": artifact_zip_sha256,
        "signature_algorithm": "Ed25519",
        "signer_key_id": signer_key_id,
        "junit_xml_sha256": None if junit_xml is None else sha256_bytes(junit_xml),
        "junit_test_counts": None if junit_counts is None else dict(junit_counts),
    }
    signature = private_key.sign(_canonical_json(unsigned))
    return EvidenceManifest(**unsigned, signature_base64=base64.b64encode(signature).decode("ascii"))


def verify_evidence_manifest(
    *,
    manifest: EvidenceManifest,
    report_json: str,
    report_markdown: str,
    public_key_pem: str,
    artifact_zip_sha256: str | None = None,
    junit_xml: bytes | None = None,
    junit_counts: Mapping[str, int] | None = None,
) -> bool:
    if manifest.signature_algorithm != "Ed25519":
        return False
    if public_key_id(public_key_pem) != manifest.signer_key_id:
        return False
    if sha256_text(report_json) != manifest.report_json_sha256:
        return False
    if sha256_text(report_markdown) != manifest.report_markdown_sha256:
        return False
    if artifact_zip_sha256 is not None and artifact_zip_sha256 != manifest.artifact_zip_sha256:
        return False
    if manifest.junit_xml_sha256 is not None:
        if junit_xml is None or sha256_bytes(junit_xml) != manifest.junit_xml_sha256:
            return False
        if junit_counts is None or dict(junit_counts) != manifest.junit_test_counts:
            return False
    public_key = serialization.load_pem_public_key(public_key_pem.encode("utf-8"))
    if not isinstance(public_key, Ed25519PublicKey):
        return False
    try:
        public_key.verify(base64.b64decode(manifest.signature_base64), _canonical_json(manifest.unsigned_dict()))
    except (InvalidSignature, ValueError):
        return False
    return True
