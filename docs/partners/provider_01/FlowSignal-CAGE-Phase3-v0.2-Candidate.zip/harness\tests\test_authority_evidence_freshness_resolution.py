from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"
REFRESH_PATH = "refresh-authority-evidence"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def _stale_adapter(request):
    base = get_authority_record(request.mandate_id)
    assert base is not None
    evaluated_at = datetime(2026, 8, 28, 12, 0, 0, tzinfo=timezone.utc)
    stale_record = replace(
        base,
        provenance=replace(
            base.provenance,
            observed_at=evaluated_at - timedelta(minutes=30),
        ),
    )
    return evaluated_at, SignedRecordAdapter(stale_record)


def test_attack015_stale_authentic_evidence_with_refresh_path_escalates_never_allows():
    request = load_scenario(AP001)
    evaluated_at, adapter = _stale_adapter(request)

    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        sealed_at=evaluated_at,
        authority_evidence_adapter=adapter,
        authority_resolution_path=REFRESH_PATH,
        authority_evidence_max_age_seconds=60,
    )

    assert response.decision == "ESCALATE"
    assert response.reason_code == "AUTHORITY_EVIDENCE_STALE"
    assert response.required_action == REFRESH_PATH
    assert receipt.decision == "ESCALATE"


def test_attack016_stale_authentic_evidence_without_refresh_path_refuses():
    request = load_scenario(AP001)
    evaluated_at, adapter = _stale_adapter(request)

    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        sealed_at=evaluated_at,
        authority_evidence_adapter=adapter,
        authority_evidence_max_age_seconds=60,
    )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_EVIDENCE_STALE"
    assert response.required_action is None
    assert receipt.decision == "REFUSE"
