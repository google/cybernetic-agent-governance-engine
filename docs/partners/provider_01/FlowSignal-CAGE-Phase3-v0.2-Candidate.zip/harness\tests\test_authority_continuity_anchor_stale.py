from dataclasses import replace
from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import (
    InMemoryAuthorityConsistencyCheckpoint,
    InMemoryAuthorityContinuityAnchor,
    temporary_authority_consistency_checkpoint,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def test_attack011_checkpoint_ahead_of_stale_anchor_must_repair_anchor_before_allow():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None

    active_v5 = replace(base, lifecycle_status="ACTIVE", version=5)
    checkpoint = InMemoryAuthorityConsistencyCheckpoint()
    anchor = InMemoryAuthorityContinuityAnchor()

    # Simulate lag: checkpoint has already committed v5, continuity anchor only v3.
    checkpoint.observe_verified_version(SOURCE, request.mandate_id, 5)
    anchor.observe_anchored_version(SOURCE, request.mandate_id, 3)

    with temporary_authority_consistency_checkpoint(checkpoint, continuity_anchor=anchor):
        response, _ = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=SignedRecordAdapter(active_v5),
        )

    assert response.decision == "ALLOW"
    assert anchor.get_highest_anchored_version(SOURCE, request.mandate_id) == 5
