import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def test_xplat014_runtime_dependencies_are_exactly_pinned():
    requirements = (ROOT / "harness" / "requirements.txt").read_text(encoding="utf-8").splitlines()
    active = [line.strip() for line in requirements if line.strip() and not line.lstrip().startswith("#")]
    assert active
    assert all("==" in line for line in active), (
        "Runtime dependency inputs are not exactly pinned: " + ", ".join(active)
    )
    assert not any(">=" in line or "~=" in line for line in active)


def test_xplat014_security_relevant_github_actions_are_pinned_to_commit_sha():
    workflow = (ROOT / ".github" / "workflows" / "vnext-regression.yml").read_text(encoding="utf-8")
    uses = re.findall(r"^\s*uses:\s*([^\s]+)\s*$", workflow, flags=re.MULTILINE)
    assert uses
    for action in uses:
        assert re.search(r"@[0-9a-f]{40}$", action), f"GitHub Action is not commit-SHA pinned: {action}"
