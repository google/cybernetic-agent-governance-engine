from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
from typing import Iterable

from app.conformance_profile import RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1


@dataclass(frozen=True)
class EvidenceProvenance:
    repository: str
    branch: str
    commit_sha: str
    workflow_run_id: str
    workflow_run_attempt: str
    profile_version: str

    def validate(self) -> None:
        values = {
            "repository": self.repository,
            "branch": self.branch,
            "commit_sha": self.commit_sha,
            "workflow_run_id": self.workflow_run_id,
            "workflow_run_attempt": self.workflow_run_attempt,
            "profile_version": self.profile_version,
        }
        missing = [name for name, value in values.items() if not str(value).strip()]
        if missing:
            raise ValueError(
                "Conformance evidence provenance is incomplete: " + ", ".join(missing)
            )
        if len(self.commit_sha) != 40 or any(ch not in "0123456789abcdef" for ch in self.commit_sha.lower()):
            raise ValueError("commit_sha must be a full 40-character hexadecimal Git commit SHA")


@dataclass(frozen=True)
class RequirementEvidence:
    requirement_id: str
    summary: str
    status: str
    required_evidence: tuple[str, ...]
    observed_evidence: tuple[str, ...]
    missing_evidence: tuple[str, ...]


@dataclass(frozen=True)
class ConformanceEvidenceReport:
    profile: str
    generated_at: str
    subject: str
    provenance: EvidenceProvenance
    overall_status: str
    requirements_passed: int
    requirements_total: int
    requirements: tuple[RequirementEvidence, ...]
    claim_boundary: str

    def to_dict(self) -> dict:
        result = asdict(self)
        result["requirements"] = [asdict(item) for item in self.requirements]
        return result

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2, sort_keys=True)

    def to_markdown(self) -> str:
        lines = [
            "# Runtime Authority Conformance Evidence Report",
            "",
            f"- Profile: `{self.profile}`",
            f"- Subject: `{self.subject}`",
            f"- Generated: `{self.generated_at}`",
            f"- Repository: `{self.provenance.repository}`",
            f"- Branch: `{self.provenance.branch}`",
            f"- Commit: `{self.provenance.commit_sha}`",
            f"- Workflow run: `{self.provenance.workflow_run_id}`",
            f"- Workflow attempt: `{self.provenance.workflow_run_attempt}`",
            f"- Profile version: `{self.provenance.profile_version}`",
            f"- Overall status: **{self.overall_status}**",
            f"- Requirements: **{self.requirements_passed}/{self.requirements_total} PASS**",
            "",
            "| Requirement | Status | Evidence | Missing |",
            "|---|---|---|---|",
        ]
        for item in self.requirements:
            evidence = ", ".join(item.observed_evidence) or "—"
            missing = ", ".join(item.missing_evidence) or "—"
            lines.append(
                f"| {item.requirement_id} — {item.summary} | {item.status} | {evidence} | {missing} |"
            )
        lines.extend(["", "## Claim boundary", "", self.claim_boundary, ""])
        return "\n".join(lines)


def generate_conformance_evidence_report(
    *,
    observed_evidence: Iterable[str],
    subject: str,
    provenance: EvidenceProvenance,
    generated_at: datetime | None = None,
) -> ConformanceEvidenceReport:
    provenance.validate()
    observed = frozenset(observed_evidence)
    timestamp = generated_at or datetime.now(timezone.utc)
    rows: list[RequirementEvidence] = []

    for requirement in RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1:
        required = tuple(requirement.evidence_tests)
        matched = tuple(test for test in required if test in observed)
        missing = tuple(test for test in required if test not in observed)
        status = "PASS" if not missing else "FAIL"
        rows.append(
            RequirementEvidence(
                requirement_id=requirement.requirement_id,
                summary=requirement.summary,
                status=status,
                required_evidence=required,
                observed_evidence=matched,
                missing_evidence=missing,
            )
        )

    passed = sum(item.status == "PASS" for item in rows)
    total = len(rows)
    overall = "PASS" if passed == total else "FAIL"

    return ConformanceEvidenceReport(
        profile="Runtime Authority Conformance Profile v0.1",
        generated_at=timestamp.astimezone(timezone.utc).isoformat().replace("+00:00", "Z"),
        subject=subject,
        provenance=provenance,
        overall_status=overall,
        requirements_passed=passed,
        requirements_total=total,
        requirements=tuple(rows),
        claim_boundary=(
            "PASS means the supplied evidence set satisfies this reference profile's mapped "
            "requirements at the exact repository/commit/workflow execution identified above. "
            "It is not production certification, universal route-closure proof, or independent "
            "third-party validation."
        ),
    )
