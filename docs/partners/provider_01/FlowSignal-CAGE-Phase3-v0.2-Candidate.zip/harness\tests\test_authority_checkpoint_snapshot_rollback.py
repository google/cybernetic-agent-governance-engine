from dataclasses import replace
from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import (
    InMemoryAuthorityConsistencyCheckpoint,
    InMemoryAuthorityContinuityAnchor,
    temporary_authority_consistency_checkpoint,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def test_attack009_stale_checkpoint_restore_must_not_resurrect_superseded_authority():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None

    active_v3 = replace(base, lifecycle_status="ACTIVE", version=3)
    revoked_v5 = replace(base, lifecycle_status="REVOKED", version=5)
    continuity_anchor = InMemoryAuthorityContinuityAnchor()

    # Before the simulated disaster, the live shared checkpoint and an
    # independently persisted monotonic anchor have observed REVOKED v5.
    live_checkpoint = InMemoryAuthorityConsistencyCheckpoint()
    with temporary_authority_consistency_checkpoint(
        live_checkpoint,
        continuity_anchor=continuity_anchor,
    ):
        revoked_response, _ = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=SignedRecordAdapter(revoked_v5),
        )
    assert revoked_response.decision == "REFUSE"
    assert continuity_anchor.get_highest_anchored_version(SOURCE, request.mandate_id) == 5

    # Disaster recovery restores an older checkpoint snapshot that only knew
    # ACTIVE v3. The continuity anchor is deliberately NOT restored with it.
    stale_restored_checkpoint = InMemoryAuthorityConsistencyCheckpoint()
    stale_restored_checkpoint.observe_verified_version(
        SOURCE,
        request.mandate_id,
        3,
    )
    with temporary_authority_consistency_checkpoint(
        stale_restored_checkpoint,
        continuity_anchor=continuity_anchor,
    ):
        restored_response, restored_receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=SignedRecordAdapter(active_v3),
        )

    # The independent anchor proves the restored checkpoint is below a
    # previously verified high-water mark. The current reference path
    # conservatively treats that as inability to establish consistency.
    assert restored_response.decision == "REFUSE"
    assert restored_response.reason_code == "AUTHORITY_CONSISTENCY_CHECKPOINT_UNAVAILABLE"

    evidence = next(
        item for item in restored_receipt.evidence_references
        if item["type"] == "delegated_authority_state"
    )
    assert evidence["consistency_checkpoint"] == "UNAVAILABLE"
    assert evidence["status"] == "UNKNOWN"
