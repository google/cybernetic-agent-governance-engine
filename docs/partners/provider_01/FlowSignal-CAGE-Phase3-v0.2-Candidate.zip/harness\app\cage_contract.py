from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class CageFinding:
    code: str
    message: str
    needs_human_review: bool


@dataclass(frozen=True)
class CageValidationResult:
    decision: str
    authority_record_id: str | None
    findings: tuple[CageFinding, ...]
    authority_receipt: dict[str, Any]
    execution_context: dict[str, str]


def _authority_record_id(receipt_payload: dict[str, Any]) -> str | None:
    for item in receipt_payload.get("evidence_references", []):
        if not isinstance(item, dict):
            continue
        if item.get("type") == "delegated_authority_state":
            return item.get("authority_id") or item.get("mandate_id")
    return None


def map_flowsignal_to_cage(
    *,
    decision: str,
    reason_code: str,
    required_action: str | None,
    receipt_payload: dict[str, Any],
    platform: str,
    execution_id: str,
) -> CageValidationResult:
    """Translate FlowSignal authority semantics into the CAGE-facing ValidationResult contract.

    FlowSignal retains ALLOW / ESCALATE / REFUSE semantics internally. The adapter
    transports those semantics without exception-based control flow. ESCALATE is
    represented as a human-review finding using the agreed FLOWSIGNAL_HOLD code.
    """
    authority_record_id = _authority_record_id(receipt_payload)
    findings: tuple[CageFinding, ...]

    if decision == "ALLOW":
        if not authority_record_id:
            raise ValueError("ALLOW requires authority_record_id")
        findings = ()
    elif decision == "ESCALATE":
        findings = (
            CageFinding(
                code="FLOWSIGNAL_HOLD",
                message=required_action or reason_code,
                needs_human_review=True,
            ),
        )
    elif decision == "REFUSE":
        findings = (
            CageFinding(
                code="FLOWSIGNAL_REFUSE",
                message=reason_code,
                needs_human_review=False,
            ),
        )
    else:
        raise ValueError(f"Unsupported FlowSignal decision: {decision}")

    return CageValidationResult(
        decision=decision,
        authority_record_id=authority_record_id,
        findings=findings,
        authority_receipt=receipt_payload,
        execution_context={"platform": platform, "execution_id": execution_id},
    )
