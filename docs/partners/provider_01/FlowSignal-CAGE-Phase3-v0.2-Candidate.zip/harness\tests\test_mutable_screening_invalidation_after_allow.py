from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import (
    InMemoryAuthorityConsistencyCheckpoint,
    temporary_authority_consistency_checkpoint,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from app.engines.mutable_evidence_state import (
    InMemoryMutableEvidenceStateStore,
    invalidate_mutable_evidence,
    temporary_mutable_evidence_state_store,
)
from harness.runner import load_scenario

ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def _attempt(request, attempted_at):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=attempted_at,
    )


def test_attack020_screening_invalidation_after_allow_cannot_leave_receipt_executable():
    """Mutable supporting evidence invalidated after ALLOW must block execution."""
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None
    determined_at = datetime(2026, 8, 28, 12, 0, 0, tzinfo=timezone.utc)
    invalidated_at = determined_at + timedelta(seconds=5)
    execution_at = determined_at + timedelta(seconds=6)

    record = replace(
        base,
        effective_until=determined_at + timedelta(minutes=5),
        provenance=replace(base.provenance, observed_at=determined_at),
    )
    request = replace(
        request,
        screening_status="CLEAR",
        screening_captured_at=determined_at,
        screening_max_age_seconds=60,
        mandate_valid_until=determined_at + timedelta(minutes=5),
        requested_execution_time=determined_at,
    )

    evidence_store = InMemoryMutableEvidenceStateStore()
    with temporary_mutable_evidence_state_store(evidence_store):
        with temporary_approval_status(APPROVAL_ID, "APPROVED"):
            with temporary_authority_consistency_checkpoint(InMemoryAuthorityConsistencyCheckpoint()):
                response, receipt = evaluate_delegated_authority(
                    request,
                    approval_id=APPROVAL_ID,
                    sealed_at=determined_at,
                    authority_evidence_adapter=SignedRecordAdapter(record),
                    authority_evidence_max_age_seconds=300,
                )

        assert response.decision == "ALLOW"
        assert receipt.valid_until is not None and receipt.valid_until > invalidated_at
        screening = next(
            item for item in receipt.evidence_references
            if item.get("type") == "sanctions_screening"
        )
        assert screening["mutable_state_version"] == 1
        assert screening["mutable_state_current"] is True

        invalidate_mutable_evidence(request.screening_source)
        result = validate_execution(receipt, _attempt(request, execution_at))

    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_SUPPORTING_EVIDENCE_INVALIDATED"
