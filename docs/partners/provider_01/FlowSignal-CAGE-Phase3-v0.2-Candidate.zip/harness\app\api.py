from __future__ import annotations

from dataclasses import asdict
from datetime import datetime
from typing import Any

from fastapi import FastAPI
from pydantic import BaseModel, Field

from app.cage_contract import map_flowsignal_to_cage
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.financial_types import FinancialAuthorityRequest


app = FastAPI(
    title="FlowSignal Runtime Authority vNext",
    version="0.1-private",
    description=(
        "Reference service boundary for independent delegated-authority "
        "determination before consequential execution."
    ),
)


class AuthorityDetermineRequest(BaseModel):
    approval_id: str
    platform: str
    execution_id: str

    scenario_id: str
    action: str
    target: str
    actor_id: str
    actor_type: str
    actor_role: str
    actor_authenticated: bool
    kya_status: str
    principal_id: str
    principal_name: str
    mandate_id: str
    mandate_status: str = Field(
        description=(
            "Caller-presented mandate status. This is preserved as evidence but "
            "is not treated as authoritative authority state."
        )
    )
    mandate_max_amount: float
    mandate_currency: str
    permitted_source_accounts: list[str]
    permitted_counterparty_class: str
    mandate_valid_until: datetime
    amount: float
    currency: str
    source_account: str
    beneficiary: str
    purpose: str
    counterparty_status: str
    account_status: str
    risk_state: str
    approval_required: bool
    screening_status: str
    screening_captured_at: datetime
    screening_max_age_seconds: int
    screening_source: str
    requested_execution_time: datetime

    authority_resolution_path: str | None = None
    evidence_references: list[dict[str, Any]] = Field(default_factory=list)


class CageAuthorityDetermineRequest(BaseModel):
    """CAGE v3-facing request model.

    CAGE generalises finance-specific fields as amount -> magnitude and
    symbol -> context. FlowSignal keeps its native amount/currency contract
    separate from this external wire vocabulary.
    """

    approval_id: str
    platform: str
    execution_id: str
    scenario_id: str
    action: str
    target: str
    actor_id: str
    actor_type: str
    actor_role: str
    actor_authenticated: bool
    kya_status: str
    principal_id: str
    principal_name: str
    mandate_id: str
    mandate_status: str
    mandate_max_amount: float
    mandate_currency: str
    permitted_source_accounts: list[str]
    permitted_counterparty_class: str
    mandate_valid_until: datetime
    magnitude: float
    context: str
    currency: str
    source_account: str
    beneficiary: str
    purpose: str
    counterparty_status: str
    account_status: str
    risk_state: str
    approval_required: bool
    screening_status: str
    screening_captured_at: datetime
    screening_max_age_seconds: int
    screening_source: str
    requested_execution_time: datetime
    authority_resolution_path: str | None = None
    evidence_references: list[dict[str, Any]] = Field(default_factory=list)


class AuthorityDetermineResponse(BaseModel):
    determination: str
    reason_code: str
    required_action: str | None
    authority_receipt: dict[str, Any]
    execution_context: dict[str, str]


class CageFindingResponse(BaseModel):
    code: str
    message: str
    needs_human_review: bool


class CageValidationResponse(BaseModel):
    decision: str
    authority_record_id: str | None
    findings: list[CageFindingResponse]
    authority_receipt: dict[str, Any]
    execution_context: dict[str, str]


def _request_from_payload(payload: AuthorityDetermineRequest) -> FinancialAuthorityRequest:
    request_fields = payload.model_dump(
        exclude={
            "approval_id",
            "platform",
            "execution_id",
            "authority_resolution_path",
            "evidence_references",
        }
    )
    return FinancialAuthorityRequest(**request_fields)


def _native_request_from_cage(payload: CageAuthorityDetermineRequest) -> AuthorityDetermineRequest:
    data = payload.model_dump(exclude={"magnitude", "context"})
    data["amount"] = payload.magnitude
    return AuthorityDetermineRequest(**data)


def _determine(payload: AuthorityDetermineRequest):
    request = _request_from_payload(payload)
    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=payload.approval_id,
        authority_resolution_path=payload.authority_resolution_path,
    )
    receipt_payload = asdict(receipt)
    if payload.evidence_references:
        # Caller evidence is intentionally not merged into the sealed receipt.
        # It remains presented context until independently verified.
        receipt_payload["presented_evidence_references"] = payload.evidence_references
    return response, receipt_payload


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "runtime-authority-vnext"}


@app.post("/authority/determine", response_model=AuthorityDetermineResponse)
def determine_authority(payload: AuthorityDetermineRequest) -> AuthorityDetermineResponse:
    """Native FlowSignal authority contract; no consequence-execution capability."""
    response, receipt_payload = _determine(payload)
    return AuthorityDetermineResponse(
        determination=response.decision,
        reason_code=response.reason_code,
        required_action=response.required_action,
        authority_receipt=receipt_payload,
        execution_context={
            "platform": payload.platform,
            "execution_id": payload.execution_id,
        },
    )


@app.post("/cage/validate", response_model=CageValidationResponse)
def validate_for_cage(payload: CageAuthorityDetermineRequest) -> CageValidationResponse:
    """CAGE-facing adapter contract.

    ESCALATE is returned as a ValidationResult HOLD finding rather than raised as
    an exception. ALLOW always carries decision and authority_record_id. REFUSE
    remains an explicit non-authorising result. FlowSignal determines only; CAGE
    remains responsible for enforcement and consequence routing.
    """
    native_payload = _native_request_from_cage(payload)
    response, receipt_payload = _determine(native_payload)
    mapped = map_flowsignal_to_cage(
        decision=response.decision,
        reason_code=response.reason_code,
        required_action=response.required_action,
        receipt_payload=receipt_payload,
        platform=payload.platform,
        execution_id=payload.execution_id,
    )
    return CageValidationResponse(
        decision=mapped.decision,
        authority_record_id=mapped.authority_record_id,
        findings=[CageFindingResponse(**asdict(item)) for item in mapped.findings],
        authority_receipt=mapped.authority_receipt,
        execution_context=mapped.execution_context,
    )
