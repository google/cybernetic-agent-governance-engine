# Runtime Authority vNext Architecture

Status: Private engineering working architecture

Evidence baseline: `evidence/vnext-74-green` at commit `7db8dda4d1fb437adeb68b7c5169c9618300a776` (74 passed / 0 failed)

## Purpose

FlowSignal vNext is being evolved from an agentic-payments reference harness into an independent runtime-authority component that can sit behind an external platform execution boundary.

The architectural question is narrow:

> Does the delegated authority required for this exact consequence remain legitimately exercisable, on the evidence available, at the moment of execution?

FlowSignal does not replace identity, policy, approval, attestation, platform access control or the execution boundary. Those are inputs or surrounding controls. FlowSignal makes a distinct authority determination and returns a sealed Authority Receipt.

## Responsibility split

1. **Agent / caller proposes** the intended consequence and presents context.
2. **Platform execution boundary intercepts** before the consequence can bind.
3. **FlowSignal Authority Core determines** ALLOW / ESCALATE / REFUSE using independently obtained authority evidence.
4. **FlowSignal returns a sealed Authority Receipt** bound to the exact consequence and current authority-state version.
5. **Platform execution boundary verifies and enforces** the receipt, including integrity, current authority-state version, expiry, exact consequence binding and replay status.
6. **Execution boundary mints the execution permit** only for a valid current ALLOW.
7. **Consequence executor consumes the permit** and forms the represented consequence.

## Explicit separations

- Agent assertions are not authoritative authority evidence.
- Approval does not manufacture continuing delegated authority.
- Platform policy PERMIT does not override a FlowSignal REFUSE.
- FlowSignal cannot directly mint an execution permit.
- FlowSignal cannot directly form the represented financial consequence.
- A previous ALLOW is not timeless authority.
- An Authority Receipt is single-use at the vNext execution boundary.
- A permit is single-use at consequence formation.

## Canonical execution invariant

> No consequential execution may occur unless the execution boundary possesses a valid FlowSignal Authority Receipt bound to the exact consequence being executed and to sufficiently current authority state.

## Determination semantics

### ALLOW
Current evidence establishes that delegated authority remains exercisable for the exact proposed consequence.

### ESCALATE
Current evidence is insufficient to establish that delegated authority remains exercisable, but an identified authority path exists capable of resolving the uncertainty.

### REFUSE
Delegated authority is not established or is known not to be exercisable for the proposed consequence, or uncertainty cannot be resolved through an identified authority path.

## Failure behaviour

FlowSignal service unavailable: fail closed at the execution boundary; no permit path.

Authoritative source unavailable with a defined resolution path: ESCALATE; execution remains blocked.

Authoritative source unavailable without a defined resolution path: REFUSE; execution remains blocked.

Authority changes after ALLOW: stale receipt blocked before execution.

Consequence changes after ALLOW: binding mismatch blocked.

Authority Receipt replay: blocked.

Execution permit replay: blocked.

## Service boundary

The canonical service entry point is:

`POST /authority/determine`

The request carries the proposed consequence, actor/principal context, delegation reference, execution context and caller-presented evidence. The implementation independently resolves current delegated-authority state before returning a determination.

The response carries:

- determination: ALLOW / ESCALATE / REFUSE
- reason code
- required action when applicable
- Authority Receipt identifier
- validity window where applicable
- authority-state version
- exact action-binding hash
- sealed checks and evidence references
- receipt HMAC for reference-harness integrity

The service does **not** expose a payment execution operation or a permit-minting operation.

## Current proof families

- AP: original agentic-payments regression behaviour
- DA: delegated-authority, state-race, binding, replay and fail-closed behaviour
- IND: independence from agent assertions, platform approval/policy and execution capability
- XPLAT: next phase; common Authority Core behind multiple reference execution boundaries

## Claim boundary

This remains a reference engineering implementation. It does not claim production certification, universal external-route closure, production IAM/KMS/HSM isolation, real bank/payment-rail prevention, distributed transaction guarantees, or independent third-party validation.
