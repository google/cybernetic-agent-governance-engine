from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import (
    AuthorityContinuityAnchorUnavailable,
    InMemoryAuthorityConsistencyCheckpoint,
    temporary_authority_consistency_checkpoint,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario

ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"

class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)
    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(authority_id=authority_id, record=self.record, source_status="AVAILABLE", evidence_source=SOURCE, acquisition_layer=type(self).__name__, source_attestation=self.attestation)

class UnavailableContinuityAnchor:
    def get_highest_anchored_version(self, source: str, authority_id: str):
        raise AuthorityContinuityAnchorUnavailable("continuity anchor partitioned")
    def get_anchored_digest(self, source: str, authority_id: str, version: int):
        raise AuthorityContinuityAnchorUnavailable("continuity anchor partitioned")
    def observe_anchored_version(self, source: str, authority_id: str, version: int, *, content_digest=None):
        raise AuthorityContinuityAnchorUnavailable("continuity anchor partitioned")

def test_attack010_unavailable_continuity_anchor_must_not_fall_back_to_checkpoint_allow():
    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None
    healthy_checkpoint = InMemoryAuthorityConsistencyCheckpoint()
    unavailable_anchor = UnavailableContinuityAnchor()
    with temporary_authority_consistency_checkpoint(healthy_checkpoint, continuity_anchor=unavailable_anchor):
        response, receipt = evaluate_delegated_authority(request, approval_id=APPROVAL_ID, authority_evidence_adapter=SignedRecordAdapter(record))
    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_CONSISTENCY_CHECKPOINT_UNAVAILABLE"
    evidence = next(item for item in receipt.evidence_references if item["type"] == "delegated_authority_state")
    assert evidence["consistency_checkpoint"] == "UNAVAILABLE"
    assert evidence["status"] == "UNKNOWN"
