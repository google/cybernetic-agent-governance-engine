from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable


AuthorityCaller = Callable[[str, dict[str, Any]], Any]


@dataclass(frozen=True)
class ReferenceBoundaryResult:
    platform: str
    execution_id: str
    determination: str
    reason_code: str
    authority_receipt: dict[str, Any]
    permitted_to_continue: bool


class ReferenceExecutionBoundary:
    """Vendor-neutral reference boundary consuming FlowSignal authority decisions.

    The boundary proposes execution context to the Runtime Authority service and
    treats only an ALLOW determination as eligible to continue toward execution.
    It does not alter FlowSignal semantics and does not represent any vendor product.
    """

    def __init__(self, *, platform_name: str, authority_caller: AuthorityCaller):
        self.platform_name = platform_name
        self._authority_caller = authority_caller

    def determine(self, *, execution_id: str, payload: dict[str, Any]) -> ReferenceBoundaryResult:
        request_payload = dict(payload)
        request_payload["platform"] = self.platform_name
        request_payload["execution_id"] = execution_id

        response = self._authority_caller("/authority/determine", request_payload)
        if response.status_code != 200:
            return ReferenceBoundaryResult(
                platform=self.platform_name,
                execution_id=execution_id,
                determination="UNAVAILABLE",
                reason_code="AUTHORITY_DETERMINATION_UNAVAILABLE",
                authority_receipt={},
                permitted_to_continue=False,
            )

        body = response.json()
        determination = body["determination"]
        return ReferenceBoundaryResult(
            platform=self.platform_name,
            execution_id=execution_id,
            determination=determination,
            reason_code=body["reason_code"],
            authority_receipt=body["authority_receipt"],
            permitted_to_continue=determination == "ALLOW",
        )


class ReferenceBoundaryAlpha(ReferenceExecutionBoundary):
    def __init__(self, *, authority_caller: AuthorityCaller):
        super().__init__(platform_name="REFERENCE-BOUNDARY-ALPHA", authority_caller=authority_caller)


class ReferenceBoundaryBeta(ReferenceExecutionBoundary):
    def __init__(self, *, authority_caller: AuthorityCaller):
        super().__init__(platform_name="REFERENCE-BOUNDARY-BETA", authority_caller=authority_caller)
