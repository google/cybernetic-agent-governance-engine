from dataclasses import replace
from pathlib import Path

import pytest

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record, canonical_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import (
    InMemoryAuthorityConsistencyCheckpoint,
    InMemoryAuthorityContinuityAnchor,
    temporary_authority_consistency_checkpoint,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario
from hashlib import sha256

ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)
    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(authority_id=authority_id, record=self.record, source_status="AVAILABLE", evidence_source=SOURCE, acquisition_layer=type(self).__name__, source_attestation=self.attestation)


class CrashAfterAcknowledgementInt(int):
    def __gt__(self, other):
        raise SystemExit("simulated hard crash after checkpoint acknowledgement")


class CrashAfterAcknowledgedCheckpointWrite(InMemoryAuthorityConsistencyCheckpoint):
    def observe_verified_version(self, source, authority_id, version, *, content_digest=None):
        current = super().observe_verified_version(source, authority_id, version, content_digest=content_digest)
        if version == 5:
            return CrashAfterAcknowledgementInt(current)
        return current


def test_attack027_acknowledged_newer_checkpoint_write_loss_cannot_resurrect_old_authority():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None
    active_v4 = replace(base, lifecycle_status="ACTIVE", version=4)
    revoked_v5 = replace(base, lifecycle_status="REVOKED", version=5)

    checkpoint = CrashAfterAcknowledgedCheckpointWrite()
    anchor = InMemoryAuthorityContinuityAnchor()
    v4_digest = sha256(canonical_authority_record(active_v4, source=SOURCE)).hexdigest()
    checkpoint.observe_verified_version(SOURCE, request.mandate_id, 4, content_digest=v4_digest)
    anchor.observe_anchored_version(SOURCE, request.mandate_id, 4, content_digest=v4_digest)

    # Anchor-first protocol records v5 before checkpoint acceptance. We then
    # simulate a hard crash immediately after the checkpoint acknowledges v5.
    with pytest.raises(SystemExit):
        with temporary_authority_consistency_checkpoint(checkpoint, continuity_anchor=anchor):
            evaluate_delegated_authority(request, approval_id=APPROVAL_ID, authority_evidence_adapter=SignedRecordAdapter(revoked_v5))

    assert checkpoint.get_highest_verified_version(SOURCE, request.mandate_id) == 5
    assert anchor.get_highest_anchored_version(SOURCE, request.mandate_id) == 5
    assert anchor.get_anchored_digest(SOURCE, request.mandate_id, 5) is not None

    # Failover loses the acknowledged checkpoint write and restores v4. The
    # independent anchor still records v5, so recovery must detect rollback.
    restored_checkpoint = InMemoryAuthorityConsistencyCheckpoint()
    restored_checkpoint.observe_verified_version(SOURCE, request.mandate_id, 4, content_digest=v4_digest)
    with temporary_authority_consistency_checkpoint(restored_checkpoint, continuity_anchor=anchor):
        response, receipt = evaluate_delegated_authority(request, approval_id=APPROVAL_ID, authority_evidence_adapter=SignedRecordAdapter(active_v4))

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_CONSISTENCY_CHECKPOINT_UNAVAILABLE"
    evidence = next(item for item in receipt.evidence_references if item["type"] == "delegated_authority_state")
    assert evidence["consistency_checkpoint"] == "UNAVAILABLE"
    assert evidence["status"] == "UNKNOWN"
