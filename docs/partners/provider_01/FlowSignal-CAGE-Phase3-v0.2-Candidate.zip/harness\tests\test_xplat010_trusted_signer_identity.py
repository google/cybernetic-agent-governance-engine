from app.evidence_trust_anchor import RUNTIME_AUTHORITY_EVIDENCE_TRUST_ANCHOR_V0_1


def test_xplat010_expected_github_workflow_identity_is_trusted():
    anchor = RUNTIME_AUTHORITY_EVIDENCE_TRUST_ANCHOR_V0_1

    assert anchor.certificate_identity == (
        "https://github.com/grahamb-ai/flowsignal-agentic-payments-vnext/"
        ".github/workflows/vnext-regression.yml@refs/heads/runtime-authority-vnext"
    )
    assert anchor.validate_identity(
        certificate_identity=anchor.certificate_identity,
        oidc_issuer="https://token.actions.githubusercontent.com",
    )


def test_xplat010_other_repository_or_workflow_identity_is_not_trusted():
    anchor = RUNTIME_AUTHORITY_EVIDENCE_TRUST_ANCHOR_V0_1

    assert not anchor.validate_identity(
        certificate_identity=(
            "https://github.com/attacker/repository/"
            ".github/workflows/vnext-regression.yml@refs/heads/runtime-authority-vnext"
        ),
        oidc_issuer=anchor.oidc_issuer,
    )
    assert not anchor.validate_identity(
        certificate_identity=(
            "https://github.com/grahamb-ai/flowsignal-agentic-payments-vnext/"
            ".github/workflows/other.yml@refs/heads/runtime-authority-vnext"
        ),
        oidc_issuer=anchor.oidc_issuer,
    )


def test_xplat010_wrong_oidc_issuer_is_not_trusted():
    anchor = RUNTIME_AUTHORITY_EVIDENCE_TRUST_ANCHOR_V0_1

    assert not anchor.validate_identity(
        certificate_identity=anchor.certificate_identity,
        oidc_issuer="https://example.invalid",
    )
