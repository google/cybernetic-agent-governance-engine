from datetime import datetime
from pathlib import Path

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from app.engines.permit_authority import issue_execution_permit
from app.engines.protected_consequence import execute_protected_consequence
from app.engines.receipt_integrity import verify_receipt_hmac
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


def _attempt(request):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=datetime.fromisoformat("2026-08-10T09:15:30+00:00"),
    )


def _evidence(receipt, evidence_type):
    return next(item for item in receipt.evidence_references if item["type"] == evidence_type)


def test_ind001_agent_asserted_active_cannot_override_authoritative_revocation():
    request = load_scenario(AP001)
    assert request.mandate_status == "ACTIVE"

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )

            assert response.decision == "REFUSE"
            assert response.reason_code == "AUTHORITY_NOT_ESTABLISHED"
            assert verify_receipt_hmac(receipt) is True

            presented = _evidence(receipt, "presented_authority_assertion")
            authoritative = _evidence(receipt, "delegated_authority_state")
            assert presented["status"] == "ACTIVE"
            assert authoritative["status"] == "REVOKED"
            assert authoritative["source"] == "authoritative_mandate_store"

            gateway = validate_execution(receipt, _attempt(request))
            assert gateway.status == "BLOCKED"
            assert gateway.reason_code == "NO_APPLICABLE_ALLOW"
            assert gateway.execution_permit is None


def test_ind002_platform_approval_cannot_manufacture_revoked_authority():
    request = load_scenario(AP001)

    # Platform/human approval remains explicitly current.
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )

            approval = _evidence(receipt, "approval_state")
            authority = _evidence(receipt, "delegated_authority_state")
            assert approval["status"] == "APPROVED"
            assert authority["status"] == "REVOKED"
            assert response.decision == "REFUSE"

            gateway = validate_execution(receipt, _attempt(request))
            assert gateway.status == "BLOCKED"
            assert gateway.execution_permit is None


def test_ind003_platform_policy_permit_does_not_override_flowsignal_refusal():
    request = load_scenario(AP001)

    # Represent a separate platform policy engine that has already returned PERMIT.
    platform_policy_decision = "PERMIT"
    assert platform_policy_decision == "PERMIT"

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )

            assert response.decision == "REFUSE"
            gateway = validate_execution(receipt, _attempt(request))
            assert gateway.status == "BLOCKED"
            assert gateway.reason_code == "NO_APPLICABLE_ALLOW"
            assert gateway.execution_permit is None


def test_ind004_flowsignal_authority_core_cannot_mint_or_execute_consequence_directly():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )

            assert response.decision == "ALLOW"
            assert verify_receipt_hmac(receipt) is True

            # The permit authority refuses direct callers that do not possess the
            # execution gateway's private mint capability.
            direct_permit = issue_execution_permit(
                authority_receipt_id=receipt.id,
                action_binding_hash=receipt.action_binding_hash,
                authority_state_version=receipt.authority_state_version,
                valid_until=receipt.valid_until.isoformat(),
            )
            assert direct_permit is None

            # The protected consequence boundary also refuses execution without a
            # gateway-issued permit. FlowSignal's determination alone cannot act.
            outcome = execute_protected_consequence(
                permit=None,
                attempted_action_binding_hash=receipt.action_binding_hash,
            )
            assert outcome == "DENIED_NO_EXECUTION_PERMIT"
