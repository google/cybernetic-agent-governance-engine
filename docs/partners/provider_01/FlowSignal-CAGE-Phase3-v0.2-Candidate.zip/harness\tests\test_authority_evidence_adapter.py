from dataclasses import replace
from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult, ReferenceAuthorityStoreAdapter
from app.engines.authority_source_authenticity import attest_test_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.receipt_integrity import verify_receipt_hmac
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


class SyntheticExternalAuthorityAdapter:
    def __init__(self, record, *, evidence_source="synthetic_external_registry"):
        self.record = record
        self.evidence_source = evidence_source
        self.calls = []

    def acquire(self, authority_id: str):
        self.calls.append(authority_id)
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=self.evidence_source,
            acquisition_layer=type(self).__name__,
            source_attestation=attest_test_authority_record(
                self.record,
                source=self.evidence_source,
            ),
        )


def _authority_evidence(receipt):
    return next(item for item in receipt.evidence_references if item["type"] == "delegated_authority_state")


def test_adapter001_core_consumes_normalized_record_without_knowing_source_schema():
    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None
    external_record = replace(
        record,
        provenance=replace(
            record.provenance,
            source="synthetic_external_registry",
            source_record_id="EXT-441",
        ),
    )
    adapter = SyntheticExternalAuthorityAdapter(external_record)

    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=adapter,
    )

    assert adapter.calls == [request.mandate_id]
    assert response.decision == "ALLOW"
    assert verify_receipt_hmac(receipt) is True
    evidence = _authority_evidence(receipt)
    assert evidence["source"] == "synthetic_external_registry"
    assert evidence["acquisition_layer"] == "SyntheticExternalAuthorityAdapter"
    assert evidence["source_authenticity"] == "VERIFIED"
    assert evidence["provenance"]["source"] == "synthetic_external_registry"
    assert evidence["provenance"]["source_record_id"] == "EXT-441"


def test_adapter002_same_normalized_authority_semantics_are_source_independent():
    request = load_scenario(AP001)
    reference_response, reference_receipt = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=ReferenceAuthorityStoreAdapter(),
    )
    record = get_authority_record(request.mandate_id)
    assert record is not None
    external_record = replace(
        record,
        provenance=replace(record.provenance, source="another_authoritative_system"),
    )
    external_response, external_receipt = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=SyntheticExternalAuthorityAdapter(
            external_record,
            evidence_source="another_authoritative_system",
        ),
    )

    assert reference_response.decision == external_response.decision == "ALLOW"
    assert reference_response.reason_code == external_response.reason_code == "AUTHORITY_ESTABLISHED"
    reference_failed = {c.name for c in reference_receipt.checks if not c.passed}
    external_failed = {c.name for c in external_receipt.checks if not c.passed}
    assert reference_failed == external_failed == set()
    assert _authority_evidence(reference_receipt)["source"] != _authority_evidence(external_receipt)["source"]
    assert _authority_evidence(reference_receipt)["source_authenticity"] == "VERIFIED"
    assert _authority_evidence(external_receipt)["source_authenticity"] == "VERIFIED"


def test_adapter003_external_adapter_cannot_bypass_core_record_constraints():
    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None

    # This proof is about the core constraint, not equivocation. Present a newer
    # source-authenticated version so the record legitimately reaches the core,
    # where the delegate mismatch must still force REFUSE.
    maliciously_permissive_record = replace(
        record,
        delegate_id="different-agent",
        version=record.version + 1,
        provenance=replace(record.provenance, source="synthetic_external_registry"),
    )

    response, receipt = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=SyntheticExternalAuthorityAdapter(maliciously_permissive_record),
    )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_RECORD_CONSTRAINT_FAILED"
    assert _authority_evidence(receipt)["source_authenticity"] == "VERIFIED"
    failed = next(c for c in receipt.checks if c.name == "authority_delegate_matches")
    assert failed.passed is False
