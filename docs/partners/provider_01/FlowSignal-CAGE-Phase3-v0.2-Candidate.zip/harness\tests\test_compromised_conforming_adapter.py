from dataclasses import replace
from pathlib import Path

from app.adapter_conformance import validate_authority_evidence_result
from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


class CompromisedButConformingAdapter:
    def __init__(self, result):
        self.result = result

    def acquire(self, _authority_id: str):
        return self.result


def _authority_evidence(receipt):
    return next(item for item in receipt.evidence_references if item["type"] == "delegated_authority_state")


def _fresh_source_record(request, record):
    return replace(
        record,
        provenance=replace(
            record.provenance,
            source="authoritative_mandate_store",
            source_record_id=record.authority_id,
            observed_at=request.requested_execution_time,
        ),
    )


def test_attack001_structurally_conforming_delegate_substitution_must_not_manufacture_authority():
    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None

    source_record = _fresh_source_record(request, record)
    genuine_attestation = attest_reference_authority_record(source_record)
    attacker_request = replace(request, actor_id="agent-attacker-99")
    forged_record = replace(source_record, delegate_id=attacker_request.actor_id)
    result = AuthorityEvidenceResult(
        authority_id=request.mandate_id,
        record=forged_record,
        source_status="AVAILABLE",
        evidence_source="authoritative_mandate_store",
        acquisition_layer="CompromisedButConformingAdapter",
        source_attestation=genuine_attestation,
    )

    conformance = validate_authority_evidence_result(
        result,
        requested_authority_id=request.mandate_id,
        evaluated_at=attacker_request.requested_execution_time,
        max_evidence_age_seconds=300,
    )
    assert conformance.passed is True

    response, receipt = evaluate_delegated_authority(
        attacker_request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=CompromisedButConformingAdapter(result),
        authority_evidence_max_age_seconds=300,
    )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_EVIDENCE_AUTHENTICITY_UNVERIFIED"
    evidence = _authority_evidence(receipt)
    assert evidence["adapter_conformance"] == "PASS"
    assert evidence["source_authenticity"] == "FAILED"
    assert evidence["status"] == "UNKNOWN"


def test_attack002_structurally_conforming_scope_expansion_must_not_manufacture_authority():
    request = load_scenario(AP001)
    record = get_authority_record(request.mandate_id)
    assert record is not None

    source_record = _fresh_source_record(request, record)
    genuine_attestation = attest_reference_authority_record(source_record)
    widened_action = "payment.override"
    widened_request = replace(request, action=widened_action)
    forged_record = replace(
        source_record,
        permitted_consequence_classes=source_record.permitted_consequence_classes + (widened_action,),
    )
    result = AuthorityEvidenceResult(
        authority_id=request.mandate_id,
        record=forged_record,
        source_status="AVAILABLE",
        evidence_source="authoritative_mandate_store",
        acquisition_layer="CompromisedButConformingAdapter",
        source_attestation=genuine_attestation,
    )

    conformance = validate_authority_evidence_result(
        result,
        requested_authority_id=request.mandate_id,
        evaluated_at=widened_request.requested_execution_time,
        max_evidence_age_seconds=300,
    )
    assert conformance.passed is True

    response, receipt = evaluate_delegated_authority(
        widened_request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=CompromisedButConformingAdapter(result),
        authority_evidence_max_age_seconds=300,
    )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_EVIDENCE_AUTHENTICITY_UNVERIFIED"
    evidence = _authority_evidence(receipt)
    assert evidence["adapter_conformance"] == "PASS"
    assert evidence["source_authenticity"] == "FAILED"
    assert evidence["status"] == "UNKNOWN"
