from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult, ReferenceAuthorityStoreAdapter
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record, temporary_authoritative_mandate_status
from app.engines.authority_version_floor import (
    InMemoryAuthorityConsistencyCheckpoint,
    clear_verified_version_floor,
    temporary_authority_consistency_checkpoint,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


class StaleReplicaAuthorityAdapter:
    def __init__(self, record, attestation):
        self.record = record
        self.attestation = attestation

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source="authoritative_mandate_store",
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def test_attack005_shared_consistency_checkpoint_prevents_replica_split_brain_rollback():
    request = load_scenario(AP001)
    old_active = get_authority_record(request.mandate_id)
    assert old_active is not None
    assert old_active.lifecycle_status == "ACTIVE"
    old_attestation = attest_reference_authority_record(old_active)

    clear_verified_version_floor()
    shared_checkpoint = InMemoryAuthorityConsistencyCheckpoint()

    with temporary_authority_consistency_checkpoint(shared_checkpoint):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            current = get_authority_record(request.mandate_id)
            assert current is not None
            assert current.lifecycle_status == "REVOKED"
            assert current.version > old_active.version

            # Replica A observes the current source-authenticated revocation.
            replica_a_response, _ = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
                authority_evidence_adapter=ReferenceAuthorityStoreAdapter(),
            )
            assert replica_a_response.decision == "REFUSE"

            # Replica B is presented only with an authentic but obsolete ACTIVE
            # record. It shares consistency state, so routing cannot restore the
            # older authority merely by selecting a different replica/region.
            replica_b_response, replica_b_receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
                authority_evidence_adapter=StaleReplicaAuthorityAdapter(
                    old_active,
                    old_attestation,
                ),
            )

            assert replica_b_response.decision == "REFUSE"
            assert replica_b_response.reason_code == "AUTHORITY_EVIDENCE_ROLLBACK_DETECTED"

            evidence = next(
                item for item in replica_b_receipt.evidence_references
                if item["type"] == "delegated_authority_state"
            )
            assert evidence["source_authenticity"] == "VERIFIED"
            assert evidence["rollback_detected"] is True
            assert evidence["record_version"] == old_active.version
            assert evidence["known_current_record_version"] == current.version

    # The reference checkpoint is intentionally in-memory. Production claims
    # require a durable/shared implementation with appropriate consistency and
    # availability guarantees across replicas, restarts and regions.
