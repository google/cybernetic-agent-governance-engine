# Reference Execution Boundary Adapter Contract

Status: Private engineering hand-off contract

Purpose: define the minimum vendor-neutral contract an external execution boundary must satisfy to consume FlowSignal Runtime Authority without moving execution capability into FlowSignal.

## Responsibility boundary

The external execution boundary owns interception, enforcement, permit minting, and consequence release.

FlowSignal owns only independent runtime-authority determination and issuance of a sealed Authority Receipt.

The adapter MUST NOT give FlowSignal direct payment, tool, transaction, or consequence-execution capability.

## Required adapter behaviour

An adapter conforming to this contract MUST:

1. Intercept the proposed consequence before it can bind.
2. Construct a complete `POST /authority/determine` request containing:
   - approval reference;
   - platform identifier;
   - execution identifier;
   - actor and principal context;
   - delegation / mandate reference;
   - exact consequence fields used by FlowSignal binding;
   - requested execution time;
   - caller-presented evidence references where available.
3. Treat caller-supplied authority claims as presented evidence only, never as authoritative authority state.
4. Accept only `ALLOW`, `ESCALATE`, or `REFUSE` as determination values.
5. Continue toward execution only when the determination is `ALLOW` and the returned Authority Receipt is available for boundary validation.
6. Keep execution blocked for `ESCALATE` and `REFUSE`.
7. Fail closed if FlowSignal is unavailable, times out, returns no Authority Receipt, returns malformed data, or returns an unknown determination.
8. Before consequence formation, validate the Authority Receipt through the boundary enforcement path, including receipt integrity, current authority-state version, validity window, exact action binding, and replay protection.
9. Mint an execution permit only inside the execution boundary after successful validation.
10. Ensure the consequence executor requires that boundary-issued permit and cannot execute from the FlowSignal determination alone.

## Required request fields

The canonical request schema is the `/authority/determine` API model. At minimum the adapter must preserve the exact fields that participate in consequence binding:

- actor_id
- principal_id
- action
- target
- amount
- currency
- source_account
- beneficiary
- purpose
- mandate_id

Platform and execution identifiers are transport / execution-context evidence and MUST NOT change the authority semantics for an otherwise identical proposed consequence.

## Required response handling

For `ALLOW`, the adapter must retain the returned Authority Receipt and pass it to the execution-boundary validation function before permit minting.

For `ESCALATE`, the adapter must block execution and surface the returned `required_action` or equivalent resolution path.

For `REFUSE`, the adapter must block execution and preserve the reason code and receipt as evidence.

## Fail-closed conditions

The adapter must not infer permission from:

- identity being valid;
- approval being present;
- platform policy returning PERMIT;
- caller asserting mandate ACTIVE;
- a previous ALLOW;
- FlowSignal being temporarily unavailable;
- inability to verify current authority state;
- inability to validate the receipt.

## Prohibited behaviour

A conforming adapter MUST NOT:

- bypass `/authority/determine` for consequential execution;
- convert `ESCALATE` or `REFUSE` into permission;
- alter the proposed consequence after receiving ALLOW without re-determination;
- reuse a consumed Authority Receipt;
- mint a permit from an unvalidated receipt;
- expose its permit-mint capability to FlowSignal;
- treat caller-presented evidence as independently verified authority evidence.

## Conformance outcome

A reference adapter is conformant only if it demonstrates both:

- a valid current ALLOW can proceed through boundary validation to a boundary-issued permit; and
- revoked / unresolved authority remains blocked even when caller identity, approval, or platform policy would otherwise permit the action.

## Vendor-neutrality

This contract is intentionally not a Google CAGE, AWS, Microsoft, or other vendor specification. Vendor-specific adapters may map their own interception, identity, policy, routing, sealing, or enforcement primitives onto this contract without changing FlowSignal's authority semantics.
