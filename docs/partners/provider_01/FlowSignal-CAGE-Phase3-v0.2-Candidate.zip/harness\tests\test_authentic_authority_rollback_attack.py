from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult, ReferenceAuthorityStoreAdapter
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record, temporary_authoritative_mandate_status
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


class ReplayOldAuthenticRecordAdapter:
    def __init__(self, record, attestation):
        self.record = record
        self.attestation = attestation

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source="authoritative_mandate_store",
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def test_attack003_authentic_older_active_record_must_not_override_observed_newer_revocation():
    request = load_scenario(AP001)
    older_active = get_authority_record(request.mandate_id)
    assert older_active is not None
    assert older_active.lifecycle_status == "ACTIVE"
    older_attestation = attest_reference_authority_record(older_active)

    with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
        current = get_authority_record(request.mandate_id)
        assert current is not None
        assert current.lifecycle_status == "REVOKED"
        assert current.version > older_active.version

        # Establish the defensible anti-rollback precondition: FlowSignal has
        # already observed and verified the newer authoritative version.
        current_response, _ = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=ReferenceAuthorityStoreAdapter(),
        )
        assert current_response.decision == "REFUSE"

        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            authority_evidence_adapter=ReplayOldAuthenticRecordAdapter(
                older_active,
                older_attestation,
            ),
        )

        # Security expectation: authenticity proves who issued a record, not that
        # it is still the latest authority state. Once version N has been observed,
        # a validly signed version < N must never restore authority.
        assert response.decision == "REFUSE"
        assert response.reason_code == "AUTHORITY_EVIDENCE_ROLLBACK_DETECTED"

        evidence = next(
            item
            for item in receipt.evidence_references
            if item["type"] == "delegated_authority_state"
        )
        assert evidence["source_authenticity"] == "VERIFIED"
        assert evidence["record_version"] == older_active.version
        assert evidence["rollback_detected"] is True
        assert evidence["known_current_record_version"] == current.version
