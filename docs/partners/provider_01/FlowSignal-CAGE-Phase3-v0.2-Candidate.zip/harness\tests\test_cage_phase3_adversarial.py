from dataclasses import replace
from datetime import datetime
from pathlib import Path

from fastapi.encoders import jsonable_encoder
from fastapi.testclient import TestClient

from app.api import app
from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from app.engines.financial_types import AuthorityReceipt, FinancialCheck
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from app.engines.mutable_evidence_state import (
    InMemoryMutableEvidenceStateStore,
    temporary_mutable_evidence_state_store,
)
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
SCENARIOS = ROOT / "harness" / "scenarios"
APPROVAL_ID = "APPROVAL-TREASURY-001"
PLATFORM = "GOOGLE-CAGE-REFERENCE"
client = TestClient(app)


def _payload(name: str, execution_id: str):
    request = load_scenario(SCENARIOS / name)
    payload = jsonable_encoder(request)
    payload["magnitude"] = payload.pop("amount")
    payload["context"] = payload.get("purpose", "")
    payload.update(
        {
            "approval_id": APPROVAL_ID,
            "platform": PLATFORM,
            "execution_id": execution_id,
            "evidence_references": [{"type": "cage_policy", "result": "PERMIT"}],
        }
    )
    return request, payload


def _receipt(body) -> AuthorityReceipt:
    payload = dict(body["authority_receipt"])
    payload.pop("presented_evidence_references", None)
    payload["sealed_at"] = datetime.fromisoformat(payload["sealed_at"])
    if payload["valid_until"] is not None:
        payload["valid_until"] = datetime.fromisoformat(payload["valid_until"])
    payload["checks"] = [FinancialCheck(**item) for item in payload["checks"]]
    return AuthorityReceipt(**payload)


def _attempt(request, *, amount=None, beneficiary=None, source_account=None, purpose=None, attempted_at=None):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount if amount is None else amount,
        currency=request.currency,
        source_account=request.source_account if source_account is None else source_account,
        beneficiary=request.beneficiary if beneficiary is None else beneficiary,
        purpose=request.purpose if purpose is None else purpose,
        mandate_id=request.mandate_id,
        attempted_at=attempted_at or request.requested_execution_time,
    )


def test_cage004_platform_permit_cannot_override_flowsignal_refuse():
    request, payload = _payload("AP-001_allow.json", "CAGE-004")
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            result = client.post("/cage/validate", json=payload)
    body = result.json()
    assert body["decision"] == "REFUSE"
    assert body["findings"][0]["code"] == "FLOWSIGNAL_REFUSE"


def test_cage005_hold_is_non_executable_even_when_cage_policy_permits():
    request, payload = _payload("AP-002_limit_escalate.json", "CAGE-005")
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            result = client.post("/cage/validate", json=payload)
            body = result.json()
            receipt = _receipt(body)
            gateway = validate_execution(receipt, _attempt(request))
    assert body["decision"] == "ESCALATE"
    assert body["findings"][0]["code"] == "FLOWSIGNAL_HOLD"
    assert gateway.status == "BLOCKED"
    assert gateway.reason_code == "NO_APPLICABLE_ALLOW"


def test_cage006_exact_bound_allow_can_reach_reference_execution_boundary(tmp_path, monkeypatch):
    request, payload = _payload("AP-001_allow.json", "CAGE-006")
    monkeypatch.setenv("FLOWSIGNAL_AUTHORITY_RECEIPT_USE_STORE", str(tmp_path / "receipt-use.sqlite3"))
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            result = client.post("/cage/validate", json=payload)
            body = result.json()
            receipt = _receipt(body)
            gateway = validate_execution(receipt, _attempt(request, attempted_at=receipt.sealed_at))
    assert body["decision"] == "ALLOW"
    assert gateway.status == "PERMITTED"
    assert gateway.reason_code == "BOUND_ALLOW_VALID"
    assert gateway.execution_permit is not None


def test_cage007_consequence_substitution_is_blocked(tmp_path, monkeypatch):
    request, payload = _payload("AP-001_allow.json", "CAGE-007")
    monkeypatch.setenv("FLOWSIGNAL_AUTHORITY_RECEIPT_USE_STORE", str(tmp_path / "receipt-use.sqlite3"))
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            receipt = _receipt(client.post("/cage/validate", json=payload).json())
            for attempt in (
                _attempt(request, amount=request.amount + 1, attempted_at=receipt.sealed_at),
                _attempt(request, beneficiary="OTHER-BENEFICIARY", attempted_at=receipt.sealed_at),
                _attempt(request, source_account="OTHER-ACCOUNT", attempted_at=receipt.sealed_at),
                _attempt(request, purpose="SUBSTITUTED", attempted_at=receipt.sealed_at),
            ):
                result = validate_execution(receipt, attempt)
                assert result.status == "BLOCKED"
                assert result.reason_code == "ACTION_BINDING_MISMATCH"


def test_cage008_tampered_receipt_is_blocked_before_permit(tmp_path, monkeypatch):
    request, payload = _payload("AP-001_allow.json", "CAGE-008")
    monkeypatch.setenv("FLOWSIGNAL_AUTHORITY_RECEIPT_USE_STORE", str(tmp_path / "receipt-use.sqlite3"))
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            receipt = _receipt(client.post("/cage/validate", json=payload).json())
            tampered = replace(receipt, reason_code="TAMPERED")
            result = validate_execution(tampered, _attempt(request, attempted_at=receipt.sealed_at))
    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_RECEIPT_INTEGRITY_INVALID"


def test_cage009_authority_change_after_allow_blocks_stale_receipt(tmp_path, monkeypatch):
    request, payload = _payload("AP-001_allow.json", "CAGE-009")
    monkeypatch.setenv("FLOWSIGNAL_AUTHORITY_RECEIPT_USE_STORE", str(tmp_path / "receipt-use.sqlite3"))
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            receipt = _receipt(client.post("/cage/validate", json=payload).json())
            with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
                result = validate_execution(receipt, _attempt(request, attempted_at=receipt.sealed_at))
    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_STATE_STALE_REEVALUATION_REQUIRED"


def test_cage010_approval_change_after_allow_blocks_stale_receipt(tmp_path, monkeypatch):
    request, payload = _payload("AP-001_allow.json", "CAGE-010")
    monkeypatch.setenv("FLOWSIGNAL_AUTHORITY_RECEIPT_USE_STORE", str(tmp_path / "receipt-use.sqlite3"))
    with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
        receipt = _receipt(client.post("/cage/validate", json=payload).json())
        with temporary_approval_status(APPROVAL_ID, "WITHDRAWN"):
            result = validate_execution(receipt, _attempt(request, attempted_at=receipt.sealed_at))
    assert result.status == "BLOCKED"
    assert result.reason_code == "APPROVAL_STATE_STALE_REEVALUATION_REQUIRED"


def test_cage011_mutable_evidence_invalidation_after_allow_blocks_execution(tmp_path, monkeypatch):
    request, payload = _payload("AP-001_allow.json", "CAGE-011")
    monkeypatch.setenv("FLOWSIGNAL_AUTHORITY_RECEIPT_USE_STORE", str(tmp_path / "receipt-use.sqlite3"))
    store = InMemoryMutableEvidenceStateStore()
    with temporary_mutable_evidence_state_store(store):
        with temporary_approval_status(APPROVAL_ID, "APPROVED"):
            with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
                receipt = _receipt(client.post("/cage/validate", json=payload).json())
                store.invalidate(request.screening_source)
                result = validate_execution(receipt, _attempt(request, attempted_at=receipt.sealed_at))
    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_SUPPORTING_EVIDENCE_INVALIDATED"


def test_cage012_same_allow_receipt_cannot_be_consumed_twice(tmp_path, monkeypatch):
    request, payload = _payload("AP-001_allow.json", "CAGE-012")
    monkeypatch.setenv("FLOWSIGNAL_AUTHORITY_RECEIPT_USE_STORE", str(tmp_path / "receipt-use.sqlite3"))
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            receipt = _receipt(client.post("/cage/validate", json=payload).json())
            attempt = _attempt(request, attempted_at=receipt.sealed_at)
            first = validate_execution(receipt, attempt)
            second = validate_execution(receipt, attempt)
    assert first.status == "PERMITTED"
    assert second.status == "BLOCKED"
    assert second.reason_code == "AUTHORITY_RECEIPT_REPLAY"


def test_cage013_caller_active_assertion_cannot_override_authoritative_revocation():
    request, payload = _payload("AP-001_allow.json", "CAGE-013")
    payload["mandate_status"] = "ACTIVE"
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            body = client.post("/cage/validate", json=payload).json()
    assert body["decision"] == "REFUSE"
    authority = next(item for item in body["authority_receipt"]["evidence_references"] if item.get("type") == "delegated_authority_state")
    assert authority["status"] == "REVOKED"


def test_cage014_caller_cage_policy_is_context_not_sealed_authority_evidence():
    request, payload = _payload("AP-001_allow.json", "CAGE-014")
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            body = client.post("/cage/validate", json=payload).json()
    receipt = body["authority_receipt"]
    assert receipt["presented_evidence_references"] == [{"type": "cage_policy", "result": "PERMIT"}]
    assert not any(item.get("type") == "cage_policy" for item in receipt["evidence_references"] if isinstance(item, dict))


def test_cage015_flow_signal_service_exposes_no_direct_consequence_bind_route():
    route_paths = {route.path for route in app.routes}
    assert "/cage/validate" in route_paths
    assert "/authority/determine" in route_paths
    assert "/execute" not in route_paths
    assert "/payment/execute" not in route_paths
    assert "/execution/permit" not in route_paths
    assert "/consequence/bind" not in route_paths


def test_cage016_stale_screening_maps_to_hold_not_exception():
    request, payload = _payload("AP-004_stale_screening_evidence.json", "CAGE-016")
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            result = client.post("/cage/validate", json=payload)
    assert result.status_code == 200
    body = result.json()
    assert body["decision"] == "ESCALATE"
    assert body["findings"][0]["code"] == "FLOWSIGNAL_HOLD"
    assert body["findings"][0]["needs_human_review"] is True


def test_cage017_execution_context_is_preserved_for_correlation():
    request, payload = _payload("AP-001_allow.json", "CAGE-CORRELATION-017")
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            body = client.post("/cage/validate", json=payload).json()
    assert body["execution_context"] == {"platform": PLATFORM, "execution_id": "CAGE-CORRELATION-017"}


def test_cage018_malformed_request_is_rejected_before_authority_result():
    _, payload = _payload("AP-001_allow.json", "CAGE-018")
    payload.pop("actor_id")
    result = client.post("/cage/validate", json=payload)
    assert result.status_code == 422


def test_cage019_native_authority_contract_remains_available_and_semantically_native():
    request = load_scenario(SCENARIOS / "AP-002_limit_escalate.json")
    payload = jsonable_encoder(request)
    payload.update({"approval_id": APPROVAL_ID, "platform": PLATFORM, "execution_id": "CAGE-019", "evidence_references": [{"type": "cage_policy", "result": "PERMIT"}]})
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            body = client.post("/authority/determine", json=payload).json()
    assert body["determination"] == "ESCALATE"
    assert "findings" not in body


def test_cage020_cage_endpoint_rejects_legacy_amount_currency_shape():
    # Clean-break verification: /cage/validate no longer accepts the pre-v3
    # amount/currency shape at all, even though /authority/determine still does.
    request = load_scenario(SCENARIOS / "AP-001_allow.json")
    payload = jsonable_encoder(request)
    payload.update(
        {
            "approval_id": APPROVAL_ID,
            "platform": PLATFORM,
            "execution_id": "CAGE-020",
            "evidence_references": [{"type": "cage_policy", "result": "PERMIT"}],
        }
    )
    # Deliberately NOT renamed: payload still has "amount"/"currency" here.
    assert "amount" in payload and "currency" in payload
    result = client.post("/cage/validate", json=payload)
    assert result.status_code == 422
