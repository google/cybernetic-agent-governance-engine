from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from hashlib import sha256

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from app.engines.authority_store import AuthorityStateRecord


# Reference-harness signing identities only. Production integrations must obtain
# source assertions from institution-controlled signing infrastructure (for
# example KMS/HSM/workload identity), not from private keys embedded in code.
_SOURCE_SEEDS = {
    "authoritative_mandate_store": "b0ce2adf69b5d6c698d55ae163eaa0c4a5747c6e7a3d5820707c522a4eaf01d3",
    "synthetic_external_registry": "17d54cba4c55479812357bda685235686842e5277a659e213db2590867c73291",
    "another_authoritative_system": "e752f74439c92ced7a1dc2fba1be8790f9e221b3260af796cfe72f14fd2af106",
}
_SOURCE_PRIVATE_KEYS = {
    source: Ed25519PrivateKey.from_private_bytes(bytes.fromhex(seed))
    for source, seed in _SOURCE_SEEDS.items()
}


def _public_key_id(public_key: Ed25519PublicKey) -> str:
    raw = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return "ed25519:" + sha256(raw).hexdigest()


_TRUSTED_SOURCE_KEYS: dict[tuple[str, str], Ed25519PublicKey] = {}
for _source, _private_key in _SOURCE_PRIVATE_KEYS.items():
    _public_key = _private_key.public_key()
    _TRUSTED_SOURCE_KEYS[(_source, _public_key_id(_public_key))] = _public_key

REFERENCE_AUTHORITY_SOURCE_KEY_ID = _public_key_id(
    _SOURCE_PRIVATE_KEYS["authoritative_mandate_store"].public_key()
)


@dataclass(frozen=True)
class AuthoritySourceAttestation:
    source: str
    key_id: str
    algorithm: str
    signature_base64: str


def canonical_authority_record(record: AuthorityStateRecord, *, source: str) -> bytes:
    payload = {
        "source": source,
        "authority_id": record.authority_id,
        "principal_id": record.principal_id,
        "delegate_id": record.delegate_id,
        "permitted_consequence_classes": list(record.permitted_consequence_classes),
        "max_amount": record.max_amount,
        "currency": record.currency,
        "effective_from": None if record.effective_from is None else record.effective_from.isoformat(),
        "effective_until": None if record.effective_until is None else record.effective_until.isoformat(),
        "lifecycle_status": record.lifecycle_status,
        "version": record.version,
        "provenance": {
            "source": record.provenance.source,
            "source_record_id": record.provenance.source_record_id,
            "observed_at": record.provenance.observed_at.isoformat(),
        },
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def attest_test_authority_record(
    record: AuthorityStateRecord,
    *,
    source: str,
) -> AuthoritySourceAttestation:
    private_key = _SOURCE_PRIVATE_KEYS.get(source)
    if private_key is None:
        raise ValueError(f"No reference-harness signing identity for source '{source}'")
    public_key = private_key.public_key()
    signature = private_key.sign(canonical_authority_record(record, source=source))
    return AuthoritySourceAttestation(
        source=source,
        key_id=_public_key_id(public_key),
        algorithm="Ed25519",
        signature_base64=base64.b64encode(signature).decode("ascii"),
    )


def attest_reference_authority_record(record: AuthorityStateRecord) -> AuthoritySourceAttestation:
    return attest_test_authority_record(record, source="authoritative_mandate_store")


def verify_authority_source_attestation(
    record: AuthorityStateRecord,
    attestation: AuthoritySourceAttestation | None,
    *,
    expected_source: str,
) -> bool:
    if attestation is None:
        return False
    if attestation.algorithm != "Ed25519":
        return False
    if attestation.source != expected_source:
        return False
    public_key = _TRUSTED_SOURCE_KEYS.get((attestation.source, attestation.key_id))
    if public_key is None:
        return False
    try:
        signature = base64.b64decode(attestation.signature_base64, validate=True)
    except Exception:
        return False
    try:
        public_key.verify(
            signature,
            canonical_authority_record(record, source=expected_source),
        )
    except InvalidSignature:
        return False
    return True
