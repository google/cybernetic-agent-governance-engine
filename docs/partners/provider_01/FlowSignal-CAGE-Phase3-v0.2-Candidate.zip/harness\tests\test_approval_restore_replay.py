from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.engines.approval_store import set_approval_status, temporary_approval_status
from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import InMemoryAuthorityConsistencyCheckpoint, temporary_authority_consistency_checkpoint
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from harness.runner import load_scenario

ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def _attempt(request, attempted_at):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=attempted_at,
    )


def test_attack023_withdraw_then_restore_approval_cannot_resurrect_old_allow_receipt():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None
    determined_at = datetime(2026, 8, 28, 12, 0, 0, tzinfo=timezone.utc)
    record = replace(
        base,
        provenance=replace(base.provenance, observed_at=determined_at),
        effective_until=determined_at + timedelta(minutes=5),
    )
    request = replace(
        request,
        screening_captured_at=determined_at,
        screening_max_age_seconds=60,
        mandate_valid_until=determined_at + timedelta(minutes=5),
        requested_execution_time=determined_at,
    )

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authority_consistency_checkpoint(InMemoryAuthorityConsistencyCheckpoint()):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
                sealed_at=determined_at,
                authority_evidence_adapter=SignedRecordAdapter(record),
                authority_evidence_max_age_seconds=300,
            )
            assert response.decision == "ALLOW"

            # The approval changes state twice. Current status is APPROVED again,
            # but the old receipt must not survive that intervening withdrawal.
            set_approval_status(APPROVAL_ID, "WITHDRAWN")
            set_approval_status(APPROVAL_ID, "APPROVED")
            result = validate_execution(
                receipt,
                _attempt(request, determined_at + timedelta(seconds=5)),
            )

    assert result.status == "BLOCKED"
    assert result.reason_code == "APPROVAL_STATE_STALE_REEVALUATION_REQUIRED"
