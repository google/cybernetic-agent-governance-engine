from datetime import datetime, timezone
import json

import pytest

from app.conformance_evidence import EvidenceProvenance, generate_conformance_evidence_report
from app.conformance_profile import RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1


ALL_MAPPED_EVIDENCE = {
    evidence
    for requirement in RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1
    for evidence in requirement.evidence_tests
}

PROVENANCE = EvidenceProvenance(
    repository="grahamb-ai/flowsignal-agentic-payments-vnext",
    branch="runtime-authority-vnext",
    commit_sha="0123456789abcdef0123456789abcdef01234567",
    workflow_run_id="33161578962",
    workflow_run_attempt="1",
    profile_version="0.1",
)


def test_xplat007_complete_evidence_generates_pass_report():
    report = generate_conformance_evidence_report(
        observed_evidence=ALL_MAPPED_EVIDENCE,
        subject="REFERENCE-BOUNDARY-CONFORMANCE",
        provenance=PROVENANCE,
        generated_at=datetime(2026, 8, 28, 10, 0, tzinfo=timezone.utc),
    )

    assert report.overall_status == "PASS"
    assert report.requirements_passed == 24
    assert report.requirements_total == 24
    assert all(item.status == "PASS" for item in report.requirements)
    assert all(not item.missing_evidence for item in report.requirements)

    payload = json.loads(report.to_json())
    assert payload["overall_status"] == "PASS"
    assert payload["requirements_passed"] == 24
    assert payload["generated_at"] == "2026-08-28T10:00:00Z"
    assert payload["provenance"]["commit_sha"] == PROVENANCE.commit_sha
    assert payload["provenance"]["workflow_run_id"] == PROVENANCE.workflow_run_id

    markdown = report.to_markdown()
    assert "Overall status: **PASS**" in markdown
    assert "24/24 PASS" in markdown
    assert f"Commit: `{PROVENANCE.commit_sha}`" in markdown
    assert f"Workflow run: `{PROVENANCE.workflow_run_id}`" in markdown
    assert "not production certification" in markdown


def test_xplat007_missing_evidence_fails_only_affected_requirements():
    observed = ALL_MAPPED_EVIDENCE - {"IND-004"}
    report = generate_conformance_evidence_report(
        observed_evidence=observed,
        subject="INCOMPLETE-BOUNDARY",
        provenance=PROVENANCE,
        generated_at=datetime(2026, 8, 28, 10, 0, tzinfo=timezone.utc),
    )

    failed = {item.requirement_id: item for item in report.requirements if item.status == "FAIL"}

    assert report.overall_status == "FAIL"
    assert set(failed) == {"RA-CP-018", "RA-CP-019", "RA-CP-020", "RA-CP-021"}
    assert all(item.missing_evidence == ("IND-004",) for item in failed.values())
    assert report.requirements_passed == 20


def test_xplat007_unknown_evidence_cannot_manufacture_conformance():
    report = generate_conformance_evidence_report(
        observed_evidence={"PLATFORM-SAYS-PERMIT", "APPROVED", "UNKNOWN-TEST"},
        subject="UNQUALIFIED-BOUNDARY",
        provenance=PROVENANCE,
        generated_at=datetime(2026, 8, 28, 10, 0, tzinfo=timezone.utc),
    )

    assert report.overall_status == "FAIL"
    assert report.requirements_passed == 0
    assert report.requirements_total == 24


def test_xplat007_missing_provenance_cannot_generate_report():
    incomplete = EvidenceProvenance(
        repository="grahamb-ai/flowsignal-agentic-payments-vnext",
        branch="runtime-authority-vnext",
        commit_sha="",
        workflow_run_id="33161578962",
        workflow_run_attempt="1",
        profile_version="0.1",
    )

    with pytest.raises(ValueError, match="provenance is incomplete"):
        generate_conformance_evidence_report(
            observed_evidence=ALL_MAPPED_EVIDENCE,
            subject="MISSING-PROVENANCE",
            provenance=incomplete,
        )


def test_xplat007_short_commit_sha_is_rejected():
    invalid = EvidenceProvenance(
        repository="grahamb-ai/flowsignal-agentic-payments-vnext",
        branch="runtime-authority-vnext",
        commit_sha="deadbeef",
        workflow_run_id="33161578962",
        workflow_run_attempt="1",
        profile_version="0.1",
    )

    with pytest.raises(ValueError, match="40-character"):
        generate_conformance_evidence_report(
            observed_evidence=ALL_MAPPED_EVIDENCE,
            subject="INVALID-SHA",
            provenance=invalid,
        )
