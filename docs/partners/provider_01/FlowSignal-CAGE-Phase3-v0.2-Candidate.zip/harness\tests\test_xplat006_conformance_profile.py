from pathlib import Path

from app.conformance_profile import (
    RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1,
    requirement_ids,
)


ROOT = Path(__file__).resolve().parents[2]
PROFILE = ROOT / "docs" / "RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_v0.1.md"


def test_xplat006_profile_contains_all_machine_readable_requirements():
    text = PROFILE.read_text(encoding="utf-8")
    ids = requirement_ids()

    assert len(ids) == 24
    assert ids == {f"RA-CP-{index:03d}" for index in range(1, 25)}

    for requirement in RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1:
        assert requirement.requirement_id in text
        assert requirement.summary
        assert requirement.evidence_tests


def test_xplat006_every_requirement_maps_to_existing_proof_family():
    allowed_prefixes = ("XPLAT-", "IND-", "DA-")

    for requirement in RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1:
        assert all(
            evidence.startswith(allowed_prefixes)
            for evidence in requirement.evidence_tests
        )


def test_xplat006_profile_preserves_core_responsibility_split_and_claim_boundary():
    text = PROFILE.read_text(encoding="utf-8")

    assert "FlowSignal determines authority." in text
    assert "The adapter transports the request and response." in text
    assert "The external execution boundary validates and enforces." in text
    assert "The consequence executor acts only after the boundary has issued an execution permit." in text

    assert "MUST NOT be described as conformant solely because it can call `/authority/determine`" in text
    assert "does not establish production certification" in text
    assert "third-party endorsement" in text
