# FlowSignal Authority Evidence Adapter Conformance Profile v0.1

Status: Private engineering profile

## Purpose

This profile defines the minimum behaviour expected of an Authority Evidence Adapter before its normalized authority evidence is relied upon by the FlowSignal Runtime Authority Core.

An adapter is not authoritative merely because it implements the `AuthorityEvidenceAdapter` interface. Conformance requires evidence that the adapter preserves source identity, produces structurally valid normalized authority records, exposes evidence freshness and version provenance, and fails explicitly when authority evidence is unavailable, conflicting, malformed or insufficient.

## Architectural boundary

External authority system → Authority Evidence Adapter → normalized `AuthorityStateRecord` → FlowSignal Runtime Authority Core.

The adapter acquires and normalizes. FlowSignal determines. The execution boundary enforces.

## Normative requirements

### Identity and provenance

- **AE-CP-001** The adapter MUST preserve the identifier of the authority record requested by the core.
- **AE-CP-002** An AVAILABLE result MUST identify the authoritative evidence source independently of the adapter implementation.
- **AE-CP-003** An AVAILABLE record MUST include source-record provenance and an evidence observation timestamp.
- **AE-CP-004** The acquisition layer MUST be identifiable separately from the authoritative evidence source.

### Normalization

- **AE-CP-005** An AVAILABLE result MUST contain a normalized `AuthorityStateRecord`.
- **AE-CP-006** The normalized record authority identifier MUST match the requested authority identifier.
- **AE-CP-007** Principal and delegate identifiers MUST be non-empty.
- **AE-CP-008** At least one permitted consequence class MUST be represented.
- **AE-CP-009** Lifecycle status MUST be explicit and non-empty.
- **AE-CP-010** Record version MUST be a positive integer.
- **AE-CP-011** Where both effective bounds exist, `effective_until` MUST NOT precede `effective_from`.
- **AE-CP-012** A monetary limit, where supplied, MUST NOT be negative.

### Freshness and traceability

- **AE-CP-013** Provenance `observed_at` MUST be timezone-aware.
- **AE-CP-014** When a maximum acceptable evidence age is specified, stale AVAILABLE evidence MUST be rejected as non-conformant rather than silently accepted.
- **AE-CP-015** The provenance source-record identifier MUST be non-empty for AVAILABLE evidence.

### Failure and uncertainty

- **AE-CP-016** Source unavailability MUST be represented explicitly and MUST NOT synthesize an ACTIVE authority record.
- **AE-CP-017** Conflicting authoritative evidence MUST be surfaced explicitly and MUST NOT be resolved by arbitrary source ordering inside the adapter contract.
- **AE-CP-018** NOT_FOUND MUST NOT include a fabricated authority record.
- **AE-CP-019** Unknown or malformed source-status values MUST fail adapter conformance.
- **AE-CP-020** A structurally malformed AVAILABLE record MUST fail adapter conformance before the record is trusted by the Runtime Authority Core.

## Conformance semantics

Passing this profile means the tested adapter satisfied these reference-harness requirements for the exercised cases. It does not establish production certification, source-system correctness, legal authority, production IAM/KMS/HSM isolation, distributed consistency, or third-party endorsement.

A vendor or institutional adapter MUST NOT be described as conformant solely because it can produce an `AuthorityStateRecord`. It must pass the applicable positive, stale, malformed, unavailable, conflict and source-provenance cases.
