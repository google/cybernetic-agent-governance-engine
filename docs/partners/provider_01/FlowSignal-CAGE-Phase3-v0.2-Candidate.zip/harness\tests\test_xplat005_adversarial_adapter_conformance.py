from __future__ import annotations

from dataclasses import replace
from datetime import timedelta
from pathlib import Path

from fastapi.encoders import jsonable_encoder
from fastapi.testclient import TestClient

from app.api import app
from app.adapters.reference_boundary_adapter import ReferenceExecutionBoundaryAdapter
from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import (
    advance_authority_state_version,
    temporary_authoritative_mandate_status,
)
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


class _StaticResponse:
    def __init__(self, body: dict, status_code: int = 200):
        self._body = body
        self.status_code = status_code

    def json(self):
        return self._body


class _StaticClient:
    def __init__(self, body: dict, status_code: int = 200):
        self.body = body
        self.status_code = status_code

    def post(self, *_args, **_kwargs):
        return _StaticResponse(self.body, self.status_code)


def _valid_service_body(request, *, execution_id: str) -> dict:
    payload = jsonable_encoder(request)
    payload.update(
        {
            "approval_id": APPROVAL_ID,
            "platform": "REFERENCE-CONFORMANCE-SOURCE",
            "execution_id": execution_id,
            "evidence_references": [],
        }
    )
    response = TestClient(app).post("/authority/determine", json=payload)
    assert response.status_code == 200
    body = response.json()
    assert body["determination"] == "ALLOW"
    return body


def _adapter_for_body(body: dict) -> ReferenceExecutionBoundaryAdapter:
    adapter = ReferenceExecutionBoundaryAdapter(platform="REFERENCE-CONFORMANCE-TARGET")
    adapter._client = _StaticClient(body)
    return adapter


def test_xplat005_malformed_allow_receipt_is_blocked_before_permit():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            body = _valid_service_body(request, execution_id="EXEC-XPLAT005-MALFORMED")

    body["authority_receipt"].pop("action_binding_hash")
    result = _adapter_for_body(body).determine_and_enforce(
        request=request,
        approval_id=APPROVAL_ID,
        execution_id="EXEC-XPLAT005-MALFORMED-TARGET",
        attempted_at=request.requested_execution_time,
    )

    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_RECEIPT_MALFORMED"
    assert result.gateway_result is None


def test_xplat005_tampered_allow_receipt_fails_integrity_validation():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            body = _valid_service_body(request, execution_id="EXEC-XPLAT005-TAMPER")

    body["authority_receipt"]["receipt_hmac"] = "0" * 64
    result = _adapter_for_body(body).determine_and_enforce(
        request=request,
        approval_id=APPROVAL_ID,
        execution_id="EXEC-XPLAT005-TAMPER-TARGET",
        attempted_at=request.requested_execution_time,
    )

    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_RECEIPT_INTEGRITY_INVALID"
    assert result.gateway_result is not None
    assert result.gateway_result.execution_permit is None


def test_xplat005_previous_allow_becomes_unusable_after_authority_state_advances():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            body = _valid_service_body(request, execution_id="EXEC-XPLAT005-STALE")
            sealed_version = body["authority_receipt"]["authority_state_version"]
            advance_authority_state_version()

            result = _adapter_for_body(body).determine_and_enforce(
                request=request,
                approval_id=APPROVAL_ID,
                execution_id="EXEC-XPLAT005-STALE-TARGET",
                attempted_at=request.requested_execution_time,
            )

    assert body["authority_receipt"]["authority_state_version"] == sealed_version
    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_STATE_STALE_REEVALUATION_REQUIRED"
    assert result.gateway_result is not None
    assert result.gateway_result.execution_permit is None


def test_xplat005_receipt_for_one_consequence_cannot_authorise_another():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            body = _valid_service_body(request, execution_id="EXEC-XPLAT005-BIND")

            altered_request = replace(request, amount=request.amount + 1.0)
            result = _adapter_for_body(body).determine_and_enforce(
                request=altered_request,
                approval_id=APPROVAL_ID,
                execution_id="EXEC-XPLAT005-BIND-TARGET",
                attempted_at=request.requested_execution_time,
            )

    assert result.status == "BLOCKED"
    assert result.reason_code == "ACTION_BINDING_MISMATCH"
    assert result.gateway_result is not None
    assert result.gateway_result.execution_permit is None


def test_xplat005_same_allow_receipt_cannot_be_consumed_twice():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            body = _valid_service_body(request, execution_id="EXEC-XPLAT005-REPLAY")
            adapter = _adapter_for_body(body)

            first = adapter.determine_and_enforce(
                request=request,
                approval_id=APPROVAL_ID,
                execution_id="EXEC-XPLAT005-REPLAY-1",
                attempted_at=request.requested_execution_time,
            )
            second = adapter.determine_and_enforce(
                request=request,
                approval_id=APPROVAL_ID,
                execution_id="EXEC-XPLAT005-REPLAY-2",
                attempted_at=request.requested_execution_time + timedelta(seconds=1),
            )

    assert first.status == "PERMITTED"
    assert first.reason_code == "BOUND_ALLOW_VALID"
    assert first.gateway_result is not None
    assert first.gateway_result.execution_permit is not None

    assert second.status == "BLOCKED"
    assert second.reason_code == "AUTHORITY_RECEIPT_REPLAY"
    assert second.gateway_result is not None
    assert second.gateway_result.execution_permit is None
