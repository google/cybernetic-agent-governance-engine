from pathlib import Path

from fastapi.encoders import jsonable_encoder
from fastapi.testclient import TestClient

from app.api import app
from app.cage_contract import map_flowsignal_to_cage
from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
SCENARIOS = ROOT / "harness" / "scenarios"
APPROVAL_ID = "APPROVAL-TREASURY-001"
client = TestClient(app)


def _payload(name: str, *, execution_id: str):
    request = load_scenario(SCENARIOS / name)
    payload = jsonable_encoder(request)
    payload["magnitude"] = payload.pop("amount")
    payload["context"] = payload.get("purpose", "")
    payload.update(
        {
            "approval_id": APPROVAL_ID,
            "platform": "GOOGLE-CAGE-REFERENCE",
            "execution_id": execution_id,
            "evidence_references": [{"type": "cage_policy", "result": "PERMIT"}],
        }
    )
    return request, payload


def test_cage001_allow_includes_mandatory_decision_and_authority_record_id():
    request, payload = _payload("AP-001_allow.json", execution_id="CAGE-ALLOW-001")
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            result = client.post("/cage/validate", json=payload)

    assert result.status_code == 200
    body = result.json()
    assert body["decision"] == "ALLOW"
    assert body["authority_record_id"] == request.mandate_id
    assert body["findings"] == []
    assert body["authority_receipt"]["decision"] == "ALLOW"


def test_cage002_escalate_maps_to_nonbinary_hold_finding_not_exception():
    request, payload = _payload("AP-002_limit_escalate.json", execution_id="CAGE-HOLD-001")
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            result = client.post("/cage/validate", json=payload)

    assert result.status_code == 200
    body = result.json()
    assert body["decision"] == "ESCALATE"
    assert body["findings"]
    finding = body["findings"][0]
    assert finding["code"] == "FLOWSIGNAL_HOLD"
    assert finding["needs_human_review"] is True


def test_cage003_refuse_remains_explicit_non_authorising_validation_result():
    request, payload = _payload("AP-001_allow.json", execution_id="CAGE-REFUSE-001")
    payload["mandate_status"] = "ACTIVE"
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            result = client.post("/cage/validate", json=payload)

    assert result.status_code == 200
    body = result.json()
    assert body["decision"] == "REFUSE"
    assert body["findings"][0]["code"] == "FLOWSIGNAL_REFUSE"
    assert body["findings"][0]["needs_human_review"] is False


def test_cage004_context_is_not_interpreted_as_flowsignal_currency():
    request, payload = _payload("AP-001_allow.json", execution_id="CAGE-CONTEXT-001")
    payload["context"] = "AAPL"
    payload["currency"] = "GBP"
    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            result = client.post("/cage/validate", json=payload)

    assert result.status_code == 200
    body = result.json()
    assert body["decision"] == "ALLOW"
    assert body["authority_receipt"]["request_snapshot"]["currency"] == "GBP"
    assert body["authority_receipt"]["request_snapshot"]["currency"] != payload["context"]


def test_cage005_invalid_flowsignal_decision_is_rejected():
    import pytest
    with pytest.raises(ValueError, match="Unsupported FlowSignal decision"):
        map_flowsignal_to_cage(
            decision="CORRUPT",
            reason_code="INVALID_TEST_DECISION",
            required_action=None,
            receipt_payload={},
            platform="GOOGLE-CAGE-REFERENCE",
            execution_id="CAGE-CORRUPT-001",
        )
