from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult


ALLOWED_SOURCE_STATUSES = {"AVAILABLE", "NOT_FOUND", "UNAVAILABLE", "CONFLICT"}


@dataclass(frozen=True)
class AdapterConformanceResult:
    passed: bool
    violations: tuple[str, ...]


def _utc(dt: datetime) -> datetime:
    if dt.tzinfo is None:
        raise ValueError("timestamp must be timezone-aware")
    return dt.astimezone(timezone.utc)


def validate_authority_evidence_result(
    result: AuthorityEvidenceResult,
    *,
    requested_authority_id: str,
    evaluated_at: datetime | None = None,
    max_evidence_age_seconds: int | None = None,
) -> AdapterConformanceResult:
    violations: list[str] = []

    if result.authority_id != requested_authority_id:
        violations.append("AE-CP-001 authority identifier mismatch")
    if result.source_status not in ALLOWED_SOURCE_STATUSES:
        violations.append("AE-CP-019 unknown source status")
    if not result.acquisition_layer:
        violations.append("AE-CP-004 acquisition layer missing")

    if result.source_status == "AVAILABLE":
        record = result.record
        if record is None:
            violations.append("AE-CP-005 AVAILABLE result missing AuthorityStateRecord")
            return AdapterConformanceResult(False, tuple(violations))
        if not result.evidence_source:
            violations.append("AE-CP-002 authoritative evidence source missing")
        if record.authority_id != requested_authority_id:
            violations.append("AE-CP-006 normalized record authority identifier mismatch")
        if not record.principal_id:
            violations.append("AE-CP-007 principal identifier missing")
        if not record.delegate_id:
            violations.append("AE-CP-007 delegate identifier missing")
        if not record.permitted_consequence_classes:
            violations.append("AE-CP-008 no permitted consequence class")
        if not record.lifecycle_status:
            violations.append("AE-CP-009 lifecycle status missing")
        if not isinstance(record.version, int) or record.version < 1:
            violations.append("AE-CP-010 record version must be positive integer")
        if record.effective_from is not None and record.effective_until is not None:
            try:
                if _utc(record.effective_until) < _utc(record.effective_from):
                    violations.append("AE-CP-011 effective window is inverted")
            except ValueError:
                violations.append("AE-CP-013 effective timestamps must be timezone-aware")
        if record.max_amount is not None and record.max_amount < 0:
            violations.append("AE-CP-012 monetary limit is negative")
        if not record.provenance.source:
            violations.append("AE-CP-003 provenance source missing")
        if not record.provenance.source_record_id:
            violations.append("AE-CP-015 provenance source record identifier missing")
        try:
            observed_at = _utc(record.provenance.observed_at)
        except ValueError:
            violations.append("AE-CP-013 provenance observed_at must be timezone-aware")
        else:
            if max_evidence_age_seconds is not None:
                moment = _utc(evaluated_at or datetime.now(timezone.utc))
                if observed_at > moment:
                    violations.append("AE-CP-021 authority evidence observed_at is in the future")
                else:
                    age = (moment - observed_at).total_seconds()
                    if age > max_evidence_age_seconds:
                        violations.append("AE-CP-014 authority evidence is stale")

    elif result.source_status in {"NOT_FOUND", "UNAVAILABLE", "CONFLICT"}:
        if result.record is not None:
            code = {
                "NOT_FOUND": "AE-CP-018",
                "UNAVAILABLE": "AE-CP-016",
                "CONFLICT": "AE-CP-017",
            }[result.source_status]
            violations.append(f"{code} non-AVAILABLE result must not include authority record")

    return AdapterConformanceResult(not violations, tuple(violations))
