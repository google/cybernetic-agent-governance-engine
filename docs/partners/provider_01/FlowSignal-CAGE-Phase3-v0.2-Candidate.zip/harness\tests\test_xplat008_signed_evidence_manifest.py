from dataclasses import replace
from datetime import datetime, timezone

from app.conformance_evidence import EvidenceProvenance, generate_conformance_evidence_report
from app.conformance_profile import RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1
from app.evidence_manifest import build_evidence_manifest, generate_ed25519_keypair_pem, verify_evidence_manifest

ALL_MAPPED_EVIDENCE = {evidence for requirement in RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1 for evidence in requirement.evidence_tests}


def _report():
    provenance = EvidenceProvenance(repository="grahamb-ai/flowsignal-agentic-payments-vnext", branch="runtime-authority-vnext", commit_sha="1" * 40, workflow_run_id="33161905538", workflow_run_attempt="1", profile_version="0.1")
    return generate_conformance_evidence_report(observed_evidence=ALL_MAPPED_EVIDENCE, subject="REFERENCE-BOUNDARY-CONFORMANCE", provenance=provenance, generated_at=datetime(2026, 8, 28, 10, 0, tzinfo=timezone.utc))


def _signed_manifest():
    report = _report()
    report_json = report.to_json()
    report_markdown = report.to_markdown()
    private_key_pem, public_key_pem = generate_ed25519_keypair_pem()
    manifest = build_evidence_manifest(report=report, report_json=report_json, report_markdown=report_markdown, private_key_pem=private_key_pem, public_key_pem=public_key_pem, artifact_zip_sha256="a" * 64, generated_at=datetime(2026, 8, 28, 10, 1, tzinfo=timezone.utc))
    return report_json, report_markdown, manifest, public_key_pem


def test_xplat008_manifest_binds_report_provenance_and_hashes():
    report_json, report_markdown, manifest, public_key_pem = _signed_manifest()
    assert manifest.manifest_version == "0.3"
    assert manifest.signature_algorithm == "Ed25519"
    assert manifest.commit_sha == "1" * 40
    assert manifest.workflow_run_id == "33161905538"
    assert manifest.profile_version == "0.1"
    assert manifest.artifact_zip_sha256 == "a" * 64
    assert len(manifest.report_json_sha256) == 64
    assert len(manifest.report_markdown_sha256) == 64
    assert len(manifest.signer_key_id) == 64
    assert manifest.signature_base64
    assert verify_evidence_manifest(manifest=manifest, report_json=report_json, report_markdown=report_markdown, public_key_pem=public_key_pem, artifact_zip_sha256="a" * 64)


def test_xplat008_tampered_report_fails_manifest_verification():
    report_json, report_markdown, manifest, public_key_pem = _signed_manifest()
    assert not verify_evidence_manifest(manifest=manifest, report_json=report_json + "\nTAMPERED", report_markdown=report_markdown, public_key_pem=public_key_pem, artifact_zip_sha256="a" * 64)


def test_xplat008_tampered_manifest_fails_signature_verification():
    report_json, report_markdown, manifest, public_key_pem = _signed_manifest()
    tampered = replace(manifest, overall_status="FAIL")
    assert not verify_evidence_manifest(manifest=tampered, report_json=report_json, report_markdown=report_markdown, public_key_pem=public_key_pem, artifact_zip_sha256="a" * 64)
