from datetime import datetime, timezone

from app.conformance_evidence import EvidenceProvenance, generate_conformance_evidence_report
from app.conformance_profile import RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1
from app.evidence_manifest import (
    build_evidence_manifest,
    generate_ed25519_keypair_pem,
    verify_evidence_manifest,
)


ALL_MAPPED_EVIDENCE = {
    evidence
    for requirement in RUNTIME_AUTHORITY_CONFORMANCE_PROFILE_V0_1
    for evidence in requirement.evidence_tests
}


def _report():
    return generate_conformance_evidence_report(
        observed_evidence=ALL_MAPPED_EVIDENCE,
        subject="REFERENCE-BOUNDARY-CONFORMANCE",
        provenance=EvidenceProvenance(
            repository="grahamb-ai/flowsignal-agentic-payments-vnext",
            branch="runtime-authority-vnext",
            commit_sha="2" * 40,
            workflow_run_id="33162170064",
            workflow_run_attempt="1",
            profile_version="0.1",
        ),
        generated_at=datetime(2026, 8, 28, 10, 5, tzinfo=timezone.utc),
    )


def test_xplat009_public_key_verifies_without_private_key_material():
    report = _report()
    report_json = report.to_json()
    report_markdown = report.to_markdown()
    private_key_pem, public_key_pem = generate_ed25519_keypair_pem()
    manifest = build_evidence_manifest(
        report=report,
        report_json=report_json,
        report_markdown=report_markdown,
        private_key_pem=private_key_pem,
        public_key_pem=public_key_pem,
    )

    del private_key_pem
    assert verify_evidence_manifest(
        manifest=manifest,
        report_json=report_json,
        report_markdown=report_markdown,
        public_key_pem=public_key_pem,
    )


def test_xplat009_wrong_public_key_cannot_verify_signature():
    report = _report()
    report_json = report.to_json()
    report_markdown = report.to_markdown()
    private_key_pem, public_key_pem = generate_ed25519_keypair_pem()
    _, wrong_public_key_pem = generate_ed25519_keypair_pem()
    manifest = build_evidence_manifest(
        report=report,
        report_json=report_json,
        report_markdown=report_markdown,
        private_key_pem=private_key_pem,
        public_key_pem=public_key_pem,
    )

    assert not verify_evidence_manifest(
        manifest=manifest,
        report_json=report_json,
        report_markdown=report_markdown,
        public_key_pem=wrong_public_key_pem,
    )
