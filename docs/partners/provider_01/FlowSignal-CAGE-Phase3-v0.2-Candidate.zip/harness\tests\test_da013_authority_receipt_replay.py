from datetime import datetime
from pathlib import Path

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt, validate_execution
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


def _attempt(request):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=datetime.fromisoformat("2026-08-10T09:15:30+00:00"),
    )


def test_da013_same_authority_receipt_cannot_mint_execution_authority_twice():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            response, receipt = evaluate_delegated_authority(
                request,
                approval_id=APPROVAL_ID,
            )
            assert response.decision == "ALLOW"

            first = validate_execution(receipt, _attempt(request))
            assert first.status == "PERMITTED"
            assert first.execution_permit is not None

            second = validate_execution(receipt, _attempt(request))
            assert second.status == "BLOCKED"
            assert second.reason_code == "AUTHORITY_RECEIPT_REPLAY"
            assert second.execution_permit is None
