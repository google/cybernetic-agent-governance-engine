from __future__ import annotations

from contextlib import contextmanager
from threading import RLock


_APPROVAL_STATE_LOCK = RLock()
_APPROVAL_STATUS = {
    "APPROVAL-TREASURY-001": "APPROVED",
}
_APPROVAL_VERSION = {
    "APPROVAL-TREASURY-001": 1,
}


def get_approval_status(approval_id: str) -> str | None:
    """Return represented approval state independently of delegated authority."""
    with _APPROVAL_STATE_LOCK:
        return _APPROVAL_STATUS.get(approval_id)


def get_approval_snapshot(approval_id: str) -> tuple[str | None, int]:
    with _APPROVAL_STATE_LOCK:
        return _APPROVAL_STATUS.get(approval_id), _APPROVAL_VERSION.get(approval_id, 1)


def set_approval_status(approval_id: str, status: str) -> None:
    normalized = status.upper()
    with _APPROVAL_STATE_LOCK:
        previous = _APPROVAL_STATUS.get(approval_id)
        if previous != normalized:
            _APPROVAL_VERSION[approval_id] = _APPROVAL_VERSION.get(approval_id, 1) + 1
        _APPROVAL_STATUS[approval_id] = normalized


@contextmanager
def temporary_approval_status(approval_id: str, status: str):
    """Test-scoped approval mutation with monotonic version advancement."""
    normalized = status.upper()
    with _APPROVAL_STATE_LOCK:
        previous = _APPROVAL_STATUS.get(approval_id)
        if previous != normalized:
            _APPROVAL_VERSION[approval_id] = _APPROVAL_VERSION.get(approval_id, 1) + 1
        _APPROVAL_STATUS[approval_id] = normalized
    try:
        yield
    finally:
        with _APPROVAL_STATE_LOCK:
            current = _APPROVAL_STATUS.get(approval_id)
            if previous is None:
                if current is not None:
                    _APPROVAL_VERSION[approval_id] = _APPROVAL_VERSION.get(approval_id, 1) + 1
                _APPROVAL_STATUS.pop(approval_id, None)
            else:
                if current != previous:
                    _APPROVAL_VERSION[approval_id] = _APPROVAL_VERSION.get(approval_id, 1) + 1
                _APPROVAL_STATUS[approval_id] = previous
