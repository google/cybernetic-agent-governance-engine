from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, field
from threading import RLock
from typing import Protocol


class AuthorityConsistencyCheckpointUnavailable(RuntimeError):
    """Raised when distributed authority consistency cannot be established."""


class AuthorityContinuityAnchorUnavailable(AuthorityConsistencyCheckpointUnavailable):
    """Raised when checkpoint continuity cannot be independently established."""


class AuthorityConsistencyCheckpoint(Protocol):
    """Shared consistency memory for authenticated authority observations.

    Production implementations should use durable, strongly consistent storage
    when rollback/equivocation guarantees must hold across replicas, restarts,
    regions or failover events.
    """

    def get_highest_verified_version(self, source: str, authority_id: str) -> int | None: ...
    def get_verified_digest(self, source: str, authority_id: str, version: int) -> str | None: ...
    def observe_verified_version(self, source: str, authority_id: str, version: int, *, content_digest: str | None = None) -> int: ...


class AuthorityContinuityAnchor(Protocol):
    """Independent rollback-resistant continuity trace.

    The anchor records both the monotonic version and the exact authenticated
    content digest for that version. It must be independent of the checkpoint's
    rollback/failover domain. Production claims require durable monotonic storage
    with semantics strong enough that a successful anchor observation cannot
    disappear on the failover path it is intended to protect.
    """

    def get_highest_anchored_version(self, source: str, authority_id: str) -> int | None: ...
    def get_anchored_digest(self, source: str, authority_id: str, version: int) -> str | None: ...
    def observe_anchored_version(self, source: str, authority_id: str, version: int, *, content_digest: str | None = None) -> int: ...


@dataclass
class InMemoryAuthorityConsistencyCheckpoint:
    """Reference-harness checkpoint that can be shared by multiple replicas."""

    _highest_verified_version: dict[tuple[str, str], int] = field(default_factory=dict)
    _verified_version_digests: dict[tuple[str, str, int], str] = field(default_factory=dict)
    _lock: RLock = field(default_factory=RLock)

    def get_highest_verified_version(self, source: str, authority_id: str) -> int | None:
        with self._lock:
            return self._highest_verified_version.get((source, authority_id))

    def get_verified_digest(self, source: str, authority_id: str, version: int) -> str | None:
        with self._lock:
            return self._verified_version_digests.get((source, authority_id, version))

    def observe_verified_version(self, source: str, authority_id: str, version: int, *, content_digest: str | None = None) -> int:
        if version < 1:
            raise ValueError("verified authority version must be positive")
        key = (source, authority_id)
        with self._lock:
            if content_digest is not None:
                digest_key = (source, authority_id, version)
                existing = self._verified_version_digests.get(digest_key)
                if existing is not None and existing != content_digest:
                    raise ValueError("verified authority version is already bound to different content")
                self._verified_version_digests[digest_key] = content_digest
            previous = self._highest_verified_version.get(key)
            if previous is None or version > previous:
                self._highest_verified_version[key] = version
                return version
            return previous

    def clear(self, source: str | None = None, authority_id: str | None = None) -> None:
        with self._lock:
            if source is None and authority_id is None:
                self._highest_verified_version.clear()
                self._verified_version_digests.clear()
                return
            for key in list(self._highest_verified_version):
                if source is not None and key[0] != source:
                    continue
                if authority_id is not None and key[1] != authority_id:
                    continue
                self._highest_verified_version.pop(key, None)
            for key in list(self._verified_version_digests):
                if source is not None and key[0] != source:
                    continue
                if authority_id is not None and key[1] != authority_id:
                    continue
                self._verified_version_digests.pop(key, None)


@dataclass
class InMemoryAuthorityContinuityAnchor:
    """Reference-only monotonic version + content-digest continuity anchor."""

    _highest_anchored_version: dict[tuple[str, str], int] = field(default_factory=dict)
    _anchored_version_digests: dict[tuple[str, str, int], str] = field(default_factory=dict)
    _lock: RLock = field(default_factory=RLock)

    def get_highest_anchored_version(self, source: str, authority_id: str) -> int | None:
        with self._lock:
            return self._highest_anchored_version.get((source, authority_id))

    def get_anchored_digest(self, source: str, authority_id: str, version: int) -> str | None:
        with self._lock:
            return self._anchored_version_digests.get((source, authority_id, version))

    def observe_anchored_version(self, source: str, authority_id: str, version: int, *, content_digest: str | None = None) -> int:
        if version < 1:
            raise ValueError("anchored authority version must be positive")
        key = (source, authority_id)
        with self._lock:
            if content_digest is not None:
                digest_key = (source, authority_id, version)
                existing = self._anchored_version_digests.get(digest_key)
                if existing is not None and existing != content_digest:
                    raise ValueError("anchored authority version is already bound to different content")
                self._anchored_version_digests[digest_key] = content_digest
            previous = self._highest_anchored_version.get(key)
            if previous is None or version > previous:
                self._highest_anchored_version[key] = version
                return version
            return previous

    def clear(self, source: str | None = None, authority_id: str | None = None) -> None:
        with self._lock:
            if source is None and authority_id is None:
                self._highest_anchored_version.clear()
                self._anchored_version_digests.clear()
                return
            for key in list(self._highest_anchored_version):
                if source is not None and key[0] != source:
                    continue
                if authority_id is not None and key[1] != authority_id:
                    continue
                self._highest_anchored_version.pop(key, None)
            for key in list(self._anchored_version_digests):
                if source is not None and key[0] != source:
                    continue
                if authority_id is not None and key[1] != authority_id:
                    continue
                self._anchored_version_digests.pop(key, None)


DEFAULT_AUTHORITY_CONSISTENCY_CHECKPOINT = InMemoryAuthorityConsistencyCheckpoint()
DEFAULT_AUTHORITY_CONTINUITY_ANCHOR = InMemoryAuthorityContinuityAnchor()
_ACTIVE_AUTHORITY_CONSISTENCY_CHECKPOINT: AuthorityConsistencyCheckpoint = DEFAULT_AUTHORITY_CONSISTENCY_CHECKPOINT
_ACTIVE_AUTHORITY_CONTINUITY_ANCHOR: AuthorityContinuityAnchor = DEFAULT_AUTHORITY_CONTINUITY_ANCHOR


@contextmanager
def temporary_authority_consistency_checkpoint(checkpoint: AuthorityConsistencyCheckpoint, continuity_anchor: AuthorityContinuityAnchor | None = None):
    """Reference-harness wiring hook for modelling shared replica/recovery state."""
    global _ACTIVE_AUTHORITY_CONSISTENCY_CHECKPOINT, _ACTIVE_AUTHORITY_CONTINUITY_ANCHOR
    previous_checkpoint = _ACTIVE_AUTHORITY_CONSISTENCY_CHECKPOINT
    previous_anchor = _ACTIVE_AUTHORITY_CONTINUITY_ANCHOR
    isolated_anchor = continuity_anchor or InMemoryAuthorityContinuityAnchor()
    _ACTIVE_AUTHORITY_CONSISTENCY_CHECKPOINT = checkpoint
    _ACTIVE_AUTHORITY_CONTINUITY_ANCHOR = isolated_anchor
    try:
        yield checkpoint
    finally:
        _ACTIVE_AUTHORITY_CONSISTENCY_CHECKPOINT = previous_checkpoint
        _ACTIVE_AUTHORITY_CONTINUITY_ANCHOR = previous_anchor


def _checkpoint_call(operation, *args, **kwargs):
    try:
        return operation(*args, **kwargs)
    except AuthorityConsistencyCheckpointUnavailable:
        raise
    except Exception as exc:
        raise AuthorityConsistencyCheckpointUnavailable("shared authority consistency checkpoint unavailable") from exc


def _anchor_call(operation, *args, **kwargs):
    try:
        return operation(*args, **kwargs)
    except AuthorityContinuityAnchorUnavailable:
        raise
    except Exception as exc:
        raise AuthorityContinuityAnchorUnavailable("independent authority continuity anchor unavailable") from exc


def get_highest_anchored_version(source: str, authority_id: str) -> int | None:
    return _anchor_call(_ACTIVE_AUTHORITY_CONTINUITY_ANCHOR.get_highest_anchored_version, source, authority_id)


def get_anchored_digest(source: str, authority_id: str, version: int) -> str | None:
    operation = getattr(_ACTIVE_AUTHORITY_CONTINUITY_ANCHOR, "get_anchored_digest", None)
    if operation is None:
        return None
    return _anchor_call(operation, source, authority_id, version)


def observe_anchored_version(source: str, authority_id: str, version: int, *, content_digest: str | None = None) -> int:
    current = _anchor_call(
        _ACTIVE_AUTHORITY_CONTINUITY_ANCHOR.observe_anchored_version,
        source,
        authority_id,
        version,
        content_digest=content_digest,
    )
    if current > version:
        raise AuthorityContinuityAnchorUnavailable("independent continuity anchor rejected stale authority observation")
    return current


def get_highest_verified_version(source: str, authority_id: str) -> int | None:
    checkpoint_version = _checkpoint_call(_ACTIVE_AUTHORITY_CONSISTENCY_CHECKPOINT.get_highest_verified_version, source, authority_id)
    anchored_version = get_highest_anchored_version(source, authority_id)
    if anchored_version is not None and (checkpoint_version is None or checkpoint_version < anchored_version):
        raise AuthorityConsistencyCheckpointUnavailable("independent continuity anchor detected checkpoint rollback")
    return checkpoint_version


def get_verified_digest(source: str, authority_id: str, version: int) -> str | None:
    checkpoint_digest = _checkpoint_call(_ACTIVE_AUTHORITY_CONSISTENCY_CHECKPOINT.get_verified_digest, source, authority_id, version)
    anchored_digest = get_anchored_digest(source, authority_id, version)
    if checkpoint_digest is not None and anchored_digest is not None and checkpoint_digest != anchored_digest:
        raise AuthorityConsistencyCheckpointUnavailable("checkpoint content conflicts with independent continuity anchor")
    return checkpoint_digest


def observe_verified_version(source: str, authority_id: str, version: int, *, content_digest: str | None = None) -> int:
    """Accept a verified authority observation using anchor-first continuity.

    The independent anchor is advanced before the checkpoint is accepted. If the
    process crashes or the checkpoint loses an acknowledged write after this
    point, recovery sees anchor > checkpoint and fails closed instead of silently
    resurrecting an older authority state.
    """
    try:
        observe_anchored_version(source, authority_id, version, content_digest=content_digest)
    except AuthorityContinuityAnchorUnavailable as exc:
        raise AuthorityConsistencyCheckpointUnavailable("independent continuity anchor rejected candidate authority state") from exc

    current = _checkpoint_call(
        _ACTIVE_AUTHORITY_CONSISTENCY_CHECKPOINT.observe_verified_version,
        source,
        authority_id,
        version,
        content_digest=content_digest,
    )
    if current > version:
        raise AuthorityConsistencyCheckpointUnavailable("shared authority consistency checkpoint rejected stale concurrent observation")

    anchored_current = get_highest_anchored_version(source, authority_id)
    if anchored_current is not None and current < anchored_current:
        raise AuthorityConsistencyCheckpointUnavailable("checkpoint did not reach independently anchored authority high-water mark")
    return current


def clear_verified_version_floor(source: str | None = None, authority_id: str | None = None) -> None:
    """Compatibility/test helper for the default reference stores only."""
    DEFAULT_AUTHORITY_CONSISTENCY_CHECKPOINT.clear(source, authority_id)
    DEFAULT_AUTHORITY_CONTINUITY_ANCHOR.clear(source, authority_id)
