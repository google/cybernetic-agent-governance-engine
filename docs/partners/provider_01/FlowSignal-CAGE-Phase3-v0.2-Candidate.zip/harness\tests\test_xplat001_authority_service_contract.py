from pathlib import Path

from fastapi.encoders import jsonable_encoder
from fastapi.testclient import TestClient

from app.api import app
from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"

client = TestClient(app)


def _payload(request):
    payload = jsonable_encoder(request)
    payload.update(
        {
            "approval_id": APPROVAL_ID,
            "platform": "REFERENCE-PLATFORM-A",
            "execution_id": "EXEC-XPLAT-001",
            "evidence_references": [
                {"type": "platform_policy", "result": "PERMIT"}
            ],
        }
    )
    return payload


def test_xplat001_authority_service_returns_bound_allow_without_execution_capability():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            result = client.post("/authority/determine", json=_payload(request))

    assert result.status_code == 200
    body = result.json()
    assert body["determination"] == "ALLOW"
    assert body["reason_code"] == "AUTHORITY_ESTABLISHED"
    assert body["execution_context"] == {
        "platform": "REFERENCE-PLATFORM-A",
        "execution_id": "EXEC-XPLAT-001",
    }
    assert body["authority_receipt"]["action_binding_hash"]
    assert body["authority_receipt"]["authority_state_version"] >= 1

    route_paths = {route.path for route in app.routes}
    assert "/authority/determine" in route_paths
    assert "/execute" not in route_paths
    assert "/payment/execute" not in route_paths
    assert "/execution/permit" not in route_paths


def test_xplat001_service_ignores_caller_active_assertion_when_authority_is_revoked():
    request = load_scenario(AP001)
    payload = _payload(request)
    payload["mandate_status"] = "ACTIVE"
    payload["execution_id"] = "EXEC-XPLAT-002"

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            result = client.post("/authority/determine", json=payload)

    assert result.status_code == 200
    body = result.json()
    assert body["determination"] == "REFUSE"
    assert body["reason_code"] == "AUTHORITY_NOT_ESTABLISHED"

    evidence = body["authority_receipt"]["evidence_references"]
    presented = next(
        item for item in evidence if item["type"] == "presented_authority_assertion"
    )
    authoritative = next(
        item for item in evidence if item["type"] == "delegated_authority_state"
    )

    assert presented["status"] == "ACTIVE"
    assert authoritative["status"] == "REVOKED"
    assert authoritative["source"] == "authoritative_mandate_store"
