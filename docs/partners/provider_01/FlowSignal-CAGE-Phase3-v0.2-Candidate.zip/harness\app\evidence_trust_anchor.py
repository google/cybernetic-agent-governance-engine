from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class EvidenceTrustAnchor:
    repository: str
    workflow_path: str
    ref: str
    oidc_issuer: str

    @property
    def certificate_identity(self) -> str:
        return f"https://github.com/{self.repository}/{self.workflow_path}@{self.ref}"

    def validate_identity(self, *, certificate_identity: str, oidc_issuer: str) -> bool:
        return (
            certificate_identity == self.certificate_identity
            and oidc_issuer == self.oidc_issuer
        )


RUNTIME_AUTHORITY_EVIDENCE_TRUST_ANCHOR_V0_1 = EvidenceTrustAnchor(
    repository="grahamb-ai/flowsignal-agentic-payments-vnext",
    workflow_path=".github/workflows/vnext-regression.yml",
    ref="refs/heads/runtime-authority-vnext",
    oidc_issuer="https://token.actions.githubusercontent.com",
)
