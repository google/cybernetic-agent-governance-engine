from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
WORKFLOW = ROOT / ".github" / "workflows" / "vnext-regression.yml"


def test_xplat011_conformance_pass_must_be_derived_from_observed_test_results():
    """Failure-first: the evidence report must not self-declare mapped tests observed.

    A public reviewer should be able to trace every conformance PASS to the exact
    test result emitted by the identified workflow run. Merely running pytest and
    then constructing the full configured evidence set is not sufficient proof.
    """
    workflow = WORKFLOW.read_text(encoding="utf-8")

    assert "--junitxml=" in workflow, (
        "workflow does not persist machine-readable pytest results for evidence derivation"
    )
    assert "observed = {" not in workflow, (
        "workflow self-declares all mapped evidence after pytest rather than deriving "
        "observed evidence from actual per-test results"
    )
    assert "pytest-results.xml" in workflow
