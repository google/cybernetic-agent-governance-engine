from __future__ import annotations

import os
import sqlite3
from pathlib import Path


_DEFAULT_STORE_PATH = Path(".flowsignal-runtime/authority_receipt_use.sqlite3")


def _store_path() -> Path:
    configured = os.environ.get("FLOWSIGNAL_AUTHORITY_RECEIPT_USE_STORE")
    return Path(configured) if configured else _DEFAULT_STORE_PATH


def claim_authority_receipt_once(receipt_id: str) -> bool:
    """Atomically claim one vNext Authority Receipt for execution-permit minting."""
    path = _store_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path, timeout=5.0, isolation_level=None)
    try:
        connection.execute("PRAGMA busy_timeout=5000")
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS claimed_authority_receipts (
                receipt_id TEXT PRIMARY KEY,
                claimed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        cursor = connection.execute(
            "INSERT OR IGNORE INTO claimed_authority_receipts(receipt_id) VALUES (?)",
            (receipt_id,),
        )
        return cursor.rowcount == 1
    finally:
        connection.close()
