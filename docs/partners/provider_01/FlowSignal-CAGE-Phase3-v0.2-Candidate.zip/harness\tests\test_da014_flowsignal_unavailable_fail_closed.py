from datetime import datetime
from pathlib import Path

from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from app.engines.delegated_authority import evaluate_delegated_authority
from app.engines.execution_gateway import ExecutionAttempt
from app.engines.reference_execution_boundary import determine_and_validate_execution
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


def _attempt(request):
    return ExecutionAttempt(
        actor_id=request.actor_id,
        principal_id=request.principal_id,
        action=request.action,
        target=request.target,
        amount=request.amount,
        currency=request.currency,
        source_account=request.source_account,
        beneficiary=request.beneficiary,
        purpose=request.purpose,
        mandate_id=request.mandate_id,
        attempted_at=datetime.fromisoformat("2026-08-10T09:15:30+00:00"),
    )


def test_da014_flowsignal_unavailable_fails_closed_without_receipt_or_permit():
    request = load_scenario(AP001)

    def unavailable_determination():
        raise ConnectionError("FlowSignal authority service unavailable")

    result = determine_and_validate_execution(
        determine_authority=unavailable_determination,
        attempt=_attempt(request),
    )

    assert result.status == "BLOCKED"
    assert result.reason_code == "AUTHORITY_DETERMINATION_UNAVAILABLE"
    assert result.authority_receipt is None
    assert result.gateway_result is None


def test_da014_positive_control_current_determination_still_permits():
    request = load_scenario(AP001)

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            result = determine_and_validate_execution(
                determine_authority=lambda: evaluate_delegated_authority(
                    request,
                    approval_id=APPROVAL_ID,
                ),
                attempt=_attempt(request),
            )

            assert result.status == "PERMITTED"
            assert result.reason_code == "BOUND_ALLOW_VALID"
            assert result.authority_receipt is not None
            assert result.gateway_result is not None
            assert result.gateway_result.execution_permit is not None
