from dataclasses import replace
from datetime import datetime, timedelta, timezone
from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult
from app.engines.authority_source_authenticity import (
    attest_reference_authority_record,
    verify_authority_source_attestation,
)
from app.engines.authority_store import get_authority_record
from app.engines.authority_version_floor import (
    InMemoryAuthorityConsistencyCheckpoint,
    temporary_authority_consistency_checkpoint,
)
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"
SOURCE = "authoritative_mandate_store"


class SignedRecordAdapter:
    def __init__(self, record):
        self.record = record
        self.attestation = attest_reference_authority_record(record)

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source=SOURCE,
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def test_attack017_future_dated_authentic_authority_evidence_cannot_allow():
    request = load_scenario(AP001)
    base = get_authority_record(request.mandate_id)
    assert base is not None

    evaluated_at = datetime(2026, 8, 28, 12, 0, 0, tzinfo=timezone.utc)
    future_record = replace(
        base,
        provenance=replace(
            base.provenance,
            observed_at=evaluated_at + timedelta(minutes=5),
        ),
    )
    adapter = SignedRecordAdapter(future_record)

    # Provenance/integrity may be genuine even when temporal evidence is impossible.
    assert verify_authority_source_attestation(
        future_record,
        adapter.attestation,
        expected_source=SOURCE,
    )

    # Isolate distributed consistency so another guard cannot mask this temporal attack.
    with temporary_authority_consistency_checkpoint(InMemoryAuthorityConsistencyCheckpoint()):
        response, receipt = evaluate_delegated_authority(
            request,
            approval_id=APPROVAL_ID,
            sealed_at=evaluated_at,
            authority_evidence_adapter=adapter,
            authority_evidence_max_age_seconds=60,
        )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_EVIDENCE_FUTURE_DATED"

    authority_evidence = next(
        item
        for item in receipt.evidence_references
        if item.get("type") == "delegated_authority_state"
    )
    assert authority_evidence["status"] == "UNKNOWN"
    assert authority_evidence["source_status"] == "FUTURE_DATED"
    assert authority_evidence["adapter_conformance"] == "FAIL"
    assert "AE-CP-021 authority evidence observed_at is in the future" in authority_evidence["adapter_conformance_violations"]
