from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from app.engines.execution_gateway import ExecutionAttempt, GatewayResult, validate_execution
from app.engines.financial_types import AuthorityReceipt


@dataclass
class BoundaryAuthorityResult:
    status: str
    reason_code: str
    gateway_result: GatewayResult | None = None
    authority_receipt: AuthorityReceipt | None = None


def determine_and_validate_execution(
    *,
    determine_authority: Callable[[], tuple[object, AuthorityReceipt]],
    attempt: ExecutionAttempt,
) -> BoundaryAuthorityResult:
    """Reference execution boundary that fails closed if authority determination is unavailable.

    The boundary does not infer authority, reuse a prior result, or bypass FlowSignal when the
    authority-determination service cannot provide a current receipt. Only a successfully
    returned Authority Receipt is passed to the existing deterministic gateway validation path.
    """
    try:
        _response, receipt = determine_authority()
    except Exception:
        return BoundaryAuthorityResult(
            status="BLOCKED",
            reason_code="AUTHORITY_DETERMINATION_UNAVAILABLE",
        )

    if receipt is None:
        return BoundaryAuthorityResult(
            status="BLOCKED",
            reason_code="AUTHORITY_DETERMINATION_UNAVAILABLE",
        )

    gateway = validate_execution(receipt, attempt)
    return BoundaryAuthorityResult(
        status=gateway.status,
        reason_code=gateway.reason_code,
        gateway_result=gateway,
        authority_receipt=receipt,
    )
