from dataclasses import replace
from pathlib import Path

from app.engines.authority_evidence_adapter import AuthorityEvidenceResult, ReferenceAuthorityStoreAdapter
from app.engines.authority_source_authenticity import attest_reference_authority_record
from app.engines.authority_store import get_authority_record
from app.engines.delegated_authority import evaluate_delegated_authority
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"


class SameVersionEquivocatingAdapter:
    def __init__(self, record, attestation):
        self.record = record
        self.attestation = attestation

    def acquire(self, authority_id: str):
        return AuthorityEvidenceResult(
            authority_id=authority_id,
            record=self.record,
            source_status="AVAILABLE",
            evidence_source="authoritative_mandate_store",
            acquisition_layer=type(self).__name__,
            source_attestation=self.attestation,
        )


def test_attack004_two_authenticated_meanings_at_same_version_must_be_rejected():
    request = load_scenario(AP001)
    original = get_authority_record(request.mandate_id)
    assert original is not None

    # FlowSignal first observes one source-authenticated meaning for version N.
    initial_response, _ = evaluate_delegated_authority(
        request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=ReferenceAuthorityStoreAdapter(),
    )
    assert initial_response.decision == "ALLOW"

    # The same trusted signing identity now emits a different delegated meaning
    # with exactly the same source version. Structurally valid and authentic,
    # but logically inconsistent with the already-observed version N.
    attacker_request = replace(request, actor_id="agent-equivocated-77")
    conflicting = replace(original, delegate_id=attacker_request.actor_id)
    assert conflicting.version == original.version
    conflicting_attestation = attest_reference_authority_record(conflicting)

    response, receipt = evaluate_delegated_authority(
        attacker_request,
        approval_id=APPROVAL_ID,
        authority_evidence_adapter=SameVersionEquivocatingAdapter(
            conflicting,
            conflicting_attestation,
        ),
    )

    assert response.decision == "REFUSE"
    assert response.reason_code == "AUTHORITY_EVIDENCE_EQUIVOCATION_DETECTED"

    evidence = next(
        item
        for item in receipt.evidence_references
        if item["type"] == "delegated_authority_state"
    )
    assert evidence["source_authenticity"] == "VERIFIED"
    assert evidence["record_version"] == original.version
    assert evidence["equivocation_detected"] is True
