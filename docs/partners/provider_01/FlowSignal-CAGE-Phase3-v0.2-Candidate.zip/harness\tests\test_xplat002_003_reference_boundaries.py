from pathlib import Path

from fastapi.encoders import jsonable_encoder
from fastapi.testclient import TestClient

from app.api import app
from app.engines.approval_store import temporary_approval_status
from app.engines.authority_store import temporary_authoritative_mandate_status
from app.reference_boundaries import ReferenceBoundaryAlpha, ReferenceBoundaryBeta
from harness.runner import load_scenario


ROOT = Path(__file__).resolve().parents[1]
AP001 = ROOT / "harness" / "scenarios" / "AP-001_allow.json"
APPROVAL_ID = "APPROVAL-TREASURY-001"

client = TestClient(app)


def _authority_caller(path, payload):
    return client.post(path, json=payload)


def _payload(request):
    payload = jsonable_encoder(request)
    payload.update(
        {
            "approval_id": APPROVAL_ID,
            "platform": "UNSET-BY-BOUNDARY",
            "execution_id": "UNSET-BY-BOUNDARY",
            "evidence_references": [
                {"type": "platform_policy", "result": "PERMIT"}
            ],
        }
    )
    return payload


def _boundaries():
    return (
        ReferenceBoundaryAlpha(authority_caller=_authority_caller),
        ReferenceBoundaryBeta(authority_caller=_authority_caller),
    )


def test_xplat002_two_different_boundaries_receive_identical_allow_semantics():
    request = load_scenario(AP001)
    alpha, beta = _boundaries()

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "ACTIVE"):
            alpha_result = alpha.determine(
                execution_id="EXEC-XPLAT-ALPHA-ALLOW",
                payload=_payload(request),
            )
            beta_result = beta.determine(
                execution_id="EXEC-XPLAT-BETA-ALLOW",
                payload=_payload(request),
            )

    assert alpha_result.platform != beta_result.platform
    assert alpha_result.execution_id != beta_result.execution_id

    assert alpha_result.determination == beta_result.determination == "ALLOW"
    assert alpha_result.reason_code == beta_result.reason_code == "AUTHORITY_ESTABLISHED"
    assert alpha_result.permitted_to_continue is True
    assert beta_result.permitted_to_continue is True

    assert (
        alpha_result.authority_receipt["action_binding_hash"]
        == beta_result.authority_receipt["action_binding_hash"]
    )
    assert (
        alpha_result.authority_receipt["authority_state_version"]
        == beta_result.authority_receipt["authority_state_version"]
    )


def test_xplat003_two_different_boundaries_receive_identical_refuse_semantics():
    request = load_scenario(AP001)
    payload = _payload(request)
    payload["mandate_status"] = "ACTIVE"
    alpha, beta = _boundaries()

    with temporary_approval_status(APPROVAL_ID, "APPROVED"):
        with temporary_authoritative_mandate_status(request.mandate_id, "REVOKED"):
            alpha_result = alpha.determine(
                execution_id="EXEC-XPLAT-ALPHA-REFUSE",
                payload=payload,
            )
            beta_result = beta.determine(
                execution_id="EXEC-XPLAT-BETA-REFUSE",
                payload=payload,
            )

    assert alpha_result.determination == beta_result.determination == "REFUSE"
    assert alpha_result.reason_code == beta_result.reason_code == "AUTHORITY_NOT_ESTABLISHED"
    assert alpha_result.permitted_to_continue is False
    assert beta_result.permitted_to_continue is False

    for result in (alpha_result, beta_result):
        evidence = result.authority_receipt["evidence_references"]
        presented = next(
            item for item in evidence if item["type"] == "presented_authority_assertion"
        )
        authoritative = next(
            item for item in evidence if item["type"] == "delegated_authority_state"
        )
        assert presented["status"] == "ACTIVE"
        assert authoritative["status"] == "REVOKED"
        assert authoritative["source"] == "authoritative_mandate_store"
